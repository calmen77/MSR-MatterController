"use strict";

/**
 * MatterController — Reactor Controller for the Matter protocol
 *
 * Connects to Matter devices via matter.js (@matter/main v0.17.1+).
 * Creates its own Matter fabric; devices are commissioned via Multi-Admin
 * (open a commissioning window in e.g. Apple Home and enter the PIN in Reactor).
 *
 * Supported device types:
 *   On/Off lights, dimmable lights, plugs, temperature sensors,
 *   motion sensors (occupancy), contact sensors (door/window).
 *
 * Requirements: Node.js >= 18, @matter/main ^0.17.1
 * Installation: cd ext/MatterController && npm install
 *
 * reactor.yaml example:
 *   controllers:
 *     - id: matter
 *       implementation: MatterController
 *       config:
 *         controller_name: "Reactor"
 *         fabric_label: "MatterController"
 */

import path from "node:path";
import fs   from "node:fs";
import { createRequire } from "node:module";
const __dirname = import.meta.dirname;   // Node >=20.11/21.2 — replaces CJS __dirname
const require = createRequire( import.meta.url );

// ── Reactor imports ────────────────────────────────────────────────────────────
// Reactor adds its root to the Node.js module search path, so no relative
// paths are needed (or work) here.

const version  = 26282;
const revision = 1;

/**
 * ORPHAN_CLUSTER_CAPS — generic table of clusters that can appear on an "orphan" endpoint
 * (an endpoint with no recognizable device type of its own — Descriptor.deviceTypeList is
 * empty/unrecognized — sibling to the node's real functional endpoint(s)). Each entry maps
 * a cluster ID to the Reactor capability it can provide and the attribute ID that must be
 * present for that capability to apply. This is the single place to extend if a future device
 * puts some other cluster (not just PowerSource) on its own orphan endpoint.
 *
 * Used by both code paths in _syncNode():
 *  - split_endpoints = false (default): orphan clusters found are merged into the node's sole
 *    functional entity (unchanged legacy behavior — a PowerSource cluster can live on its own
 *    sibling endpoint, e.g. observed on a real Thread door lock).
 *  - split_endpoints = true: each orphan endpoint that matches at least one entry here becomes
 *    its own separate Sensor entity instead of being merged.
 */
const ORPHAN_CLUSTER_CAPS = [
    { clusterId: 47 /* PowerSource */, attrId: 12, capability: "battery_power" },
    { clusterId: 47 /* PowerSource */, attrId: 11, capability: "voltage_sensor" },
];

/**
 * Matter device types that are actual *lights* (as opposed to plugs/relays/switches that merely
 * happen to expose an OnOff + Identify cluster, e.g. a metering smart plug). Identify.TriggerEffect
 * (the basis of Reactor's light_effect capability — see below) is only meaningful on these: a plain
 * on/off relay/plug has no visible effect it can actually perform, even though it mandatorily
 * implements the Identify cluster like every other Matter device. Used to gate light_effect
 * auto-detection in _createOrUpdateEntity() so plugs/relays (0x010A, 0x010B, 0x0103, 0x010F, 0x0110)
 * don't get a non-functional light_effect capability just for having power_switch + Identify.
 */
const LIGHT_DEVICE_TYPES = new Set( [
    0x0100, // OnOffLight
    0x0101, // DimmableLight
    0x010C, // ColorTemperatureLight
    0x010D, // ExtendedColorLight
] );

/**
 * Matter ThermostatSystemMode (attr 28) → Reactor hvac_control.mode enum.
 * Matter: 0=Off, 1=Auto, 3=Cool, 4=Heat, 5=EmergencyHeat, 6=Precooling, 7=FanOnly, 8=Dry, 9=Sleep.
 * Reactor hvac_control.mode: off/on/heat/cool/auto/vent/dry/emergency/secondary.
 * Precooling (6) is treated as "cool" and Sleep (9) as "auto" — neither has a direct Reactor
 * equivalent, these are the closest matches.
 */
const HVAC_SYSTEM_MODE_TO_STRING = {
    0: "off", 1: "auto", 3: "cool", 4: "heat", 5: "emergency", 6: "cool", 7: "vent", 8: "dry", 9: "auto",
};
function _hvacModeToString( systemMode ) {
    return HVAC_SYSTEM_MODE_TO_STRING[ systemMode ] ?? "auto";
}
/**
 * Reverse of HVAC_SYSTEM_MODE_TO_STRING, for hvac_control.set_mode → Thermostat.systemMode writes.
 * "on" has no direct Matter SystemMode equivalent — mapped to Auto (1) as the closest reasonable
 * fallback. "secondary" has no equivalent at all and is deliberately left unmapped (unsupported).
 */
const HVAC_MODE_STRING_TO_SYSTEM_MODE = {
    "off": 0, "auto": 1, "cool": 3, "heat": 4, "emergency": 5, "vent": 7, "dry": 8, "on": 1,
};
/**
 * Derives hvac_control.state (off/idle/heating/cooling/...) from systemMode + the
 * thermostatRunningState bitmap/struct (attr 41, decoded by matter.js as
 * { heat, cool, fan, heatStage2, coolStage2, fanStage2, fanStage3 }).
 */
function _hvacStateToString( systemMode, runningState ) {
    if ( systemMode === 0 ) return "off";
    if ( runningState?.heat ) return "heating";
    if ( runningState?.cool ) return "cooling";
    return "idle";
}

const Logger = require("server/lib/Logger").default;
Logger.getLogger("MatterController", "Controller").always("Module MatterController v%1", version);

const Controller    = require("server/lib/Controller").default.requires(22304);
const Entity        = require("server/lib/Entity").default.requires(22306);
const Configuration = require("server/lib/Configuration").default;

// ── Module-level state ────────────────────────────────────────────────────────

let impl = false;

// matter.js is loaded lazily to provide clear error messages if it is missing
let matterLoaded = false;
let ServerNode, Environment, ManualPairingCodeCodec;
let Descriptor, BasicInformation, OnOff, LevelControl, ColorControl, Identify,
    TemperatureMeasurement, OccupancySensing, BooleanState, PowerSource,
    BridgedDeviceBasicInformation, DoorLock,
    // UNTESTED (2026-09-08) — prepared from matter.js cluster specs only, no real device
    // available yet to verify attribute semantics/direction. See the UNTESTED comments in
    // matter_devices.yaml and README.md's device type table before relying on these.
    WindowCovering, SmokeCoAlarm,
    RelativeHumidityMeasurement, PressureMeasurement, FlowMeasurement, IlluminanceMeasurement,
    AirQuality, ValveConfigurationAndControl, MatterSwitch, FanControl, EnergyEvse,
    Thermostat, ElectricalPowerMeasurement, ElectricalEnergyMeasurement;
let Invoke, Write, WriteResult;

// ── DeviceTypeId → Reactor configuration ──────────────────────────────────────

const DEVICE_MAP = new Map([
    [ 0x0100, { entity_type: "Switch", capabilities: ["power_switch", "toggle"],                                    default_name: "Matter Light"                  } ],
    [ 0x0101, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming"],                         default_name: "Matter Dimmable Light"          } ],
    [ 0x010C, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming", "color_temperature"],    default_name: "Matter Color Temp Light"        } ],
    [ 0x010D, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming", "color_temperature"],    default_name: "Matter Extended Color Light"    } ],
    [ 0x010A, { entity_type: "Switch", capabilities: ["power_switch", "toggle"],                                    default_name: "Matter Plug"                   } ],
    [ 0x010B, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming"],                         default_name: "Matter Dimmable Plug"          } ],
    [ 0x0302, { entity_type: "Sensor", capabilities: ["temperature_sensor"],                                        default_name: "Matter Temperature"            } ],
    [ 0x0107, { entity_type: "Sensor", capabilities: ["motion_sensor"],                                             default_name: "Matter Occupancy"              } ],
    [ 0x0015, { entity_type: "Sensor", capabilities: ["door_sensor"],                                               default_name: "Matter Contact Sensor"         } ],
    [ 0x0850, { entity_type: "Sensor", capabilities: ["binary_sensor"],                                             default_name: "Matter On/Off Sensor"          } ],
    [ 0x000A, { entity_type: "Lock",   capabilities: ["lock"],                                                      default_name: "Matter Door Lock"              } ],
    // ── UNTESTED (2026-09-08): prepared from matter.js cluster specs, no physical device
    // available yet to verify. Verify carefully (units, enum semantics, sign conventions)
    // the first time a real device of this type is commissioned.
    [ 0x0202, { entity_type: "Cover",  capabilities: ["cover", "position"],                                         default_name: "Matter Window Covering"        } ],
    [ 0x0076, { entity_type: "Sensor", capabilities: ["smoke_detector", "co_detector"],                             default_name: "Matter Smoke/CO Alarm"         } ],
    // NOTE: Thermostat/AirConditioner mappings exist for entity/capability assignment only —
    // the Thermostat cluster itself (setpoints, modes, running state) is intentionally NOT
    // implemented yet (2026-09-08): its multi-setpoint/multi-mode model doesn't map cleanly
    // onto Reactor's hvac_control capability without real-device testing to get right.
    // These entities will currently only show temperature_sensor.value (via the standard
    // TemperatureMeasurement cluster, already implemented) with no thermostat control.
    [ 0x0301, { entity_type: "Thermostat", capabilities: ["hvac_control", "temperature_sensor"],                    default_name: "Matter Thermostat"             } ],
    [ 0x0072, { entity_type: "Thermostat", capabilities: ["hvac_control", "temperature_sensor"],                    default_name: "Matter Air Conditioner"        } ],
    // NOTE: Fan/AirPurifier — FanControl cluster is attribute-write based (fanMode), not
    // command based like OnOff. No verified attribute-write path exists yet in this file (all
    // other commands use Invoke against cluster *commands*) — see _doFan() for details on what
    // is and isn't implemented.
    [ 0x002B, { entity_type: "Switch", capabilities: ["power_switch"],                                              default_name: "Matter Fan"                    } ],
    [ 0x002D, { entity_type: "Switch", capabilities: ["power_switch"],                                              default_name: "Matter Air Purifier"           } ],
    [ 0x0042, { entity_type: "Switch", capabilities: ["valve"],                                                     default_name: "Matter Water Valve"            } ],
    [ 0x000F, { entity_type: "Sensor", capabilities: ["button"],                                                    default_name: "Matter Switch Button"          } ],
    // NOTE: EnergyEvse — read-only status mapping only; set_current/set_operating_mode/
    // set_schedule actions are NOT implemented (safety-critical charge control commands
    // should not be guessed at without spec verification against a real charger).
    [ 0x050C, { entity_type: "Switch", capabilities: ["ev_charger", "power_sensor"],                                 default_name: "Matter EV Charger"             } ],
    [ 0x0307, { entity_type: "Sensor", capabilities: ["humidity_sensor"],                                            default_name: "Matter Humidity Sensor"        } ],
    [ 0x0305, { entity_type: "Sensor", capabilities: ["pressure_sensor"],                                            default_name: "Matter Pressure Sensor"        } ],
    [ 0x0306, { entity_type: "Sensor", capabilities: ["value_sensor"],                                               default_name: "Matter Flow Sensor"            } ],
    [ 0x0106, { entity_type: "Sensor", capabilities: ["light_sensor"],                                               default_name: "Matter Light Sensor"           } ],
    [ 0x002C, { entity_type: "Sensor", capabilities: ["air_quality_sensor"],                                         default_name: "Matter Air Quality Sensor"     } ],
    [ 0x0043, { entity_type: "Sensor", capabilities: ["leak_detector"],                                              default_name: "Matter Water Leak Sensor"      } ],
    [ 0x0041, { entity_type: "Sensor", capabilities: ["freeze_detector"],                                            default_name: "Matter Water Freeze Sensor"    } ],
    [ 0x0044, { entity_type: "Sensor", capabilities: ["binary_sensor"],                                              default_name: "Matter Rain Sensor"            } ],
    [ 0x0045, { entity_type: "Sensor", capabilities: ["humidity_sensor"],                                            default_name: "Matter Soil Sensor"            } ],
]);

// ── Controller class ──────────────────────────────────────────────────────────

class MatterController extends Controller {

    /** Prevent Reactor from automatically creating a controller group */
    static createControllerGroup = false;

    constructor( ...args ) {
        super( ...args );
        this._serverNode    = null;   // @matter/main ServerNode
        this._reconnTimer   = null;
        this._retryCount    = 0;
        this._stopping      = false;
        // Map nodeId(string) → { peerAddress, entityIds[] }
        this._nodeMap             = new Map();
        // Map nodeId(string) → label (from the commission action — cleared after first _syncNode)
        this._commissioningLabels = new Map();
        // Map nodeId(string) → name (persisted to disk, survives entity delete)
        this._persistedNames      = new Map();
        // Map nodeId(string) → split_endpoints boolean (persisted to disk, per-node commission choice)
        this._splitEndpointsPrefs = new Map();
        // Pending split_endpoints choice for a commission in flight, consumed by _onNodeAdded()
        // the instant the new node appears — same race-avoidance pattern as _pendingCommissionLabel.
        this._pendingSplitEndpoints = null;
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    async start() {
        this._stopping = false;
        this.log.info( "%1 starting (v%2)", this, version );

        // Load impl data once per process
        if ( false === impl ) {
            impl = await this.loadBaseImplementationData( "matter", __dirname );
        }

        // Import matter.js
        if ( !matterLoaded ) {
            try {
                await this._importMatter();
            } catch ( err ) {
                this.log.err( "%1 cannot load @matter/main: %2\n  Run: cd ext/MatterController && npm install", this, err.message );
                this.offline();
                this._scheduleReconnect();
                return this;
            }
        }

        try {
            await this._startMatter();
            this._setupSystemEntity();
            this.online();
            this._retryCount = 0;
        } catch ( err ) {
            this.log.err( "%1 startup error: %2\n%3", this, err.message, err.stack );
            await this._stopMatter();
            this.offline();
            this._scheduleReconnect();
        }

        return this;
    }

    async stop() {
        this.log.info( "%1 stopping", this );
        this._stopping = true;
        this._clearReconnect();
        await this._stopMatter();
        return super.stop();
    }

    // ── Entity lifecycle ───────────────────────────────────────────────────────

    /** Called by the base class for every entity removal (purge_dead_entities,
     *  delete_entity, etc.).  When the last Reactor entity for a matter.js node
     *  is removed, the node is decommissioned so it won't be re-created on the
     *  next restart. */
    removeEntity( entity ) {
        const nodeId   = entity.getAttribute?.( "x_matter.node_id" );
        const entityId = entity.getID();
        const wasDead  = !!entity.isDead?.();   // capture before destroy()

        super.removeEntity( entity );   // destroys the entity

        // Only decommission matter.js nodes when a dead entity is purged.
        // A live entity removed via delete_entity should be recreated on restart.
        if ( !nodeId || !wasDead ) return;

        // Update the entity list for this node; if others remain, we're done.
        const data = this._nodeMap.get( nodeId );
        if ( data ) {
            data.entityIds = data.entityIds.filter( eid => eid !== entityId );
            if ( data.entityIds.length > 0 ) return;
        }

        // All entities for this node are gone — decommission the matter.js node.
        this._nodeMap.delete( nodeId );
        this._persistedNames.delete( nodeId );
        this._splitEndpointsPrefs.delete( nodeId );
        this._saveSplitEndpointsPrefsFile();
        this.log.info( "%1 node %2 decommissioned (all dead entities purged)", this, nodeId );
        if ( this._serverNode ) {
            for ( const node of [ ...this._serverNode.peers ] ) {
                if ( String( node.id ) === nodeId ) {
                    node.delete().catch( e =>
                        this.log.warn( "%1 node %2 delete failed: %3", this, nodeId, e.message ) );
                    break;
                }
            }
        }
    }

    // ── Actions ────────────────────────────────────────────────────────────────

    /** x_matter.remove action — decommissions a Matter node (properly informing the
     *  physical device so it forgets Reactor's fabric, when reachable) and removes all
     *  Reactor entities backed by it. Works for both standalone devices and bridge/aggregator
     *  nodes (removes every sub-device entity sharing the same nodeId in one call), without
     *  needing to stop Reactor or edit storage.json by hand.
     *  params.force: if true, force-remove locally even if the device can't be reached to
     *  decommission cleanly (device will need a manual factory-reset to re-pair elsewhere). */
    async _removeMatterDevice( nodeId, params ) {
        const force = params?.force === true || params?.force === "true";
        const node = this._serverNode
            ? [ ...this._serverNode.peers ].find( n => String( n.id ) === nodeId )
            : null;

        if ( node ) {
            try {
                await node.decommission();
                this.log.notice( "%1 node %2 decommissioned (device notified)", this, nodeId );
            } catch ( err ) {
                if ( !force ) {
                    throw new Error( `Could not reach the device to decommission it cleanly (${err.message}). ` +
                        `Retry with force=true to remove it from Reactor anyway — you will likely need to ` +
                        `factory-reset the physical device manually before it can be paired elsewhere.` );
                }
                this.log.warn( "%1 node %2 unreachable — force-removing locally: %3", this, nodeId, err.message );
                await node.delete().catch( e =>
                    this.log.warn( "%1 node %2 local delete also failed: %3", this, nodeId, e.message ) );
            }
        } else {
            this.log.warn( "%1 node %2 not found among active peers — removing Reactor entities only", this, nodeId );
        }

        this._nodeMap.delete( nodeId );
        this._persistedNames.delete( nodeId );
        this._commissioningLabels.delete( nodeId );
        this._splitEndpointsPrefs.delete( nodeId );
        this._saveSplitEndpointsPrefsFile();

        // Remove every Reactor entity backed by this node (all sub-devices for a bridge/hub)
        for ( const e of Object.values( this.getEntities() ) ) {
            if ( e.getAttribute?.( "x_matter.node_id" ) === nodeId ) {
                e.markDead( true );
                this.removeEntity( e );
            }
        }
    }

    async performOnEntity( entity, actionName, parameters ) {
        if ( !entity.hasCapability( "x_matter" ) ) {
            return super.performOnEntity( entity, actionName, parameters );
        }

        const nodeId     = entity.getAttribute( "x_matter.node_id" );
        const endpointId = entity.getAttribute( "x_matter.endpoint_id" );

        if ( !nodeId ) {
            this.log.err( "%1 performOnEntity: entity %2 missing x_matter.node_id", this, entity.getID() );
            return;
        }

        try {
            const clientNode = await this._getClientNode( nodeId );
            const dot       = actionName.indexOf(".");
            const capName   = actionName.substring(0, dot);
            const actName   = actionName.substring(dot + 1);

            switch ( capName ) {
                case "power_switch":
                    await this._doOnOff( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "toggle":
                    if ( actName === "toggle" ) {
                        await this._invokeCommand( clientNode, endpointId, OnOff, "toggle", undefined );
                        // Optimistic update: flip current state
                        entity.setAttribute( "power_switch.state", !entity.getAttribute("power_switch.state") );
                    }
                    break;
                case "dimming":
                    await this._doDimming( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "color_temperature":
                    await this._doColorTemperature( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "hs_color":
                    await this._doHsColor( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "light_effect":
                    await this._doLightEffect( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "lock":
                    await this._doLock( entity, clientNode, endpointId, actName, parameters );
                    break;
                // UNTESTED (2026-09-08) — see _doCover()/_doPosition() comments.
                case "cover":
                    await this._doCover( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "position":
                    await this._doPosition( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "valve":
                    await this._doValve( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "hvac_control":
                    await this._doHvacControl( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "hvac_heating_unit":
                    await this._doHvacSetpoint( entity, clientNode, endpointId, "heating", actName, parameters );
                    break;
                case "hvac_cooling_unit":
                    await this._doHvacSetpoint( entity, clientNode, endpointId, "cooling", actName, parameters );
                    break;
                case "x_matter":
                    if ( actName === "remove" ) {
                        await this._removeMatterDevice( nodeId, parameters );
                    } else {
                        this.log.warn( "%1 performOnEntity: unknown action '%2'", this, actionName );
                    }
                    break;
                default:
                    this.log.warn( "%1 performOnEntity: unknown action '%2'", this, actionName );
            }
        } catch ( err ) {
            this.log.err( "%1 performOnEntity(%2) error: %3", this, actionName, err.message );
        }
    }

    /** x_matter_controller.commission action — commissions a new Matter device using a
     *  manual pairing code, replacing the old standalone HTTP commissioning UI. Called on
     *  the controller's system entity (see _setupSystemEntity()); base Controller.performOnEntity
     *  dispatches "x_matter_controller.commission" to this method by naming convention. */
    async action_x_matter_controller_commission( entity, params ) {
        const code  = String( params?.code || "" ).replace( /[\s-]/g, "" );
        const label = String( params?.name || "" ).trim() || "Matter Device";
        // split_endpoints: per-node choice — when true, orphan endpoints (e.g. a sibling
        // PowerSource endpoint with no device type of its own) become their own separate
        // Sensor entity instead of being merged into the node's sole functional entity.
        const splitEndpoints = !!params?.split_endpoints;

        if ( !/^\d{11}$/.test( code ) ) {
            const msg = "The code must be exactly 11 digits (hyphens are allowed).";
            entity.setAttributes({ status: "error", last_error: msg }, "x_matter_controller" );
            throw new Error( msg );
        }

        entity.setAttributes({ status: "pending", last_error: "" }, "x_matter_controller" );
        try {
            const nodeId = await this._commissionDevice( code, label, splitEndpoints );
            this.log.notice( "%1 commissioning via action succeeded: node %2", this, nodeId );
            entity.setAttributes({
                status: "ok",
                last_device_name: label,
                last_device_node_id: nodeId,
                last_error: "",
            }, "x_matter_controller" );
            return { node_id: nodeId };
        } catch ( err ) {
            this.log.err( "%1 commissioning via action failed: %2", this, err.message );
            entity.setAttributes({ status: "error", last_error: err.message }, "x_matter_controller" );
            throw err;
        }
    }

    /** sys_system.restart action — auto-attached to every controller's system entity by the
     *  base Controller class (see system_capabilities.yaml), but the base class's default
     *  implementation only logs "not implemented for this Controller class" unless a subclass
     *  overrides action_sys_system_restart (see e.g. MQTTController.js's own override). Matter
     *  needed a full stop()/start() cycle (not just a soft reconnect) since it tears down and
     *  recreates the whole matter.js ServerNode/fabric — a partial recycle wouldn't pick up
     *  e.g. a node_modules update or a config change without a full process restart anyway,
     *  but this at least re-establishes all peer connections and re-syncs every commissioned
     *  device without needing an OS-level service restart. */
    async action_sys_system_restart( entity, params ) {  // eslint-disable-line no-unused-vars
        this.log.info( "%1 performing sys_system.restart", this );
        await this.stop();
        await this.start();
    }

    // ── Private: matter.js import ─────────────────────────────────────────────

    async _importMatter() {
        // @matter/main automatically includes @matter/nodejs registration
        const m = await import( "@matter/main" );
        ServerNode  = m.ServerNode;
        Environment = m.Environment;

        // Protocol layer — ClusterClient was removed in 0.17.1; commands are sent via interaction.invoke()

        // Pairing code codec (for commissioning from Apple Home etc.)
        ({ ManualPairingCodeCodec } = await import( "@matter/types" ));

        // Cluster definitions — use @matter/main/clusters/* (package exports)
        ({ Descriptor }             = await import( "@matter/main/clusters/descriptor" ));
        ({ BasicInformation }       = await import( "@matter/main/clusters/basic-information" ));
        ({ OnOff }                  = await import( "@matter/main/clusters/on-off" ));
        ({ LevelControl }           = await import( "@matter/main/clusters/level-control" ));
        ({ TemperatureMeasurement } = await import( "@matter/main/clusters/temperature-measurement" ));
        ({ OccupancySensing }       = await import( "@matter/main/clusters/occupancy-sensing" ));
        ({ BooleanState }           = await import( "@matter/main/clusters/boolean-state" ));
        ({ PowerSource }            = await import( "@matter/main/clusters/power-source" ));
        ({ BridgedDeviceBasicInformation } = await import( "@matter/main/clusters/bridged-device-basic-information" ));
        ({ ColorControl }           = await import( "@matter/main/clusters/color-control" ));
        ({ Identify }               = await import( "@matter/main/clusters/identify" ));
        ({ DoorLock }               = await import( "@matter/main/clusters/door-lock" ));
        // UNTESTED — see comment at module-level variable declaration above.
        ({ WindowCovering }         = await import( "@matter/main/clusters/window-covering" ));
        ({ SmokeCoAlarm }           = await import( "@matter/main/clusters/smoke-co-alarm" ));
        ({ RelativeHumidityMeasurement } = await import( "@matter/main/clusters/relative-humidity-measurement" ));
        ({ PressureMeasurement }    = await import( "@matter/main/clusters/pressure-measurement" ));
        ({ FlowMeasurement }        = await import( "@matter/main/clusters/flow-measurement" ));
        ({ IlluminanceMeasurement } = await import( "@matter/main/clusters/illuminance-measurement" ));
        ({ AirQuality }             = await import( "@matter/main/clusters/air-quality" ));
        ({ ValveConfigurationAndControl } = await import( "@matter/main/clusters/valve-configuration-and-control" ));
        ({ Switch: MatterSwitch }   = await import( "@matter/main/clusters/switch" ));
        ({ FanControl }             = await import( "@matter/main/clusters/fan-control" ));
        ({ EnergyEvse }             = await import( "@matter/main/clusters/energy-evse" ));
        ({ Thermostat }             = await import( "@matter/main/clusters/thermostat" ));
        ({ ElectricalPowerMeasurement }  = await import( "@matter/main/clusters/electrical-power-measurement" ));
        ({ ElectricalEnergyMeasurement } = await import( "@matter/main/clusters/electrical-energy-measurement" ));

        // Invoke/Write builders from the protocol layer (required for the correct invoke/write
        // format to ClientInteraction) — Write/WriteResult added for Thermostat setpoint/mode writes.
        ({ Invoke, Write, WriteResult } = await import( "@matter/protocol" ));

        matterLoaded = true;
        this.log.info( "%1 matter.js loaded", this );
    }

    // ── Private: Matter server ────────────────────────────────────────────────

    async _startMatter() {
        const conf    = this.getConfig() || {};
        const confDir = Configuration.getConfig( "reactor.confdir", "string" ) ||
                        path.resolve( __dirname, "../.." );
        const storDir = path.join( confDir, `matter_${this.getID()}` );
        this._storDir = storDir;

        this.log.info( "%1 Matter storage: %2", this, storDir );

        // Load persisted device names (survive entity deletion in Reactor)
        this._loadPersistedNames();
        // Load persisted per-node split_endpoints preferences (survive entity deletion)
        this._loadSplitEndpointsPrefs();
        const env = Environment.default;
        env.vars.set( "storage.path", storDir );
        // Disable matter.js signal/exit-code handling — Reactor manages this.
        // Without these settings, ProcessManager installs its own SIGINT/SIGTERM handlers
        // that conflict with Reactor and cause the process to hang on Ctrl+C.
        env.vars.set( "runtime.signals",          false );
        env.vars.set( "runtime.exitcode",         false );
        env.vars.set( "runtime.unhandlederrors",  false );

        // Use JSON-file storage: stores all matter.js state in a single storage.json
        // instead of one file per key.  Auto-migrates from the default file format.
        const { StorageService }       = await import( "@matter/general" );
        const { JsonFileStorageDriver } = await import( "@matter/nodejs" );
        const storageSvc = env.get( StorageService );
        storageSvc.registerDriver( JsonFileStorageDriver );
        storageSvc.configuredDriver = "json";

        // controller_name = name shown in Apple Home for this controller ("Reactor")
        // fabric_label    = fabric label stored on the device ("MatterController")
        const controllerName = conf.controller_name || "Reactor";
        const fabricLabel    = conf.fabric_label    || "MatterController";

        // Create the controller ServerNode (ControllerBehavior included by default)
        this._serverNode = await ServerNode.create({
            id: `reactor-${this.getID()}`,
            network: {
                // Avoid port conflict with other Matter processes (e.g. Matterbridge) on 5540
                port: conf.port || 5541,
            },
            commissioning: {
                // This controller node should not be commissionable by others
                enabled: false,
            },
            productDescription: {
                // Shown as the controller name in Apple Home and similar apps
                name:       controllerName,
                deviceType: 0x0016,  // Root Node
            },
            basicInformation: {
                // nodeLabel = controller name displayed in Apple Home
                nodeLabel: controllerName,
            },
            controller: {
                // Fabric label stored on the device, visible in "Apps with Access"
                adminFabricLabel: fabricLabel,
                // Use random 64-bit operational node IDs instead of sequential (1, 2, 3…).
                // Sequential IDs are not persisted across restarts (nextNodeId resets to 1
                // each time), and IdentityService does not re-register peers restored from
                // storage, so the sequential allocator can hand out a NodeId that a restored
                // peer already holds — ControllerCommissioner then rejects it with
                // "Node ID N is already commissioned and can not be reused". Random IDs avoid
                // the collision entirely.
                nodeIdAssignment: "random",
            },
        });

        // Listen for nodes added by commissioning or loaded from storage
        this._serverNode.peers.added.on( node => this._onNodeAdded( node ) );

        // Start the node (initialises network, loads commissioned nodes from storage)
        await this._serverNode.start();

        this.log.info( "%1 Matter ServerNode started (controller: '%2', fabric: '%3')", this, controllerName, fabricLabel );

        // Process nodes that already exist (loaded from storage).
        // peers.added does not fire for pre-existing nodes, so lifecycle listeners are registered manually.
        // NOTE: _syncNode is NOT called here — we wait for lifecycle.online which fires once
        // the subscription is active. Listeners on a cold (unsubscribed) endpoint never fire.
        let peersFound = 0;
        for ( const node of this._serverNode.peers ) {
            peersFound++;
            this._onNodeAdded( node );   // registers lifecycle.online.on + offline.on
        }
        this.log.info( "%1 %2 existing peer(s) registered", this, peersFound );

        // Remove Reactor entities whose nodes no longer exist in matter.js storage
        this._cleanupStaleEntities();

    }

    /** Registers the x_matter_controller capability (commission action) on the
     *  controller's system entity — replaces the old standalone HTTP commissioning UI. */
    _setupSystemEntity() {
        const sys = this.getSystemEntity();
        sys.extendCapability( "x_matter_controller" );
        // status/last_error reflect an in-flight or just-finished commissioning attempt, which
        // never survives a process restart (the in-memory _commissionQueue is gone) — force them
        // back to a clean idle state on every start(), not just the first time ever. Without this,
        // a restart that happens to occur while a commission is "pending" would leave status stuck
        // on "pending" forever (nothing left to resolve it), and a stale "error" from a past
        // attempt would linger indefinitely and look like an active problem. last_device_name/
        // last_device_node_id are historical ("last device commissioned") and are NOT reset here.
        sys.setAttributes({ status: "idle", last_error: "" }, "x_matter_controller" );
    }

    /**
     * Commissions a new Matter device using a manual pairing code (11 digits)
     * obtained from e.g. Apple Home (Pair in Another Home).
     *
     * @param {string} pairingCode  11-digit manual pairing code
     * @param {string} label        Human-readable name for logging
     * @param {boolean} [splitEndpoints]  If true, orphan endpoints (e.g. a sibling PowerSource
     *   endpoint with no device type of its own) become their own separate entity instead of
     *   being merged into the node's sole functional entity. Persisted per-node.
     */
    // Serialises commissioning calls — only one at a time to avoid races
    // on the cleanup loop that removes uncommissioned nodes.
    _commissionDevice( pairingCode, label, splitEndpoints ) {
        this._commissionQueue = (this._commissionQueue || Promise.resolve())
            .catch( () => {} )   // absorb previous failure so the queue doesn't stall
            .then( () => this._doCommissionDevice( pairingCode, label, splitEndpoints ) );
        return this._commissionQueue;
    }

    async _doCommissionDevice( pairingCode, label, splitEndpoints ) {
        const clean = String(pairingCode).replace(/[^0-9]/g, "");
        this.log.info( "%1 starting commissioning for '%2' (code: %3)", this, label, clean );

        let passcode, shortDiscriminator;
        try {
            const decoded = ManualPairingCodeCodec.decode( clean );
            passcode          = decoded.passcode;
            shortDiscriminator = decoded.shortDiscriminator;
            this.log.info( "%1 decoded pairing code: passcode=%2 shortDiscriminator=%3", this, passcode, shortDiscriminator );
        } catch ( e ) {
            throw new Error( `Invalid pairing code '${clean}': ${e.message}` );
        }

        // Remove uncommissioned nodes from previous attempts to avoid cached addresses
        try {
            for ( const node of [ ...this._serverNode.peers ] ) {
                if ( !node.lifecycle.isCommissioned ) {
                    this.log.info( "%1 removing uncommissioned node %2 before retry", this, node.id );
                    await node.delete().catch( () => {} );
                }
            }
        } catch { /* ignore */ }

        // Stash the label so _onNodeAdded() can attach it to the new node the instant
        // it appears — this must happen before commission() is called since the peers.added
        // event (and the lifecycle.online-triggered first _syncNode) can fire before this
        // function's own await resolves. See _onNodeAdded() for the consuming side.
        this._pendingCommissionLabel = label;
        // Same race-avoidance stash for the split_endpoints choice — must be readable by
        // _onNodeAdded() the instant the new node object exists, before its own
        // lifecycle.online-triggered first _syncNode can fire.
        this._pendingSplitEndpoints = splitEndpoints;

        // nodes.commission() is a CancelablePromise (extends Promise) that resolves to ClientNode
        const TIMEOUT_MS = 5 * 60 * 1000;
        this.log.info( "%1 calling nodes.commission()…", this );
        const discovery = this._serverNode.peers.commission({ passcode, shortDiscriminator, regulatoryCountryCode: "XX" });

        let clientNode;
        try {
            clientNode = await Promise.race([
                discovery,
                new Promise( (_, rej) => setTimeout(
                    () => { discovery.cancel(); rej( new Error("commissioning timeout after 5 min") ); },
                    TIMEOUT_MS
                ) ),
            ]);
        } catch ( e ) {
            // Log full error including stack and inner errors
            this.log.err( "%1 commissioning error: %2", this, e.message );
            this.log.err( "%1 stack: %2", this, (e.stack || "").split("\n").slice(0,5).join(" | ") );
            if ( e.errors ) {
                e.errors.forEach( (inner, i) => {
                    const cause = inner.cause ? ` cause: ${inner.cause?.message}` : "";
                    const causeStack = inner.cause?.stack ? ` | ${inner.cause.stack.split("\n").slice(0,3).join(" | ")}` : "";
                    this.log.err( "%1 inner[%2]: %3%4%5", this, i, inner.message, cause, causeStack );
                });
            }

            // statusCode 8 = FabricConflict, 9 = LabelConflict — device is already commissioned
            // on our fabric. Find the existing node and sync it instead.
            const isFabricConflict = /addNoc.*[: ][89][,\s]/.test( e.message ) ||
                                     /statusCode.*[89]/.test( e.message ) ||
                                     e.message.includes("FabricConflict") ||
                                     e.message.includes("LabelConflict") ||
                                     e.errors?.some( inner => inner.message?.includes("already commissioned and can not be reused") );
            if ( isFabricConflict ) {
                this.log.warn( "%1 AddNOC FabricConflict — searching for existing commissioned node…", this );
                const existing = [ ...this._serverNode.peers ]
                    .filter( n => n.lifecycle.isCommissioned && !this._nodeMap.has( String(n.id) ) );
                if ( existing.length > 0 ) {
                    const node = existing[ existing.length - 1 ];
                    this.log.info( "%1 found existing node %2 — syncing", this, node.id );
                    this._commissioningLabels.set( String(node.id), label );
                    this._saveSplitEndpointsPref( String(node.id), splitEndpoints );
                    await this._syncNode( node ).catch( err =>
                        this.log.warn( "%1 _syncNode (FabricConflict-recover) failed: %2", this, err.message ) );
                    return String( node.id );
                }
                this.log.warn( "%1 no existing node found — device may already be commissioned in another session", this );
            }

            throw new Error( `Commissioning failed: ${e.message}` );
        } finally {
            // Don't let a stale label/preference leak onto some unrelated future node if this
            // attempt failed before _onNodeAdded() ever consumed it.
            this._pendingCommissionLabel = null;
            this._pendingSplitEndpoints = null;
        }

        const resultNodeId = String(clientNode.id);
        this.log.notice( "%1 device '%2' commissioned! Node ID: %3", this, label, resultNodeId );

        // Save the label from the commissioning UI so _syncNode can use it as the entity name
        this._commissioningLabels.set( resultNodeId, label );
        // Save permanently (survives entity deletion)
        this._savePersistedName( resultNodeId, label );
        // Save the split_endpoints choice permanently too (in case _onNodeAdded already
        // consumed the pending stash into a per-node preference before this point — this call
        // is idempotent and just ensures the persisted file reflects the final choice).
        this._saveSplitEndpointsPref( resultNodeId, splitEndpoints );

        // Wait briefly to let the node stabilise after CASE
        await new Promise( res => setTimeout(res, 2000) );

        // Sync the node immediately after commissioning regardless of lifecycle.isOnline —
        // isOnline may be false right after CASE but the node is still reachable.
        this.log.info( "%1 syncing node %2 immediately after commissioning (isOnline=%3)",
            this, resultNodeId, clientNode.lifecycle.isOnline );
        await this._syncNode( clientNode ).catch( e =>
            this.log.warn( "%1 _syncNode after commissioning failed: %2", this, e.message ) );

        return resultNodeId;
    }

    async _stopMatter() {
        this._nodeMap.clear();
        if ( this._serverNode ) {
            const node = this._serverNode;
            this._serverNode = null;
            try {
                // Timeout of 5s — matter.js can hang during close()
                await Promise.race([
                    node.close(),
                    new Promise( res => setTimeout(res, 5000) ),
                ]);
            } catch { /* ignore */ }
        }
    }


    _onNodeAdded( clientNode ) {
        // If a commissioning action is in flight, capture the label immediately —
        // before the very first lifecycle.online-triggered _syncNode() runs — so the
        // entity is created with the right name instead of an autoName that would
        // then win as "existingName" on every later sync.
        if ( this._pendingCommissionLabel != null ) {
            this._commissioningLabels.set( String(clientNode.id), this._pendingCommissionLabel );
            this._pendingCommissionLabel = null;
        }
        // Same race-avoidance pattern for the split_endpoints choice — must be persisted
        // before the first _syncNode() runs, since that's what decides whether orphan
        // endpoints get split off into their own entity or merged.
        if ( this._pendingSplitEndpoints != null ) {
            this._saveSplitEndpointsPref( String(clientNode.id), this._pendingSplitEndpoints );
            this._pendingSplitEndpoints = null;
        }
        clientNode.lifecycle.online.on( () => {
            this.log.notice( "%1 lifecycle.online fired for node %2 — running _syncNode", this, clientNode.id );
            this._syncNode( clientNode ).catch( e =>
                this.log.warn( "%1 _syncNode online error (node %2): %3", this, clientNode.id, e.message ) );
        });
        clientNode.lifecycle.offline.on( () => {
            this._markNodeOffline( clientNode.id );
        });
    }

    _markNodeOffline( nodeId ) {
        const data = this._nodeMap.get( String(nodeId) );
        if ( !data ) return;
        this.log.info( "%1 node %2 offline", this, nodeId );
        for ( const eid of data.entityIds ) {
            const entity = this.findEntity( eid );
            if ( entity ) entity.setAttribute( "x_matter.available", false );
        }
    }

    /** Marks entities as dead if their node no longer exists in matter.js storage. */
    _cleanupStaleEntities() {
        const knownPeerIds = new Set();
        for ( const peer of this._serverNode.peers ) {
            knownPeerIds.add( String(peer.id) );
        }
        for ( const entity of Object.values( this.getEntities() ) ) {
            if ( !entity.hasCapability( "x_matter" ) ) continue;
            const nodeId = entity.getAttribute( "x_matter.node_id" );
            if ( nodeId && !knownPeerIds.has( nodeId ) ) {
                this.log.info( "%1 removing stale entity %2 (node %3 not found)", this, entity.getID(), nodeId );
                entity.markDead( true );
            }
        }
    }

    /**
     * Reads a commissioned node's endpoints and creates/updates Reactor entities
     * and sets up subscriptions via matter.js behavior $Changed events.
     */
    async _syncNode( clientNode ) {
        const nodeIdStr  = String( clientNode.id );
        const peerAddress = clientNode.state?.commissioning?.peerAddress;

        if ( !peerAddress ) {
            this.log.warn( "%1 node %2 has no peerAddress — skipping", this, nodeIdStr );
            return;
        }

        this.log.info( "%1 syncing node %2", this, nodeIdStr );

        try {
            // Read cached state from matter.js local storage (interaction.read returns empty
            // due to version filtering once NetworkClient has subscribed and populated the cache)
            let endpointMap = this._readEndpointMapFromStorage( nodeIdStr );
            if ( !endpointMap || Object.keys( endpointMap ).length === 0 ) {
                // Fallback 1: in-memory behavior state (works immediately after commissioning)
                endpointMap = this._readEndpointMapFromLocalState( clientNode );
                if ( endpointMap ) {
                    this.log.debug( 5, "%1 _syncNode(%2) local state: %3 endpoints", this, nodeIdStr, Object.keys( endpointMap ).length );
                } else {
                    // Fallback 2: network read (e.g. if local cache is entirely absent)
                    this.log.debug( 5, "%1 _syncNode(%2) local state empty — reading from network", this, nodeIdStr );
                    const allAttrs = [];
                    for await ( const chunk of clientNode.interaction.read({ isFabricFiltered: true, includeKnownVersions: true, attributeRequests: [{}] }) ) {
                        for ( const change of chunk ) {
                            if ( change.kind === "attr-value" ) allAttrs.push( change );
                        }
                    }
                    this.log.debug( 5, "%1 _syncNode(%2) network read: %3 attr-value items", this, nodeIdStr, allAttrs.length );
                    endpointMap = this._buildEndpointMap( allAttrs );
                }
            } else {
                this.log.debug( 5, "%1 _syncNode(%2) storage: %3 endpoints", this, nodeIdStr, Object.keys( endpointMap ).length );
            }

            // Read vendorName/productName/firmwareVersion from root endpoint (ep 0), BasicInformation cluster
            let vendorName      = "Unknown";
            let productName     = "Unknown";
            let firmwareVersion = null;
            try {
                const bi = endpointMap[0]?.[BasicInformation.Cluster.id];
                if ( bi ) {
                    vendorName      = bi[1]  || vendorName;   // vendorName attribute id = 1
                    productName     = bi[3]  || productName;  // productName attribute id = 3
                    firmwareVersion = bi[10] || null;         // softwareVersionString attribute id = 10
                }
            } catch { /* ignore */ }

            const entityIds = [];

            // On bridge/aggregator devices (e.g. Matterbridge), each bridged sub-device sits
            // under a wrapper endpoint (partsList child) that carries its own distinct
            // BridgedDeviceBasicInformation.nodeLabel — build a child→parent map from every
            // endpoint's Descriptor.partsList so we can look that per-device name up below.
            // Without this, all sub-devices of the same node would otherwise share one name.
            const childToParent = {};
            for ( const [pEndpointId, pClusterMap] of Object.entries(endpointMap) ) {
                const partsList = pClusterMap[Descriptor.Cluster.id]?.[3];  // attributeId 3 = partsList
                if ( Array.isArray(partsList) ) {
                    for ( const childId of partsList ) childToParent[childId] = Number(pEndpointId);
                }
            }

            // Per-node split_endpoints preference (commission-time choice, persisted).
            // false (default) = legacy merge behavior; true = orphan endpoints become their
            // own separate entity instead of being merged into the node's sole functional entity.
            const splitEndpoints = !!this._splitEndpointsPrefs.get( nodeIdStr );

            // Some devices (e.g. several Thread door locks) put PowerSource on its own endpoint
            // with no recognizable device type of its own (Descriptor.deviceTypeList empty/unknown),
            // sibling to the endpoint carrying the actual functional cluster (e.g. DoorLock on ep1,
            // PowerSource on ep2). Collect any PowerSource attrs found anywhere in the node so they
            // can be merged into the one functional endpoint below — but only when the node has
            // exactly one entity-bearing endpoint, to avoid misattributing a shared/ambiguous
            // cluster to the wrong sub-device on multi-endpoint bridges/aggregators. This legacy
            // merge path only runs when split_endpoints is false for this node (see below).
            const nodeWidePowerSource = {};
            for ( const clusterMap of Object.values(endpointMap) ) {
                if ( clusterMap[PowerSource.Cluster.id] ) {
                    Object.assign( nodeWidePowerSource, clusterMap[PowerSource.Cluster.id] );
                }
            }

            // Pre-scan endpoints (skip ep 0 = root) to find which ones will actually become
            // entities, so we know whether it's safe to merge the node-wide bonus cluster above.
            const candidateEndpoints = [];
            for ( const [endpointId, clusterMap] of Object.entries(endpointMap) ) {
                const epId = Number(endpointId);
                if ( epId === 0 ) continue;

                // Read deviceTypeList from Descriptor cluster (cluster id 29, attr id 0)
                const descAttrs = clusterMap[Descriptor.Cluster.id];
                if ( !descAttrs ) continue;
                const deviceTypeList = descAttrs[0];  // attributeId 0 = deviceTypeList
                if ( !Array.isArray(deviceTypeList) || deviceTypeList.length === 0 ) continue;

                // Pick the best-matching config (most capabilities)
                const cfg = this._pickBestConfig( deviceTypeList );
                if ( !cfg ) continue;

                // Thermostat cluster (513) reports its own localTemperature (attr 0) instead of
                // a separate TemperatureMeasurement cluster (1026) — e.g. some floor-heating
                // thermostats have no TemperatureMeasurement cluster at all. Mirror it into the
                // TemperatureMeasurement slot so the generic temperature_sensor capability
                // handler (which only reads cluster 1026) picks it up without duplicating logic.
                // Matter spec: Thermostat.localTemperature uses the same hundredths-of-a-degree-C
                // encoding as TemperatureMeasurement.measuredValue.
                if ( cfg.capabilities?.includes( "temperature_sensor" ) && clusterMap[Thermostat.Cluster.id]?.[0] != null
                     && clusterMap[TemperatureMeasurement.Cluster.id]?.[0] == null ) {
                    clusterMap[TemperatureMeasurement.Cluster.id] = { ...(clusterMap[TemperatureMeasurement.Cluster.id] || {}), 0: clusterMap[Thermostat.Cluster.id][0] };
                }

                candidateEndpoints.push( { epId, clusterMap, cfg } );
            }

            // Orphan endpoints: any non-root endpoint that did NOT qualify as a candidateEndpoint
            // above (no recognizable device type) but exposes at least one cluster/attribute this
            // controller knows how to map to a Reactor capability (see ORPHAN_CLUSTER_CAPS). Under
            // split_endpoints=true, each becomes its own entity below instead of being merged.
            const candidateEpIds = new Set( candidateEndpoints.map( c => c.epId ) );

            // Group sibling candidateEndpoints that share the same parent endpoint AND resolve
            // to the same capability set into ONE Reactor entity, instead of one entity per
            // endpoint. This models physical multi-action devices — e.g. a Generic Switch
            // bridged as several press-type sub-endpoints for what is, physically, a single
            // button with several "scenes"/actions — as a single entity whose attributes are
            // driven by every sibling endpoint's events (see entityEndpoints below and
            // _registerStateListeners).
            //
            // IMPORTANT: restricted to Generic Switch (button) candidates only. Some bridges
            // (e.g. a zigbee2mqtt-backed Matterbridge instance) place ALL of a bridge's
            // sub-devices as flat children of a single shared aggregator endpoint, rather than
            // giving each physical device its own wrapper parent — so "same parent" alone is
            // nowhere near enough to identify genuine action-siblings of ONE device; it was
            // found to incorrectly glob together many unrelated lights/sensors that merely
            // share a device type and the aggregator as common ancestor. Generic Switch presses
            // are the one case actually needing this merge (confirmed: each physical button's
            // own press-type sub-endpoints DO have a unique immediate parent, distinct from
            // other buttons/devices), so only endpoints with the "button" capability participate.
            const parentGroups = {};
            for ( const cand of candidateEndpoints ) {
                if ( !(cand.cfg.capabilities || []).includes( "button" ) ) continue;
                const parentEpId = childToParent[cand.epId];
                if ( parentEpId === undefined ) continue;
                const capKey = `${cand.cfg.entity_type}|${(cand.cfg.capabilities || []).join(",")}`;
                const key = `${parentEpId}::${capKey}`;
                ( parentGroups[key] ||= [] ).push( cand );
            }
            const extraEndpointsByPrimary = {};   // primary epId -> [sibling epIds merged into it]
            const mergedAwayEpIds = new Set();    // sibling epIds that get no entity of their own
            for ( const group of Object.values( parentGroups ) ) {
                if ( group.length < 2 ) continue;
                group.sort( ( a, b ) => a.epId - b.epId );   // stable "primary" choice across restarts
                const [ primary, ...rest ] = group;
                extraEndpointsByPrimary[primary.epId] = rest.map( r => r.epId );
                for ( const sib of rest ) mergedAwayEpIds.add( sib.epId );
            }

            // Endpoints that are themselves the parent of one or more OTHER candidate endpoints
            // (e.g. a composed device whose own sensor/battery cluster lives alongside child
            // sub-endpoints for each press action) — used below to suffix that parent's own
            // entity name so it doesn't collide with its children's entity name.
            const parentOfOtherCandidates = new Set(
                candidateEndpoints.map( c => childToParent[c.epId] ).filter( p => p !== undefined )
            );

            // Multiple non-merged candidate siblings can share the same specific wrapper parent
            // (not the aggregator) without being Generic Switch press-pairs eligible for the
            // button-only merge above — e.g. a 2-relay module (one physical device, two separate
            // OnOffPlugInUnit sub-endpoints) plus its own Generic Switch config sub-endpoint, all
            // under one wrapper. They all inherit the exact same parent nodeLabel (deviceLabel
            // resolved from the parent, below) with nothing to tell them apart. Precompute how
            // many (non-merged-away) candidates share each parent so each can be suffixed below.
            const siblingCountByParent = {};
            for ( const cand of candidateEndpoints ) {
                if ( mergedAwayEpIds.has( cand.epId ) ) continue;
                const p = childToParent[cand.epId];
                if ( p === undefined ) continue;
                siblingCountByParent[p] = ( siblingCountByParent[p] || 0 ) + 1;
            }

            const entityEndpoints = {};   // eid -> [epId, ...] — all physical endpoints feeding this entity
            const entityParentEndpoint = {};   // eid -> parent epId (if this endpoint has one), for live PowerSource lookup

            const orphanEndpoints = [];
            if ( splitEndpoints ) {
                for ( const [endpointId, clusterMap] of Object.entries(endpointMap) ) {
                    const epId = Number(endpointId);
                    if ( epId === 0 || candidateEpIds.has(epId) ) continue;
                    const caps = [];
                    for ( const spec of ORPHAN_CLUSTER_CAPS ) {
                        if ( clusterMap[spec.clusterId]?.[spec.attrId] != null && !caps.includes( spec.capability ) ) {
                            caps.push( spec.capability );
                        }
                    }
                    if ( caps.length > 0 ) orphanEndpoints.push( { epId, clusterMap, caps } );
                }
            }

            for ( const { epId, clusterMap, cfg } of candidateEndpoints ) {
                // Folded into a sibling's entity above (see parentGroups/extraEndpointsByPrimary) —
                // no separate entity for this endpoint, its events feed the primary sibling instead.
                if ( mergedAwayEpIds.has( epId ) ) continue;

                // Legacy merge: only when this node has split_endpoints off, exactly one candidate
                // endpoint, and no PowerSource of its own already — unchanged from before.
                if ( !splitEndpoints && candidateEndpoints.length === 1 && !clusterMap[PowerSource.Cluster.id]
                     && Object.keys( nodeWidePowerSource ).length > 0 ) {
                    clusterMap[PowerSource.Cluster.id] = nodeWidePowerSource;
                }

                const parentEpId = childToParent[epId];

                // Generic Switch sub-endpoints (and other merged-sibling groups) typically carry
                // no PowerSource cluster of their own — the battery lives on the shared parent
                // wrapper endpoint instead (e.g. "Mini Switch källaren"'s ep20 has PowerSource,
                // its press-type children ep21/ep22 do not). Merge the parent's PowerSource into
                // the primary merged entity's clusterMap so the existing battery_power/
                // voltage_sensor auto-detect in _createOrUpdateEntity (and the sibling-endpoint
                // search in _registerStateListeners) picks it up, same as the single-candidate
                // "legacy merge" above but for this multi-entity-per-node case.
                if ( extraEndpointsByPrimary[epId] && parentEpId !== undefined && !clusterMap[PowerSource.Cluster.id]
                     && endpointMap[parentEpId]?.[PowerSource.Cluster.id] ) {
                    clusterMap[PowerSource.Cluster.id] = endpointMap[parentEpId][PowerSource.Cluster.id];
                }

                // Per-device name from the bridged wrapper endpoint's BridgedDeviceBasicInformation,
                // if any (only present for bridge/aggregator sub-devices, not standalone devices)
                let deviceLabel = null;
                let labelFromParent = false;
                if ( parentEpId !== undefined ) {
                    deviceLabel = endpointMap[parentEpId]?.[BridgedDeviceBasicInformation.Cluster.id]?.[5] || null;
                    if ( deviceLabel ) labelFromParent = true;
                }

                // Some bridges (e.g. a zigbee2mqtt-backed Matterbridge instance) put
                // BridgedDeviceBasicInformation directly on the SAME endpoint as the device's own
                // functional clusters instead of on a separate wrapper/parent endpoint — fall back
                // to the endpoint's own label when no parent-provided one was found above. Without
                // this, such devices fall through to the node-level persistedName/uiLabel (i.e. the
                // whole bridge's commissioning-time name) for every single sub-device.
                if ( !deviceLabel ) {
                    deviceLabel = clusterMap[BridgedDeviceBasicInformation.Cluster.id]?.[5] || null;
                }

                // Disambiguate non-merged siblings that share one wrapper parent's label (see
                // siblingCountByParent above) — e.g. relay 1 / relay 2 / config-switch of one
                // physical device all reporting the same parent nodeLabel. Only applies when the
                // label actually came FROM that specific parent (labelFromParent) — most endpoints
                // on this kind of bridge merely share the top-level aggregator as a common
                // ancestor (not a genuine per-device wrapper) and already get their own distinct
                // label via the own-endpoint fallback above, so they must NOT be suffixed here.
                // Prefer this endpoint's own Descriptor TagList label (cluster 29, attr 4 —
                // semantic tag, e.g. "endpoint l1"/"switch_1") when present, falling back to this
                // entity's own type_label, so each sibling gets a distinct, meaningful name
                // instead of colliding.
                if ( deviceLabel && labelFromParent && (siblingCountByParent[parentEpId] || 0) > 1 ) {
                    const tagList = clusterMap[Descriptor.Cluster.id]?.[4];
                    const tagLabel = Array.isArray(tagList) && tagList.length > 0 ? tagList[0]?.label : null;
                    const suffix = tagLabel || cfg.type_label;
                    if ( suffix ) deviceLabel = `${deviceLabel} ${suffix}`;
                }

                // If this endpoint is itself the parent of one or more OTHER candidate endpoints
                // (e.g. a composed device whose own temperature/battery cluster lives alongside
                // child Generic Switch sub-endpoints for each press action), its name would
                // otherwise collide with its children's entity name (same inherited nodeLabel).
                // Suffix with this entity's own type_label to disambiguate — mirrors the existing
                // split_endpoints main-entity-suffix pattern below.
                if ( deviceLabel && parentOfOtherCandidates.has( epId ) && cfg.type_label ) {
                    deviceLabel = `${deviceLabel} ${cfg.type_label}`;
                }

                // When a split actually occurred on this node (at least one orphan endpoint was
                // split into its own entity) AND this is the sole main/functional entity on a
                // standalone (non-bridge) device, append this entity's own type_label to its name
                // too — e.g. "Entrédörr" + "Door Lock" — so it's clearly distinguishable from the
                // split-off sibling (e.g. "Entrédörr Battery / Voltage") rather than looking like an
                // unlabeled/default entity next to a labeled one. Only applies when a split actually
                // happened; otherwise the main entity keeps its plain, unsuffixed name as always.
                if ( !deviceLabel && orphanEndpoints.length > 0 && candidateEndpoints.length === 1 && cfg.type_label ) {
                    const nodeLevelName = this._persistedNames.get( nodeIdStr ) || this._commissioningLabels.get( nodeIdStr );
                    if ( nodeLevelName ) deviceLabel = `${nodeLevelName} ${cfg.type_label}`;
                }

                const eid = this._makeEntityId( nodeIdStr, epId );
                try {
                    this._createOrUpdateEntity( eid, nodeIdStr, epId, cfg, vendorName, productName,
                                                firmwareVersion, clusterMap, deviceLabel );
                    entityIds.push( eid );
                    if ( parentEpId !== undefined ) entityParentEndpoint[eid] = parentEpId;
                    if ( extraEndpointsByPrimary[epId] ) {
                        entityEndpoints[eid] = [ epId, ...extraEndpointsByPrimary[epId] ];
                        this.log.info( "%1 merged sibling endpoint(s) %2 into entity %3 (%4) — same physical device, multiple actions",
                            this, extraEndpointsByPrimary[epId].join(","), eid, cfg.type_label || cfg.entity_type );
                    }
                } catch ( e ) {
                    this.log.warn( "%1 could not create entity %2: %3", this, eid, e.message );
                }
            }

            // Create a separate entity for each orphan endpoint (split_endpoints=true only).
            // These get a synthetic cfg (no matter_devices.yaml entry exists for a device-type-less
            // endpoint) built from whichever capabilities its clusters matched in ORPHAN_CLUSTER_CAPS.
            const CAP_LABELS = { battery_power: "Battery", voltage_sensor: "Voltage" };
            for ( const { epId, clusterMap, caps } of orphanEndpoints ) {
                const suffix = caps.map( c => CAP_LABELS[c] || c ).join(" / ");

                let deviceLabel = null;
                const parentEpId = childToParent[epId];
                if ( parentEpId !== undefined ) {
                    const parentLabel = endpointMap[parentEpId]?.[BridgedDeviceBasicInformation.Cluster.id]?.[5] || null;
                    if ( parentLabel ) deviceLabel = `${parentLabel} ${suffix}`;
                }
                // Some bridges put BridgedDeviceBasicInformation directly on the orphan endpoint
                // itself rather than a separate parent — fall back to that before falling further
                // back to the node-level name below.
                if ( !deviceLabel ) {
                    const ownLabel = clusterMap[BridgedDeviceBasicInformation.Cluster.id]?.[5] || null;
                    if ( ownLabel ) deviceLabel = `${ownLabel} ${suffix}`;
                }
                // Standalone (non-bridge) device: there's no per-endpoint BridgedDeviceBasicInformation
                // label to fall back to, so persistedName/uiLabel (both keyed per NODE, not per
                // endpoint) would otherwise win via _createOrUpdateEntity's naming priority and give
                // this orphan entity the exact same name as the main functional entity. Build a
                // "<node name> <suffix>" label instead so it ranks ahead of those in the priority
                // chain (existingName || deviceLabel || persistedName || uiLabel || ...).
                if ( !deviceLabel ) {
                    const nodeLevelName = this._persistedNames.get( nodeIdStr ) || this._commissioningLabels.get( nodeIdStr );
                    if ( nodeLevelName ) deviceLabel = `${nodeLevelName} ${suffix}`;
                }

                const orphanCfg = {
                    entity_type:   "Sensor",
                    capabilities:  caps,
                    type_label:    suffix,
                    default_name:  `${vendorName} ${productName} ${suffix} (${nodeIdStr}:${epId})`,
                };

                const eid = this._makeEntityId( nodeIdStr, epId );
                try {
                    this._createOrUpdateEntity( eid, nodeIdStr, epId, orphanCfg, vendorName, productName,
                                                firmwareVersion, clusterMap, deviceLabel );
                    entityIds.push( eid );
                    this.log.info( "%1 split_endpoints: created separate entity %2 for orphan endpoint %3 (%4)",
                        this, eid, epId, suffix );
                } catch ( e ) {
                    this.log.warn( "%1 could not create split entity %2: %3", this, eid, e.message );
                }
            }

            // Update the node map and clear any commissioning label
            this._nodeMap.set( nodeIdStr, { peerAddress, entityIds, entityEndpoints, entityParentEndpoint } );
            this._commissioningLabels.delete( nodeIdStr );

            // Register listeners on behavior events (matter.js auto-subscribes; we only
            // need to listen on the $Changed events, no separate subscription required)
            this._registerStateListeners( clientNode, nodeIdStr );

            this.log.info( "%1 node %2 synced (%3 entity/-ies)", this, nodeIdStr, entityIds.length );

        } catch ( err ) {
            this.log.err( "%1 _syncNode(%2) error: %3", this, nodeIdStr, err.message );
            throw err;
        }
    }

    // ── Private: Entity management ───────────────────────────────────────────────

    _createOrUpdateEntity( entityId, nodeIdStr, endpointId, cfg, vendorName, productName, firmwareVersion, clusterMap, deviceLabel ) {
        const entity = this.getEntity( cfg.entity_type || "Switch", entityId );
        entity.deferNotifies( true );

        try {
            // Mark as available (node is online when we sync)
            entity.setAttribute( "x_matter.available", true );

            // Name priority: existing name (restart) always wins so user renames survive.
            // Otherwise prefer the per-device bridged label (e.g. Matterbridge's name for this
            // specific sub-device). persistedName/uiLabel are keyed per NODE (one name per whole
            // Matter node, from matter-names.json / the commissioning UI input) — fine for
            // single-device nodes, but must rank below deviceLabel, or every sub-device of a
            // bridge/aggregator would get the same node-level name again.
            const uiLabel        = this._commissioningLabels.get( nodeIdStr );
            const existingName   = entity.getAttribute( "x_matter.node_id" ) ? entity.getName() : null;
            const persistedName  = this._persistedNames.get( nodeIdStr );
            const autoName       = `${vendorName} ${productName} (${nodeIdStr}:${endpointId})`;
            entity.setName( existingName || deviceLabel || persistedName || uiLabel || cfg.default_name || autoName );

            // Extend capabilities — start from the device-type's declared list, then
            // opportunistically auto-add any capability we know how to map from a cluster
            // that's actually present on this endpoint, regardless of the device type/YAML
            // (e.g. a battery-powered lock/sensor exposes PowerSource even though
            // matter_devices.yaml's capability list for its primary device type doesn't
            // mention battery_power). Keep this list small — only clusters we have fully
            // working read/write/listener code for, to avoid exposing dead attributes.
            const capsList = [...(cfg.capabilities || [])];
            if ( clusterMap[PowerSource.Cluster.id]?.[12] != null && !capsList.includes( "battery_power" ) ) {
                capsList.push( "battery_power" );
            }
            // batVoltage (attr 11, mV) maps directly onto the standard voltage_sensor
            // (alias of value_sensor) capability — same opportunistic auto-detect pattern
            // as battery_power above.
            if ( clusterMap[PowerSource.Cluster.id]?.[11] != null && !capsList.includes( "voltage_sensor" ) ) {
                capsList.push( "voltage_sensor" );
            }
            // Identify.TriggerEffect (Blink/Breathe/Okay/ChannelChange) maps onto Reactor's
            // standard light_effect capability — only meaningful on actual lights (see
            // LIGHT_DEVICE_TYPES above): a plain on/off plug/relay also implements Identify
            // (mandatory on every Matter device) but has no dimmable/visual output of its own to
            // perform an effect on, so gate on both power_switch AND the device type being a light.
            if ( clusterMap[Identify.Cluster.id]?.[1] != null && capsList.includes( "power_switch" )
                 && LIGHT_DEVICE_TYPES.has( Number( cfg.device_type_id ) )
                 && !capsList.includes( "light_effect" ) ) {
                capsList.push( "light_effect" );
            }
            // Thermostat.featureMap (attr 65532) tells us which of Heating/Cooling this specific
            // device actually supports — a heat-only floor-heating thermostat (e.g. "Golvvärme
            // hallen") has no Cooling feature bit, so don't expose an hvac_cooling_unit that could
            // never populate any real attribute. Only filters hvac_heating_unit/hvac_cooling_unit
            // that matter_devices.yaml already declared for this device type; never adds them.
            const thermostatFeatures = clusterMap[Thermostat.Cluster.id]?.[65532];
            if ( thermostatFeatures ) {
                if ( thermostatFeatures.cooling !== true ) {
                    const i = capsList.indexOf( "hvac_cooling_unit" );
                    if ( i !== -1 ) capsList.splice( i, 1 );
                }
                if ( thermostatFeatures.heating !== true ) {
                    const i = capsList.indexOf( "hvac_heating_unit" );
                    if ( i !== -1 ) capsList.splice( i, 1 );
                }
            }
            const caps = [...capsList, "x_matter"];
            entity.extendCapabilities( caps, true );

            // Hide capability actions that have no feasible Matter implementation, so the UI
            // doesn't offer controls that silently do nothing. `registerAction(name, false)` is
            // a core Reactor Entity API (also used by MQTTController's template "enabled: false"
            // actions) — not something specific to this plugin.
            if ( capsList.includes( "energy_sensor" ) ) {
                // ElectricalEnergyMeasurement has no "reset cumulative counter" command in the
                // Matter spec — nothing for this to invoke.
                entity.registerAction( "energy_sensor.reset", false );
            }
            if ( capsList.includes( "button" ) ) {
                // This is a passive, physical battery-powered button — it can't be "pressed"
                // from the UI, only report live events from the real device.
                for ( const act of [ "press", "single", "double", "hold", "release", "long" ] ) {
                    entity.registerAction( `button.${act}`, false );
                }
            }
            if ( capsList.includes( "ev_charger" ) ) {
                // EV charger support is currently read-only (state only) — writing
                // current/operating-mode/schedule to the EnergyEvse cluster isn't implemented.
                for ( const act of [ "set_current", "set_operating_mode", "set_schedule" ] ) {
                    entity.registerAction( `ev_charger.${act}`, false );
                }
            }
            if ( capsList.includes( "light_effect" ) ) {
                // Identify.TriggerEffect has no speed/duration parameters — the device itself
                // decides the timing of each effect, so these two arguments have nothing to map to.
                entity.registerAction( "light_effect.set_speed", false );
                entity.registerAction( "light_effect.set_duration", false );
            }

            // Matter metadata
            entity.setAttribute( "x_matter.node_id",     nodeIdStr );
            entity.setAttribute( "x_matter.endpoint_id", endpointId );
            entity.setAttribute( "x_matter.vendor_name",  vendorName );
            entity.setAttribute( "x_matter.product_name", productName );
            if ( firmwareVersion != null ) {
                entity.setAttribute( "x_matter.firmware_version", firmwareVersion );
            }
            entity.setAttribute( "x_matter.device_type",
                cfg.type_label || "0x" + (cfg.device_type_id || 0).toString(16).toUpperCase().padStart(4, "0") );

            // Primary attribute for UI
            if ( cfg.primary_attribute ) {
                try { entity.setPrimaryAttribute( cfg.primary_attribute ); } catch { /* ignore */ }
            }

            // Apply initial attribute values from already-read data
            this._applyClusterValues( entity, clusterMap, capsList );

        } finally {
            entity.deferNotifies( false );
        }
    }

    /** Applies cluster attribute values (from initial sync) to an entity. */
    _applyClusterValues( entity, clusterMap, capabilities ) {
        for ( const cap of capabilities ) {
            try {
                switch ( cap ) {
                    case "power_switch": {
                        const v = clusterMap[OnOff.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "power_switch.state", Boolean(v) );
                        break;
                    }
                    case "dimming": {
                        const v = clusterMap[LevelControl.Cluster.id]?.[0];
                        if ( v != null ) {
                            entity.setAttribute( "dimming.level", Math.round( v / 254 * 100 ) / 100 );
                            entity.setAttribute( "dimming.step",  0.1 );
                        }
                        break;
                    }
                    case "color_temperature": {
                        // colorTemperatureMireds attr id 7 → Kelvin
                        const v = clusterMap[768]?.[7];
                        if ( v != null && v > 0 )
                            entity.setAttribute( "color_temperature.value", Math.round( 1_000_000 / v ) );
                        break;
                    }
                    case "hs_color": {
                        // currentHue/currentSaturation (attr ids 0/1) are Matter's 0-254 scale —
                        // hs_color expects hue in degrees (0-360) and saturation as a 0-1 fraction.
                        const hue = clusterMap[768]?.[0];
                        const sat = clusterMap[768]?.[1];
                        if ( hue != null ) entity.setAttribute( "hs_color.hue", Math.round( hue * 360 / 254 ) );
                        if ( sat != null ) entity.setAttribute( "hs_color.saturation", Math.round( sat / 254 * 100 ) / 100 );
                        break;
                    }
                    case "light_effect": {
                        // Identify.TriggerEffect is a fire-and-forget command — there's no
                        // readable "current effect" attribute on the device, so just default to
                        // "not running" on initial sync (updated optimistically by _doLightEffect).
                        entity.setAttribute( "light_effect.current", "" );
                        break;
                    }
                    case "temperature_sensor": {
                        const v = clusterMap[TemperatureMeasurement.Cluster.id]?.[0];
                        if ( v != null ) {
                            entity.setAttribute( "temperature_sensor.value", v / 100 );
                            entity.setAttribute( "temperature_sensor.units", "°C" );
                        }
                        break;
                    }
                    case "hvac_control": {
                        const tc = clusterMap[Thermostat.Cluster.id];
                        if ( tc?.[28] != null ) entity.setAttribute( "hvac_control.mode", _hvacModeToString( tc[28] ) );
                        if ( tc ) entity.setAttribute( "hvac_control.state", _hvacStateToString( tc[28], tc[41] ) );
                        break;
                    }
                    case "hvac_heating_unit": {
                        const tc = clusterMap[Thermostat.Cluster.id];
                        if ( tc?.[18] != null ) entity.setAttribute( "hvac_heating_unit.setpoint", tc[18] / 100 );
                        if ( tc ) entity.setAttribute( "hvac_heating_unit.state", Boolean( tc[41]?.heat ) );
                        entity.setAttribute( "hvac_heating_unit.units", "°C" );
                        break;
                    }
                    case "hvac_cooling_unit": {
                        const tc = clusterMap[Thermostat.Cluster.id];
                        if ( tc?.[17] != null ) entity.setAttribute( "hvac_cooling_unit.setpoint", tc[17] / 100 );
                        if ( tc ) entity.setAttribute( "hvac_cooling_unit.state", Boolean( tc[41]?.cool ) );
                        entity.setAttribute( "hvac_cooling_unit.units", "°C" );
                        break;
                    }
                    case "motion_sensor": {
                        // motion_sensor is a core Reactor alias of binary_sensor — its attribute
                        // is "state", not "tripped" (which doesn't exist in the capability schema).
                        // matter.js decodes the Occupancy bitmap into a struct ({occupied: bool}),
                        // not a raw integer — read .occupied directly, don't bit-mask it.
                        const v = clusterMap[OccupancySensing.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "motion_sensor.state", Boolean(v?.occupied ?? v) );
                        break;
                    }
                    case "door_sensor": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "door_sensor.state", Boolean(v) );
                        break;
                    }
                    case "binary_sensor": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "binary_sensor.state", Boolean(v) );
                        break;
                    }
                    case "battery_power": {
                        const v = clusterMap[PowerSource.Cluster.id]?.[12];
                        if ( v != null ) entity.setAttribute( "battery_power.level", v / 200 );
                        break;
                    }
                    case "voltage_sensor": {
                        // Battery voltage (PowerSource.batVoltage) and mains voltage
                        // (ElectricalPowerMeasurement.voltage) are mutually exclusive in
                        // practice (a device is either battery-powered or mains-metered) — both
                        // are reported in millivolts, convert to volts, prefer whichever is
                        // actually present on this endpoint.
                        const v = clusterMap[PowerSource.Cluster.id]?.[11]
                                  ?? clusterMap[ElectricalPowerMeasurement.Cluster.id]?.[4];
                        if ( v != null ) {
                            entity.setAttribute( "voltage_sensor.value", v / 1000 );
                            entity.setAttribute( "voltage_sensor.units", "V" );
                        }
                        break;
                    }
                    case "power_sensor": {
                        // ElectricalPowerMeasurement.activePower is reported in milliwatts
                        const v = clusterMap[ElectricalPowerMeasurement.Cluster.id]?.[8];
                        if ( v != null ) {
                            entity.setAttribute( "power_sensor.value", v / 1000 );
                            entity.setAttribute( "power_sensor.units", "W" );
                        }
                        break;
                    }
                    case "current_sensor": {
                        // ElectricalPowerMeasurement.activeCurrent is reported in milliamps
                        const v = clusterMap[ElectricalPowerMeasurement.Cluster.id]?.[5];
                        if ( v != null ) {
                            entity.setAttribute( "current_sensor.value", v / 1000 );
                            entity.setAttribute( "current_sensor.units", "A" );
                        }
                        break;
                    }
                    case "energy_sensor": {
                        // ElectricalEnergyMeasurement.cumulativeEnergyImported is a struct;
                        // its .energy field is reported in milliwatt-hours — convert to kWh.
                        const v = clusterMap[ElectricalEnergyMeasurement.Cluster.id]?.[1]?.energy;
                        if ( v != null ) {
                            entity.setAttribute( "energy_sensor.value", v / 1_000_000 );
                            entity.setAttribute( "energy_sensor.units", "kWh" );
                        }
                        break;
                    }
                    case "lock": {
                        // LockState enum: 0=NotFullyLocked, 1=Locked, 2=Unlocked, 3=Unlatched
                        const v = clusterMap[DoorLock.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "lock.state", v === 1 );
                        break;
                    }
                    // ── UNTESTED (2026-09-08) — no physical device available to verify yet.
                    // In particular the percent100ths direction (0=open/10000=closed per spec)
                    // and the "position.value" 0..1 convention (open=1 assumed here — CONFIRM
                    // against Reactor's other position-capability controllers, e.g. Zwave, once
                    // a real device exists) need checking against a real Window Covering device.
                    case "cover": {
                        const v = clusterMap[WindowCovering.Cluster.id]?.[14];
                        if ( v != null ) entity.setAttribute( "cover.state", v < 10000 );
                        break;
                    }
                    case "position": {
                        const v = clusterMap[WindowCovering.Cluster.id]?.[14];
                        if ( v != null ) entity.setAttribute( "position.value", Math.round( (10000 - v) / 100 ) / 100 );
                        break;
                    }
                    // UNTESTED (2026-09-08) — AlarmStateEnum semantics (Normal/Warning/Critical)
                    // assumed per spec; no physical smoke/CO alarm available to verify.
                    case "smoke_detector": {
                        const v = clusterMap[SmokeCoAlarm.Cluster.id]?.[1];
                        if ( v != null ) entity.setAttribute( "smoke_detector.state", v !== 0 );
                        break;
                    }
                    case "co_detector": {
                        const v = clusterMap[SmokeCoAlarm.Cluster.id]?.[2];
                        if ( v != null ) entity.setAttribute( "co_detector.state", v !== 0 );
                        break;
                    }
                    // ── UNTESTED (2026-09-08) — all cases below prepared from matter.js cluster
                    // specs only, no physical devices available yet to verify. Verify carefully
                    // the first time a real device of each type is commissioned (units, enum
                    // semantics, and sign conventions all need confirming against real hardware —
                    // the spec is not always followed consistently by vendors).
                    case "humidity_sensor": {
                        const v = clusterMap[RelativeHumidityMeasurement.Cluster.id]?.[0];
                        if ( v != null ) {
                            entity.setAttribute( "humidity_sensor.value", v / 100 );
                            entity.setAttribute( "humidity_sensor.units", "%" );
                        }
                        break;
                    }
                    case "pressure_sensor": {
                        // Spec: MeasuredValue = 10 x Pressure[kPa], which is numerically the same
                        // as Pressure[hPa] (1 kPa = 10 hPa) — report directly in hPa, no division.
                        const v = clusterMap[PressureMeasurement.Cluster.id]?.[0];
                        if ( v != null ) {
                            entity.setAttribute( "pressure_sensor.value", v );
                            entity.setAttribute( "pressure_sensor.units", "hPa" );
                        }
                        break;
                    }
                    case "value_sensor": {
                        // Flow sensor. Spec: MeasuredValue = 10 x Flow[m3/h] — CONFIRM units.
                        // value_sensor is a generic Reactor capability (no fixed physical
                        // quantity), reused here only because there's no dedicated flow_sensor
                        // capability — deliberately NOT setting a default ".units" string, since
                        // that would be wrong for any other future use of this generic capability.
                        const v = clusterMap[FlowMeasurement.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "value_sensor.value", v / 10 );
                        break;
                    }
                    case "light_sensor": {
                        // Spec formula: MeasuredValue = 10000 * log10(lux) + 1 → invert to get lux.
                        const v = clusterMap[IlluminanceMeasurement.Cluster.id]?.[0];
                        if ( v != null && v > 0 ) {
                            entity.setAttribute( "light_sensor.value", Math.round( 10 ** ( (v - 1) / 10000 ) ) );
                            entity.setAttribute( "light_sensor.units", "lx" );
                        }
                        break;
                    }
                    case "air_quality_sensor": {
                        // AirQualityEnum: 0=Unknown,1=Good,2=Fair,3=Moderate,4=Poor,5=VeryPoor,6=ExtremelyPoor
                        // Stored as-is (0-6); CONFIRM this raw enum is a sensible ".value" for
                        // Reactor UI/rules, or whether it should be translated to a % / AQI scale.
                        const v = clusterMap[AirQuality.Cluster.id]?.[0];
                        if ( v != null ) {
                            entity.setAttribute( "air_quality_sensor.value", v );
                            entity.setAttribute( "air_quality_sensor.units", "" );
                        }
                        break;
                    }
                    case "leak_detector": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "leak_detector.state", Boolean(v) );
                        break;
                    }
                    case "freeze_detector": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "freeze_detector.state", Boolean(v) );
                        break;
                    }
                    case "valve": {
                        // ValveStateEnum: 0=Closed, 1=Open, 2=Transitioning
                        const v = clusterMap[ValveConfigurationAndControl.Cluster.id]?.[4];
                        if ( v != null ) entity.setAttribute( "valve.state", v === 1 );
                        break;
                    }
                    case "button": {
                        // GenericSwitch is event-driven (initialPress/shortRelease/longPress/...),
                        // not attribute-state driven — this only covers the initial full sync
                        // (current position at commissioning time). See _registerStateListeners()
                        // for the live Switch-cluster-Event → button.state mapping, confirmed
                        // working 2026-10-09.
                        const v = clusterMap[MatterSwitch.Cluster.id]?.[1];
                        if ( v != null ) entity.setAttribute( "button.state", v > 0 ? "single" : "release" );
                        break;
                    }
                    case "ev_charger": {
                        // EnergyEvse.State enum — approximate mapping to ev_charger.state strings.
                        // READ-ONLY: set_current/set_operating_mode/set_schedule are NOT implemented,
                        // see DEVICE_MAP comment near 0x050C for why.
                        const v = clusterMap[EnergyEvse.Cluster.id]?.[0];
                        if ( v != null ) {
                            const STATE_MAP = {
                                0: "not connected", 1: "ready", 2: "ready",
                                3: "charging", 4: "charging", 5: "suspended", 6: "fault",
                            };
                            entity.setAttribute( "ev_charger.state", STATE_MAP[v] ?? "fault" );
                        }
                        break;
                    }
                }
            } catch { /* ignore individual read errors */ }
        }
    }

    // ── Private: Subscriptions ────────────────────────────────────────────────

    /**
     * Registers listeners on matter.js behavior $Changed events for all known endpoints.
     * matter.js maintains an automatic subscription — no separate subscription is needed.
     *
     * Covers all clusters in BEHAVIOR_MAP so Reactor entities are updated in real time:
     * on/off, dimming, color temperature, temperature, occupancy, boolean state, battery.
     */
    _registerStateListeners( clientNode, nodeIdStr ) {
        const data = this._nodeMap.get( nodeIdStr );
        if ( !data ) return;

        for ( const eid of data.entityIds ) {
            const entity = this.findEntity( eid );
            if ( !entity ) continue;
            const primaryEndpointId = entity.getAttribute( "x_matter.endpoint_id" );
            if ( primaryEndpointId == null ) continue;

            // Normally just this entity's own endpoint. A multi-action device bridged as
            // several sibling sub-endpoints under one parent (e.g. a Generic Switch exposed as
            // one Matter endpoint per press-type) is folded into a single Reactor entity at
            // sync time (see "parentGroups"/entityEndpoints in _syncNode) — listen on every
            // endpoint it was folded from so all of them drive this one entity's attributes.
            const endpointIds = data.entityEndpoints?.[eid] || [ primaryEndpointId ];

            for ( const endpointId of endpointIds ) {

                let ep;
                try { ep = clientNode.endpoints.for( endpointId ); } catch { continue; }

                const apply = ( clusterId, attributeId ) => ( value ) => {
                    const e = this.findEntity( eid );
                    if ( !e ) return;
                    e.deferNotifies( true );
                    try { this._applyOneAttribute( e, clusterId, attributeId, value ); }
                    finally { e.deferNotifies( false ); }
                };

                const ev = ep.events;

                // If this entity has battery_power or voltage_sensor (possibly auto-detected
                // from a *sibling* endpoint — see _createOrUpdateEntity — and this endpoint
                // itself has no powerSource behavior), find the endpoint that actually carries
                // PowerSource and listen there instead, so live updates still reach this entity.
                // Prefer the entity's known parent endpoint (e.g. a Generic Switch pair's shared
                // wrapper endpoint, which holds the battery for a multi-endpoint/multi-entity
                // bridge node) when known; otherwise fall back to scanning all sibling endpoints,
                // but only when this node has exactly one entity in total (the original,
                // narrower single-device-with-sibling-PowerSource case, e.g. a standalone
                // Thread door lock — safe since there's no other device on the node to confuse
                // it with).
                let powerEv = ev;
                if ( ( entity.hasCapability( "battery_power" ) || entity.hasCapability( "voltage_sensor" ) )
                     && !ev?.powerSource ) {
                    const parentEpId = data.entityParentEndpoint?.[eid];
                    if ( parentEpId !== undefined && parentEpId !== endpointId ) {
                        try {
                            const parentEp = clientNode.endpoints.for( parentEpId );
                            if ( parentEp?.events?.powerSource ) powerEv = parentEp.events;
                        } catch { /* parent endpoint not available — fall through */ }
                    }
                    if ( !powerEv?.powerSource && data.entityIds.length === 1 ) {
                        for ( const sibling of clientNode.endpoints ) {
                            if ( !sibling || sibling.number === endpointId ) continue;
                            if ( sibling.events?.powerSource ) { powerEv = sibling.events; break; }
                        }
                    }
                }

                // OnOff cluster (6)
                ev?.onOff?.onOff$Changed                            ?.on( apply( OnOff.Cluster.id, 0 ) );
                ev?.levelControl?.currentLevel$Changed              ?.on( apply( LevelControl.Cluster.id, 0 ) );

                // ColorControl cluster (768) — color temperature + XY + Hue/Saturation
                ev?.colorControl?.colorTemperatureMireds$Changed    ?.on( apply( 768, 7 ) );
                ev?.colorControl?.colorMode$Changed                 ?.on( apply( 768, 8 ) );
                ev?.colorControl?.currentX$Changed                  ?.on( apply( 768, 3 ) );
                ev?.colorControl?.currentY$Changed                  ?.on( apply( 768, 4 ) );
                ev?.colorControl?.currentHue$Changed                ?.on( apply( 768, 0 ) );
                ev?.colorControl?.currentSaturation$Changed         ?.on( apply( 768, 1 ) );

                // TemperatureMeasurement cluster (1026)
                ev?.temperatureMeasurement?.measuredValue$Changed   ?.on( apply( TemperatureMeasurement.Cluster.id, 0 ) );

                // Thermostat cluster (513) — devices with no separate TemperatureMeasurement
                // cluster (e.g. some floor-heating thermostats) report temperature only via
                // localTemperature; feed it into the same TemperatureMeasurement slot the
                // generic temperature_sensor handler reads (see matching mirror in _syncNode).
                ev?.thermostat?.localTemperature$Changed            ?.on( apply( TemperatureMeasurement.Cluster.id, 0 ) );
                // Mode/state/setpoint for extended Thermostat support (hvac_control/hvac_heating_unit/
                // hvac_cooling_unit) — dispatched through _applyOneAttribute's own Thermostat.Cluster.id case.
                ev?.thermostat?.systemMode$Changed                  ?.on( apply( Thermostat.Cluster.id, 28 ) );
                ev?.thermostat?.thermostatRunningState$Changed      ?.on( apply( Thermostat.Cluster.id, 41 ) );
                ev?.thermostat?.occupiedHeatingSetpoint$Changed     ?.on( apply( Thermostat.Cluster.id, 18 ) );
                ev?.thermostat?.occupiedCoolingSetpoint$Changed     ?.on( apply( Thermostat.Cluster.id, 17 ) );

                // OccupancySensing cluster (1030)
                ev?.occupancySensing?.occupancy$Changed             ?.on( apply( OccupancySensing.Cluster.id, 0 ) );

                // BooleanState cluster (69)
                ev?.booleanState?.stateValue$Changed                ?.on( apply( BooleanState.Cluster.id, 0 ) );

                // PowerSource cluster (47) — batteri (own endpoint, or sibling — see powerEv above)
                powerEv?.powerSource?.batPercentRemaining$Changed   ?.on( apply( PowerSource.Cluster.id, 12 ) );
                powerEv?.powerSource?.status$Changed                ?.on( apply( PowerSource.Cluster.id, 0 ) );
                powerEv?.powerSource?.batVoltage$Changed            ?.on( apply( PowerSource.Cluster.id, 11 ) );

                // ElectricalPowerMeasurement cluster (144) / ElectricalEnergyMeasurement (145)
                // — mains power metering (e.g. a metering smart plug/relay)
                ev?.electricalPowerMeasurement?.voltage$Changed      ?.on( apply( ElectricalPowerMeasurement.Cluster.id, 4 ) );
                ev?.electricalPowerMeasurement?.activeCurrent$Changed ?.on( apply( ElectricalPowerMeasurement.Cluster.id, 5 ) );
                ev?.electricalPowerMeasurement?.activePower$Changed  ?.on( apply( ElectricalPowerMeasurement.Cluster.id, 8 ) );
                ev?.electricalEnergyMeasurement?.cumulativeEnergyImported$Changed ?.on( apply( ElectricalEnergyMeasurement.Cluster.id, 1 ) );

                // DoorLock cluster (257)
                ev?.doorLock?.lockState$Changed                     ?.on( apply( DoorLock.Cluster.id, 0 ) );

                // WindowCovering cluster (258) — UNTESTED, see comments in _applyClusterValues
                ev?.windowCovering?.currentPositionLiftPercent100ths$Changed ?.on( apply( WindowCovering.Cluster.id, 14 ) );

                // SmokeCoAlarm cluster (92) — UNTESTED, see comments in _applyClusterValues
                ev?.smokeCoAlarm?.smokeState$Changed                ?.on( apply( SmokeCoAlarm.Cluster.id, 1 ) );
                ev?.smokeCoAlarm?.coState$Changed                   ?.on( apply( SmokeCoAlarm.Cluster.id, 2 ) );

                // UNTESTED (2026-09-08) — remaining clusters below, see comments in _applyClusterValues.
                ev?.relativeHumidityMeasurement?.measuredValue$Changed ?.on( apply( RelativeHumidityMeasurement.Cluster.id, 0 ) );
                ev?.pressureMeasurement?.measuredValue$Changed      ?.on( apply( PressureMeasurement.Cluster.id, 0 ) );
                ev?.flowMeasurement?.measuredValue$Changed          ?.on( apply( FlowMeasurement.Cluster.id, 0 ) );
                ev?.illuminanceMeasurement?.measuredValue$Changed   ?.on( apply( IlluminanceMeasurement.Cluster.id, 0 ) );
                ev?.airQuality?.airQuality$Changed                  ?.on( apply( AirQuality.Cluster.id, 0 ) );
                ev?.valveConfigurationAndControl?.currentState$Changed ?.on( apply( ValveConfigurationAndControl.Cluster.id, 4 ) );
                ev?.energyEvse?.state$Changed                       ?.on( apply( EnergyEvse.Cluster.id, 0 ) );

                // button.state: currentPosition is a regular subscribable attribute (works via
                // the normal $Changed mechanism) — kept as a coarse fallback (see
                // _applyOneAttribute's MatterSwitch.Cluster.id case), but never actually fires
                // live on real button-only devices (no latching position). The real live
                // press/hold/multi-press classification is driven entirely by the raw Switch
                // cluster Events below.
                ev?.switch?.currentPosition$Changed                 ?.on( apply( MatterSwitch.Cluster.id, 1 ) );

                // Switch cluster Events (matter.js exposes these via ev.switch.<eventName>,
                // no "$Changed" suffix — confirmed live 2026-10-09) → button.state. Per the
                // Matter spec, ShortRelease fires on every short click regardless of whether
                // it ends up being part of a multi-press gesture; the authoritative click
                // count only arrives afterward via MultiPressComplete, on devices that support
                // the MultiPress feature. To handle both multi-press and plain single-press-only
                // devices without needing to read FeatureMap, a ShortRelease is provisionally
                // classified as "single" after a short debounce, unless superseded first by a
                // MultiPressComplete with the real count. LongPress/LongRelease (a held button)
                // never participate in multi-press counting, so they're handled independently.
                const COUNT_STATE = { 1: "single", 2: "double", 3: "triple", 4: "4", 5: "5" };
                let shortReleaseTimer = null;
                const setButtonState = ( v ) => {
                    const e = this.findEntity( eid );
                    if ( e ) e.setAttribute( "button.state", v );
                };
                ev?.switch?.shortRelease?.on( () => {
                    if ( shortReleaseTimer ) clearTimeout( shortReleaseTimer );
                    shortReleaseTimer = setTimeout( () => {
                        shortReleaseTimer = null;
                        setButtonState( "single" );
                    }, 600 );
                } );
                ev?.switch?.multiPressComplete?.on( ( value ) => {
                    if ( shortReleaseTimer ) { clearTimeout( shortReleaseTimer ); shortReleaseTimer = null; }
                    setButtonState( COUNT_STATE[ value?.totalNumberOfPressesCounted ] ?? "unknown" );
                } );
                ev?.switch?.longPress?.on( () => setButtonState( "hold" ) );
                ev?.switch?.longRelease?.on( () => setButtonState( "release" ) );

                this.log.debug( 5, "%1 behavior listeners registered for entity %2 (endpoint %3)", this, eid, endpointId );
            }
        }
    }

    /** Applies a single attribute value to an entity. */
    _applyOneAttribute( entity, clusterId, attributeId, value ) {
        switch ( clusterId ) {
            case OnOff.Cluster.id:
                if ( attributeId === 0 ) {
                    entity.setAttribute( "power_switch.state", Boolean(value) );
                    // Some metering relays/plugs stop actively reporting
                    // ElectricalPowerMeasurement updates once the relay opens, leaving the last
                    // nonzero reading stuck forever — force power/current to 0 on power-off since
                    // no load can flow through an open relay. Voltage (mains still present at the
                    // plug) and cumulative energy are left untouched.
                    if ( value === false ) {
                        if ( entity.hasCapability( "power_sensor" ) )   entity.setAttribute( "power_sensor.value", 0 );
                        if ( entity.hasCapability( "current_sensor" ) ) entity.setAttribute( "current_sensor.value", 0 );
                    }
                }
                break;

            case LevelControl.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "dimming.level", Math.round( value / 254 * 100 ) / 100 );
                break;

            case 768: // ColorControl
                if ( attributeId === 7 && value != null && value > 0 )
                    // mireds → Kelvin
                    entity.setAttribute( "color_temperature.value", Math.round( 1_000_000 / value ) );
                // currentHue/currentSaturation are Matter's 0-254 scale — hs_color expects
                // hue in degrees (0-360) and saturation as a 0-1 fraction.
                if ( attributeId === 0 && value != null && entity.hasCapability( "hs_color" ) )
                    entity.setAttribute( "hs_color.hue", Math.round( value * 360 / 254 ) );
                if ( attributeId === 1 && value != null && entity.hasCapability( "hs_color" ) )
                    entity.setAttribute( "hs_color.saturation", Math.round( value / 254 * 100 ) / 100 );
                break;

            case TemperatureMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null ) {
                    entity.setAttribute( "temperature_sensor.value", value / 100 );
                    entity.setAttribute( "temperature_sensor.units", "°C" );
                }
                break;

            case Thermostat.Cluster.id: {
                // systemMode (28) and thermostatRunningState (41) are combined to derive
                // hvac_control.mode/.state, so the last value of each is cached per-entity
                // (both core Reactor capabilities — no custom attributes are introduced here).
                if ( !this._thermostatState ) this._thermostatState = new Map();
                const id = entity.getID();
                const st = this._thermostatState.get( id ) || {};
                if ( attributeId === 28 ) st.systemMode   = value;
                if ( attributeId === 41 ) st.runningState = value;
                if ( attributeId === 28 || attributeId === 41 ) {
                    this._thermostatState.set( id, st );
                    if ( st.systemMode != null )
                        entity.setAttribute( "hvac_control.mode", _hvacModeToString( st.systemMode ) );
                    entity.setAttribute( "hvac_control.state", _hvacStateToString( st.systemMode, st.runningState ) );
                    if ( entity.hasCapability( "hvac_heating_unit" ) )
                        entity.setAttribute( "hvac_heating_unit.state", Boolean( st.runningState?.heat ) );
                    if ( entity.hasCapability( "hvac_cooling_unit" ) )
                        entity.setAttribute( "hvac_cooling_unit.state", Boolean( st.runningState?.cool ) );
                }
                if ( attributeId === 18 && value != null && entity.hasCapability( "hvac_heating_unit" ) ) {
                    entity.setAttribute( "hvac_heating_unit.setpoint", value / 100 );
                    entity.setAttribute( "hvac_heating_unit.units", "°C" );
                }
                if ( attributeId === 17 && value != null && entity.hasCapability( "hvac_cooling_unit" ) ) {
                    entity.setAttribute( "hvac_cooling_unit.setpoint", value / 100 );
                    entity.setAttribute( "hvac_cooling_unit.units", "°C" );
                }
                break;
            }

            case OccupancySensing.Cluster.id:
                // motion_sensor is a core Reactor alias of binary_sensor — attribute is "state".
                // matter.js decodes the Occupancy bitmap into a struct ({occupied: bool}), not a
                // raw integer — read .occupied directly, don't bit-mask it.
                if ( attributeId === 0 )
                    entity.setAttribute( "motion_sensor.state", Boolean(value?.occupied ?? value) );
                break;

            case BooleanState.Cluster.id:
                if ( attributeId === 0 ) {
                    // Select the correct attribute name based on which capability the entity has
                    // (door_sensor/leak_detector/freeze_detector are all core Reactor aliases of
                    // binary_sensor — the alias name, not the canonical "binary_sensor.state",
                    // must be used so the attribute actually exists on entities that only
                    // declared the alias capability — see the matching motion_sensor comment
                    // above for the same pattern).
                    const boolAttr = entity.hasCapability("door_sensor")    ? "door_sensor.state"    :
                                     entity.hasCapability("leak_detector")   ? "leak_detector.state"  :
                                     entity.hasCapability("freeze_detector") ? "freeze_detector.state" :
                                     "binary_sensor.state";
                    entity.setAttribute( boolAttr, Boolean(value) );
                }
                break;

            case PowerSource.Cluster.id:
                if ( attributeId === 12 && value != null )
                    entity.setAttribute( "battery_power.level", value / 200 );
                if ( attributeId === 11 && value != null )
                    entity.setAttribute( "voltage_sensor.value", value / 1000 );
                break;

            case ElectricalPowerMeasurement.Cluster.id:
                if ( attributeId === 4 && value != null ) {   // voltage (mV)
                    entity.setAttribute( "voltage_sensor.value", value / 1000 );
                    entity.setAttribute( "voltage_sensor.units", "V" );
                }
                if ( attributeId === 5 && value != null ) {   // activeCurrent (mA)
                    entity.setAttribute( "current_sensor.value", value / 1000 );
                    entity.setAttribute( "current_sensor.units", "A" );
                }
                if ( attributeId === 8 && value != null ) {   // activePower (mW)
                    entity.setAttribute( "power_sensor.value", value / 1000 );
                    entity.setAttribute( "power_sensor.units", "W" );
                }
                break;

            case ElectricalEnergyMeasurement.Cluster.id:
                if ( attributeId === 1 && value?.energy != null ) {   // cumulativeEnergyImported (mWh)
                    entity.setAttribute( "energy_sensor.value", value.energy / 1_000_000 );
                    entity.setAttribute( "energy_sensor.units", "kWh" );
                }
                break;

            case DoorLock.Cluster.id:
                // LockState enum: 0=NotFullyLocked, 1=Locked, 2=Unlocked, 3=Unlatched
                if ( attributeId === 0 )
                    entity.setAttribute( "lock.state", value === 1 );
                break;

            // UNTESTED (2026-09-08) — see comments in _applyClusterValues.
            case WindowCovering.Cluster.id:
                if ( attributeId === 14 && value != null ) {
                    entity.setAttribute( "cover.state", value < 10000 );
                    entity.setAttribute( "position.value", Math.round( (10000 - value) / 100 ) / 100 );
                }
                break;

            case SmokeCoAlarm.Cluster.id:
                if ( attributeId === 1 ) entity.setAttribute( "smoke_detector.state", value !== 0 );
                if ( attributeId === 2 ) entity.setAttribute( "co_detector.state", value !== 0 );
                break;

            // UNTESTED (2026-09-08) — see _applyClusterValues for caveats on all cases below.
            case RelativeHumidityMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null ) {
                    entity.setAttribute( "humidity_sensor.value", value / 100 );
                    entity.setAttribute( "humidity_sensor.units", "%" );
                }
                break;

            case PressureMeasurement.Cluster.id:
                // Spec: MeasuredValue = 10 x Pressure[kPa] == Pressure[hPa] numerically.
                if ( attributeId === 0 && value != null ) {
                    entity.setAttribute( "pressure_sensor.value", value );
                    entity.setAttribute( "pressure_sensor.units", "hPa" );
                }
                break;

            case FlowMeasurement.Cluster.id:
                // value_sensor is generic — no default units (see _applyClusterValues comment).
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "value_sensor.value", value / 10 );
                break;

            case IlluminanceMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null && value > 0 ) {
                    entity.setAttribute( "light_sensor.value", Math.round( 10 ** ( (value - 1) / 10000 ) ) );
                    entity.setAttribute( "light_sensor.units", "lx" );
                }
                break;

            case AirQuality.Cluster.id:
                if ( attributeId === 0 && value != null ) {
                    entity.setAttribute( "air_quality_sensor.value", value );
                    entity.setAttribute( "air_quality_sensor.units", "" );
                }
                break;

            case ValveConfigurationAndControl.Cluster.id:
                // ValveStateEnum: 0=Closed, 1=Open, 2=Transitioning
                if ( attributeId === 4 && value != null )
                    entity.setAttribute( "valve.state", value === 1 );
                break;

            case MatterSwitch.Cluster.id:
                // Fallback path only (currentPosition$Changed) — the live press/hold/multi-press
                // classification is driven by the raw Switch cluster Events, see
                // _registerStateListeners().
                if ( attributeId === 1 && value != null )
                    entity.setAttribute( "button.state", value > 0 ? "single" : "release" );
                break;

            case EnergyEvse.Cluster.id:
                if ( attributeId === 0 && value != null ) {
                    const STATE_MAP = {
                        0: "not connected", 1: "ready", 2: "ready",
                        3: "charging", 4: "charging", 5: "suspended", 6: "fault",
                    };
                    entity.setAttribute( "ev_charger.state", STATE_MAP[value] ?? "fault" );
                }
                break;
        }
    }

    // ── Privat: Commands ──────────────────────────────────────────────────────

    async _doOnOff( entity, clientNode, endpointId, action, params ) {
        const newState = action === "on" ? true : action === "off" ? false : (params?.state ?? false);
        await this._invokeCommand( clientNode, endpointId, OnOff, newState ? "on" : "off", undefined );
        // Optimistic update — subscription report will confirm later
        entity.setAttribute( "power_switch.state", newState );
    }

    async _doLock( entity, clientNode, endpointId, action, params ) {
        const newState = action === "lock" ? true : action === "unlock" ? false : (params?.state ?? false);
        await this._invokeCommand( clientNode, endpointId, DoorLock, newState ? "lockDoor" : "unlockDoor", undefined );
        // Optimistic update — subscription report will confirm later
        entity.setAttribute( "lock.state", newState );
    }

    // UNTESTED (2026-09-08) — prepared from matter.js/spec only, no physical Water Valve
    // device available yet to verify.
    async _doValve( entity, clientNode, endpointId, action, params ) {
        const newState = action === "open" ? true : action === "close" ? false : (params?.state ?? false);
        await this._invokeCommand( clientNode, endpointId, ValveConfigurationAndControl,
            newState ? "open" : "close", undefined );
        entity.setAttribute( "valve.state", newState );
    }

    // UNTESTED (only verified against real storage.json attribute values, not a live write yet)
    // — Thermostat systemMode (attr 28) is a writable attribute per the Matter spec; written
    // directly (not via a command) since Thermostat has no "set mode" command.
    async _doHvacControl( entity, clientNode, endpointId, action, params ) {
        if ( action !== "set_mode" || !params?.mode ) return;
        const systemMode = HVAC_MODE_STRING_TO_SYSTEM_MODE[ params.mode ];
        if ( systemMode === undefined ) {
            this.log.warn( "%1 hvac_control.set_mode: unsupported mode '%2'", this, params.mode );
            return;
        }
        await this._writeAttribute( clientNode, endpointId, Thermostat.Cluster, "systemMode", systemMode );
        // Optimistic update — subscription report will confirm later
        entity.setAttribute( "hvac_control.mode", params.mode );
    }

    // Confirmed working live (2026-10-09) — write correctly sends the full decimal value
    // (raw int16 hundredths-of-°C, e.g. 21.5°C → 2150) to the device via the Matter protocol.
    // occupiedHeatingSetpoint/occupiedCoolingSetpoint (attrs 18/17) are writable attributes;
    // written directly rather than via the relative SetpointRaiseLower command, since Reactor's
    // set_setpoint action is an absolute value. Note: some bridged devices (e.g. certain
    // Zigbee TRVs via Matterbridge/zigbee2mqtt) only support whole-degree setpoints at the
    // Zigbee level and will round a fractional value themselves further down the chain — that
    // is a bridge/device-side limitation, confirmed via Matterbridge's own log (the MQTT publish
    // payload was already rounded before this plugin's correctly-sent value reached it), not a
    // bug in this write path.
    async _doHvacSetpoint( entity, clientNode, endpointId, kind, action, params ) {
        if ( action !== "set_setpoint" || params?.setpoint == null ) return;
        const attrName = kind === "heating" ? "occupiedHeatingSetpoint" : "occupiedCoolingSetpoint";
        const raw = Math.round( params.setpoint * 100 );   // °C → hundredths, matching the read-side scaling
        await this._writeAttribute( clientNode, endpointId, Thermostat.Cluster, attrName, raw );
        // Optimistic update — subscription report will confirm later
        entity.setAttribute( `hvac_${kind}_unit.setpoint`, params.setpoint );
    }

    // ── UNTESTED (2026-09-08) — prepared from matter.js/spec only, no physical Window
    // Covering device available yet. Verify against a real device before relying on this:
    //   - percent100ths direction (spec says 0=open, 10000=closed; confirm no inversion)
    //   - "open"/"close" mapping to upOrOpen/downOrClose (spec names, should be safe)
    //   - position.value 0..1 convention matches Reactor's other position-capable controllers
    async _doCover( entity, clientNode, endpointId, action, params ) {
        switch ( action ) {
            case "open":
                await this._invokeCommand( clientNode, endpointId, WindowCovering, "upOrOpen", undefined );
                entity.setAttribute( "cover.state", true );
                break;
            case "close":
                await this._invokeCommand( clientNode, endpointId, WindowCovering, "downOrClose", undefined );
                entity.setAttribute( "cover.state", false );
                break;
            case "stop":
                await this._invokeCommand( clientNode, endpointId, WindowCovering, "stopMotion", undefined );
                break;
            case "set": {
                const open = params?.state ?? false;
                await this._invokeCommand( clientNode, endpointId, WindowCovering,
                    open ? "upOrOpen" : "downOrClose", undefined );
                entity.setAttribute( "cover.state", open );
                break;
            }
        }
    }

    // UNTESTED (2026-09-08) — see _doCover() comment above; shares the same underlying
    // WindowCovering.goToLiftPercentage command as the "cover" capability's open/close.
    async _doPosition( entity, clientNode, endpointId, action, params ) {
        const clamp    = v => Math.max( 0, Math.min( 1, v ) );
        const toPct100 = v => Math.round( (1 - clamp(v)) * 10000 );  // Reactor 1=open → Matter 0=open
        const current  = entity.getAttribute( "position.value" ) ?? 0;

        let target;
        switch ( action ) {
            case "set":      target = clamp( params?.value ?? 0 );                       break;
            case "increase":  target = clamp( current + (params?.amount ?? 0.1) );        break;
            case "decrease":  target = clamp( current - (params?.amount ?? 0.1) );        break;
            case "relative":  target = clamp( current + (params?.amount ?? 0) );          break;
            default: return;
        }

        await this._invokeCommand( clientNode, endpointId, WindowCovering, "goToLiftPercentage", {
            liftPercent100thsValue: toPct100( target ),
        });
        entity.setAttribute( "position.value", target );
        entity.setAttribute( "cover.state", target > 0 );
    }

    async _doDimming( entity, clientNode, endpointId, action, params ) {
        const clamp = lvl => Math.max(1, Math.min(254, Math.round(lvl * 254)));
        const move  = async lvl => {
            await this._invokeCommand( clientNode, endpointId, LevelControl, "moveToLevel", {
                level:           clamp(lvl),
                transitionTime:  0,
                optionsMask:     0,
                optionsOverride: 0,
            });
            // Optimistic update
            entity.setAttribute( "dimming.level", Math.round( lvl * 100 ) / 100 );
        };

        switch ( action ) {
            case "set":  await move( params?.level ?? 1 ); break;
            case "up": {
                const step = entity.getAttribute("dimming.step") || 0.1;
                await move( Math.min(1, (entity.getAttribute("dimming.level") || 0) + step) );
                break;
            }
            case "down": {
                const step = entity.getAttribute("dimming.step") || 0.1;
                await move( Math.max(0, (entity.getAttribute("dimming.level") || 0) - step) );
                break;
            }
            default: this.log.warn( "%1 unknown dimming action: %2", this, action );
        }
    }

    async _doColorTemperature( entity, clientNode, endpointId, action, params ) {
        if ( action !== "set" || params?.value == null ) return;
        // Kelvin → mireds (Matter: 1 000 000 / K), clamp to valid range
        const mireds = Math.max( 1, Math.min( 65279, Math.round( 1_000_000 / params.value ) ) );
        await this._invokeCommand( clientNode, endpointId, ColorControl, "moveToColorTemperature", {
            colorTemperatureMireds:         mireds,
            transitionTime:                 0,
            colorTemperatureMinimumMireds:  0,
            colorTemperatureMaximumMireds:  65279,
            optionsMask:                    0,
            optionsOverride:                0,
        });
        // Optimistic update — convert back to Kelvin
        entity.setAttribute( "color_temperature.value", Math.round( 1_000_000 / mireds ) );
    }

    async _doHsColor( entity, clientNode, endpointId, action, params ) {
        // hs_color: hue in degrees (0-360), saturation as a 0-1 fraction.
        // Matter's ColorControl cluster uses a 0-254 scale for both.
        const toMatterHue = deg  => Math.max( 0, Math.min( 254, Math.round( deg  / 360 * 254 ) ) );
        const toMatterSat = frac => Math.max( 0, Math.min( 254, Math.round( frac * 254 ) ) );

        switch ( action ) {
            case "set_hs": {
                if ( params?.hue == null || params?.saturation == null ) return;
                const hue        = toMatterHue( params.hue );
                const saturation = toMatterSat( params.saturation );
                await this._invokeCommand( clientNode, endpointId, ColorControl, "moveToHueAndSaturation", {
                    hue,
                    saturation,
                    transitionTime:  0,
                    optionsMask:     0,
                    optionsOverride: 0,
                });
                // Optimistic update — convert back to hs_color's scale
                entity.setAttribute( "hs_color.hue", Math.round( hue * 360 / 254 ) );
                entity.setAttribute( "hs_color.saturation", Math.round( saturation / 254 * 100 ) / 100 );
                break;
            }
            case "set_hue": {
                if ( params?.hue == null ) return;
                const hue = toMatterHue( params.hue );
                await this._invokeCommand( clientNode, endpointId, ColorControl, "moveToHue", {
                    hue,
                    direction:       0,   // ShortestDistance
                    transitionTime:  0,
                    optionsMask:     0,
                    optionsOverride: 0,
                });
                entity.setAttribute( "hs_color.hue", Math.round( hue * 360 / 254 ) );
                break;
            }
            case "set_saturation": {
                if ( params?.saturation == null ) return;
                const saturation = toMatterSat( params.saturation );
                await this._invokeCommand( clientNode, endpointId, ColorControl, "moveToSaturation", {
                    saturation,
                    transitionTime:  0,
                    optionsMask:     0,
                    optionsOverride: 0,
                });
                entity.setAttribute( "hs_color.saturation", Math.round( saturation / 254 * 100 ) / 100 );
                break;
            }
            default: this.log.warn( "%1 unknown hs_color action: %2", this, action );
        }
    }

    /**
     * light_effect: maps Reactor's generic start/stop actions onto the Identify cluster's
     * TriggerEffect command (Blink/Breathe/Okay/ChannelChange — see EFFECT_NAME_MAP below).
     * Matter's TriggerEffect has no speed/duration fields (the device decides its own timing),
     * so those two Reactor arguments are hidden from the UI (see _createOrUpdateEntity) and
     * ignored here if somehow still supplied.
     */
    async _doLightEffect( entity, clientNode, endpointId, action, params ) {
        const EFFECT_NAME_MAP = {
            blink:          Identify.EffectIdentifier.Blink,
            breathe:        Identify.EffectIdentifier.Breathe,
            okay:           Identify.EffectIdentifier.Okay,
            channel_change: Identify.EffectIdentifier.ChannelChange,
        };

        switch ( action ) {
            case "start": {
                const effectName = String( params?.effect || "" ).trim().toLowerCase();
                const effectId   = EFFECT_NAME_MAP[effectName];
                if ( effectId === undefined ) {
                    this.log.warn( "%1 light_effect.start: unknown effect '%2' (supported: %3)",
                        this, params?.effect, Object.keys( EFFECT_NAME_MAP ).join( ", " ) );
                    return;
                }
                await this._invokeCommand( clientNode, endpointId, Identify, "triggerEffect", {
                    effectIdentifier: effectId,
                    effectVariant:    Identify.EffectVariant.Default,
                });
                entity.setAttribute( "light_effect.current", effectName );
                break;
            }
            case "stop": {
                await this._invokeCommand( clientNode, endpointId, Identify, "triggerEffect", {
                    effectIdentifier: Identify.EffectIdentifier.StopEffect,
                    effectVariant:    Identify.EffectVariant.Default,
                });
                entity.setAttribute( "light_effect.current", "" );
                break;
            }
            default: this.log.warn( "%1 unknown light_effect action: %2", this, action );
        }
    }

    // ── Private: ClientNode management ───────────────────────────────────────

    /** Finds a ClientNode in peers by its nodeIdStr (same as String(node.id)). */
    async _getClientNode( nodeId ) {
        for ( const node of this._serverNode.peers ) {
            if ( String(node.id) === nodeId ) return node;
        }
        throw new Error( `ClientNode ${nodeId} not found in peers` );
    }

    /**
     * Sends a command via the 0.17.1 interaction.invoke() API.
     * Invoke() constructs the Map+invokeRequests structure that ClientInteraction requires.
     */
    async _invokeCommand( clientNode, endpointId, cluster, commandName, fields ) {
        const request = Invoke({
            commands: [
                Invoke.ConcreteCommandRequest({ endpoint: Number(endpointId), cluster, command: commandName, fields })
            ]
        });
        for await ( const chunk of clientNode.interaction.invoke( request ) ) {
            for ( const entry of chunk ) {
                if ( entry.kind === "cmd-status" && entry.status !== 0 ) {
                    throw new Error( `Command ${commandName} returned status ${entry.status}` );
                }
            }
        }
    }

    /**
     * Writes a single attribute via the protocol layer's Write() builder (used for Thermostat
     * systemMode/setpoints, which the Matter spec exposes as plain writable attributes rather
     * than invokable commands). `cluster.attributes[attrName]` is the attribute's model/schema
     * object (required by Write.Attribute — not just the raw attribute ID/name).
     */
    async _writeAttribute( clientNode, endpointId, cluster, attrName, value ) {
        const attrModel = cluster.attributes[attrName];
        if ( !attrModel ) throw new Error( `Unknown attribute ${attrName} on cluster ${cluster.id}` );
        const request = Write( Write.Attribute({
            endpoint:   Number(endpointId),
            cluster,
            attributes: [ attrModel ],
            value,
        }) );
        const result = await clientNode.interaction.write( request );
        WriteResult.assertSuccess( result );
    }

    // ── Private: Helper methods ───────────────────────────────────────────────

    _namesFilePath() {
        return path.join( this._storDir, "matter-names.json" );
    }

    _loadPersistedNames() {
        try {
            const data = JSON.parse( fs.readFileSync( this._namesFilePath(), "utf8" ) );
            this._persistedNames = new Map( Object.entries(data) );
            this.log.debug( 5, "%1 loaded %2 persisted device names", this, this._persistedNames.size );
        } catch {
            this._persistedNames = new Map();
        }
    }

    _savePersistedName( nodeIdStr, name ) {
        this._persistedNames.set( nodeIdStr, name );
        try {
            const data = Object.fromEntries( this._persistedNames );
            fs.writeFileSync( this._namesFilePath(), JSON.stringify(data, null, 2), "utf8" );
        } catch ( e ) {
            this.log.warn( "%1 could not save device name: %2", this, e.message );
        }
    }

    _splitEndpointsFilePath() {
        return path.join( this._storDir, "matter-splitendpoints.json" );
    }

    _loadSplitEndpointsPrefs() {
        try {
            const data = JSON.parse( fs.readFileSync( this._splitEndpointsFilePath(), "utf8" ) );
            this._splitEndpointsPrefs = new Map( Object.entries(data) );
            this.log.debug( 5, "%1 loaded %2 persisted split_endpoints preferences", this, this._splitEndpointsPrefs.size );
        } catch {
            this._splitEndpointsPrefs = new Map();
        }
    }

    _saveSplitEndpointsPref( nodeIdStr, splitEndpoints ) {
        this._splitEndpointsPrefs.set( nodeIdStr, !!splitEndpoints );
        this._saveSplitEndpointsPrefsFile();
    }

    /** Persists the current _splitEndpointsPrefs Map as-is (used after deleting an entry). */
    _saveSplitEndpointsPrefsFile() {
        try {
            const data = Object.fromEntries( this._splitEndpointsPrefs );
            fs.writeFileSync( this._splitEndpointsFilePath(), JSON.stringify(data, null, 2), "utf8" );
        } catch ( e ) {
            this.log.warn( "%1 could not save split_endpoints preferences: %2", this, e.message );
        }
    }


    /**
     * Reads cached attribute state from matter.js file storage.
     *
     * @param {string} nodeIdStr – Matter NodeId as string (e.g. "1")
     * @returns {{ [epId]: { [clusterId]: { [attrId]: any } } } | null}
     */
    _readEndpointMapFromStorage( nodeIdStr ) {
        if ( !this._storDir ) return null;

        const storageDir = path.join( this._storDir, `reactor-${this.getID()}` );
        let files;
        try {
            files = fs.readdirSync( storageDir );
        } catch {
            return null;
        }

        // Find the peerId matching nodeIdStr via the peerAddress file
        let peerId = null;
        for ( const filename of files ) {
            if ( !filename.endsWith( ".commissioning.peerAddress" ) ) continue;
            const m = filename.match( /^nodes\.(peer\d+)\..+\.commissioning\.peerAddress$/ );
            if ( !m ) continue;
            try {
                const raw  = fs.readFileSync( path.join( storageDir, filename ), "utf8" );
                const addr = JSON.parse( raw );
                // nodeId is double-encoded JSON representing a BigInt
                const nodeIdObj = JSON.parse( addr.nodeId );
                if ( String( nodeIdObj.__value__ ) === nodeIdStr ) {
                    peerId = m[1];
                    break;
                }
            } catch { /* skip corrupt files */ }
        }

        if ( !peerId ) return null;

        // Build endpointMap from: nodes.{peerId}.endpoints.{epId}.{clusterId}.{attrId}
        const prefix = `nodes.${peerId}.endpoints.`;
        const endpointMap = {};

        for ( const filename of files ) {
            if ( !filename.startsWith( prefix ) ) continue;
            const rest = filename.slice( prefix.length );
            // File must have exactly 3 parts (epId.clusterId.attrId), all numeric
            const parts = rest.split( "." );
            if ( parts.length !== 3 ) continue;
            const epId     = Number( parts[0] );
            const clusterId = Number( parts[1] );
            const attrId   = Number( parts[2] );
            if ( !Number.isFinite(epId) || !Number.isFinite(clusterId) || !Number.isFinite(attrId) ) continue;

            try {
                const value = JSON.parse( fs.readFileSync( path.join( storageDir, filename ), "utf8" ) );
                if ( !endpointMap[epId] )              endpointMap[epId] = {};
                if ( !endpointMap[epId][clusterId] )   endpointMap[epId][clusterId] = {};
                endpointMap[epId][clusterId][attrId] = value;
            } catch { /* skip corrupt files */ }
        }

        return endpointMap;
    }

    /**
     * Reads cached attribute state from matter.js in-memory behavior state.
     * Works immediately after commissioning (before disk cache is flushed).
     *
     * @param {object} clientNode – ClientNode
     * @returns {{ [epId]: { [clusterId]: { [attrId]: any } } } | null}
     */
    _readEndpointMapFromLocalState( clientNode ) {
        // behaviorId → { id: clusterId, attrs: { propName: attrId } }
        const BEHAVIOR_MAP = {
            descriptor:              { id: 29,   attrs: { deviceTypeList: 0, serverList: 1, clientList: 2, partsList: 3, tagList: 4 } },
            basicInformation:        { id: 40,   attrs: { vendorName: 1, vendorId: 2, productName: 3, productId: 4, softwareVersionString: 10 } },
            onOff:                   { id: 6,    attrs: { onOff: 0 } },
            levelControl:            { id: 8,    attrs: { currentLevel: 0 } },
            colorControl:            { id: 768,  attrs: { colorMode: 8, colorTemperatureMireds: 7, currentX: 3, currentY: 4, currentHue: 0, currentSaturation: 1 } },
            // Identify has no useful readable state for us — identifyType (attr 1) is only read
            // so its mere presence in clusterMap lets us detect the cluster to auto-add light_effect.
            identify:                { id: 3,    attrs: { identifyType: 1 } },
            temperatureMeasurement:  { id: 1026, attrs: { measuredValue: 0 } },
            thermostat:              { id: 513,  attrs: { localTemperature: 0, occupiedCoolingSetpoint: 17,
                                                           occupiedHeatingSetpoint: 18, systemMode: 28,
                                                           thermostatRunningState: 41, featureMap: 65532 } },
            electricalPowerMeasurement:  { id: 144, attrs: { voltage: 4, activeCurrent: 5, activePower: 8 } },
            electricalEnergyMeasurement: { id: 145, attrs: { cumulativeEnergyImported: 1 } },
            occupancySensing:        { id: 1030, attrs: { occupancy: 0 } },
            booleanState:            { id: 69,   attrs: { stateValue: 0 } },
            powerSource:             { id: 47,   attrs: { batPercentRemaining: 12, status: 0, batVoltage: 11 } },
            bridgedDeviceBasicInformation: { id: 57, attrs: { nodeLabel: 5 } },
            doorLock:                { id: 257,  attrs: { lockState: 0 } },
            // UNTESTED — see comment near WindowCovering/SmokeCoAlarm module vars.
            windowCovering:          { id: 258,  attrs: { currentPositionLiftPercent100ths: 14 } },
            smokeCoAlarm:            { id: 92,   attrs: { smokeState: 1, coState: 2 } },
            relativeHumidityMeasurement: { id: 1029, attrs: { measuredValue: 0 } },
            pressureMeasurement:     { id: 1027, attrs: { measuredValue: 0 } },
            flowMeasurement:         { id: 1028, attrs: { measuredValue: 0 } },
            illuminanceMeasurement:  { id: 1024, attrs: { measuredValue: 0 } },
            airQuality:              { id: 91,   attrs: { airQuality: 0 } },
            valveConfigurationAndControl: { id: 129, attrs: { currentState: 4 } },
            switch:                  { id: 59,   attrs: { currentPosition: 1 } },
            fanControl:              { id: 514,  attrs: { fanMode: 0 } },
            energyEvse:              { id: 153,  attrs: { state: 0 } },
        };

        const endpointMap = {};
        // Iterate every endpoint the node actually has (root + all descendants) instead of a
        // hardcoded numeric range — bridge/aggregator devices can expose endpoint numbers well
        // beyond 15 (e.g. a Matterbridge hub's sub-devices at ep17/ep18), which a fixed 0..15
        // loop would silently skip.
        const allEndpoints = [ clientNode, ...clientNode.endpoints ];
        for ( const endpoint of allEndpoints ) {
            if ( !endpoint ) continue;
            const epId = endpoint === clientNode ? 0 : endpoint.number;
            if ( epId === undefined || epId === null ) continue;

            let state;
            try {
                state = endpoint.state;
            } catch { continue; }
            if ( !state ) continue;

            const clusterMap = {};
            for ( const [behaviorId, info] of Object.entries( BEHAVIOR_MAP ) ) {
                const bs = state[ behaviorId ];
                if ( !bs || typeof bs !== "object" ) continue;
                const attrMap = {};
                for ( const [propName, attrId] of Object.entries( info.attrs ) ) {
                    if ( bs[ propName ] !== undefined ) attrMap[ attrId ] = bs[ propName ];
                }
                if ( Object.keys( attrMap ).length > 0 ) clusterMap[ info.id ] = attrMap;
            }
            if ( Object.keys( clusterMap ).length > 0 ) endpointMap[ epId ] = clusterMap;
        }

        return Object.keys( endpointMap ).length > 0 ? endpointMap : null;
    }

    _buildEndpointMap( allAttrs ) {
        const map = {};
        for ( const { path, value } of allAttrs ) {
            const { endpointId, clusterId, attributeId } = path;
            if ( !map[endpointId] ) map[endpointId] = {};
            if ( !map[endpointId][clusterId] ) map[endpointId][clusterId] = {};
            map[endpointId][clusterId][attributeId] = value;
        }
        return map;
    }

    /** Selects the DeviceType configuration with the most capabilities. */
    _pickBestConfig( deviceTypeList ) {
        let best     = null;
        let bestScore = -1;
        const matched = [];

        for ( const dt of deviceTypeList ) {
            const code = typeof dt === "object" ? (dt.deviceType ?? dt.code) : dt;
            let cfg = null;

            // Check YAML file first, then built-in map
            if ( impl && Array.isArray(impl.mapping) ) {
                cfg = impl.mapping.find( m => Number(m.device_type_id) === code ) || null;
            }
            cfg = cfg || DEVICE_MAP.get(code) || null;

            if ( cfg ) {
                matched.push( cfg );
                // Prefer an actionable/controllable device type (entity_type other than the
                // generic "Sensor") over a co-located passive sensor/meter device type, even if
                // the sensor happens to declare more capabilities — e.g. a smart plug endpoint
                // that reports both a plain relay (Switch, few capabilities) AND an Electrical
                // Sensor (Sensor, several power/voltage/current capabilities) should keep its
                // Switch identity (so it stays controllable from the UI), not flip to a read-only
                // Sensor entity just because the sensor side has a longer capability list. The
                // +1000 bonus guarantees any non-Sensor match always outranks a Sensor-only one;
                // capability count still breaks ties within the same tier.
                const n = (cfg.capabilities || []).length;
                const score = n + ( cfg.entity_type !== "Sensor" ? 1000 : 0 );
                if ( score > bestScore ) { best = cfg; bestScore = score; }
            }
        }

        if ( !best ) return null;

        // Matter endpoints commonly expose SEVERAL device types at once (e.g. a combo
        // temperature/humidity/pressure sensor reports deviceTypeList = [TemperatureSensor,
        // HumiditySensor, PressureSensor, ...]) — each contributes its own capability, but only
        // ONE device type's config can be "best" (used for entity_type/type_label/default_name/
        // primary_attribute) above. Union in every OTHER matched device type's capabilities too,
        // so e.g. humidity_sensor/pressure_sensor aren't silently dropped just because
        // TemperatureSensor happened to be picked as the base config. Clone rather than mutate —
        // `best` may be the same shared object reused across many endpoints/syncs (parsed once
        // from YAML/DEVICE_MAP).
        const allCaps = new Set( best.capabilities || [] );
        for ( const cfg of matched ) {
            if ( cfg === best ) continue;
            for ( const cap of cfg.capabilities || [] ) allCaps.add( cap );
        }
        if ( allCaps.size !== (best.capabilities || []).length ) {
            return { ...best, capabilities: [ ...allCaps ] };
        }
        return best;
    }

    _makeEntityId( nodeIdStr, endpointId ) {
        const safe = String(nodeIdStr).replace( /[^a-zA-Z0-9]/g, "_" );
        return `${safe}_ep${endpointId}`.substring(0, 128);
    }

    // ── Private: Poll ──────────────────────────────────────────────────────────

    // ── Private: Reconnection ─────────────────────────────────────────────────

    _scheduleReconnect() {
        if ( this._reconnTimer || this._stopping ) return;
        const BASE_MS  = 30_000;
        const MAX_MS   = 300_000;
        const FAST_IDX = 12;
        let delay = BASE_MS;
        if ( this._retryCount > FAST_IDX ) {
            delay = Math.min( MAX_MS, BASE_MS * Math.pow(2, this._retryCount - FAST_IDX) );
        }
        this.log.info( "%1 reconnecting in %2s (attempt %3)", this, Math.round(delay/1000), this._retryCount + 1 );

        this._reconnTimer = setTimeout( async () => {
            this._reconnTimer = null;
            if ( this._stopping ) return;
            this._retryCount++;
            await this._stopMatter();
            try {
                await this._startMatter();
                this._setupSystemEntity();
                this.online();
                this._retryCount = 0;
            } catch ( err ) {
                this.log.err( "%1 reconnection %2 failed: %3\n%4", this, this._retryCount, err.message, err.stack );
                this.offline();
                this._scheduleReconnect();
            }
        }, delay );
    }

    _clearReconnect() {
        if ( this._reconnTimer ) { clearTimeout(this._reconnTimer); this._reconnTimer = null; }
    }
}

export default MatterController;
