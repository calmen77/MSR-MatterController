#!/usr/bin/env bash
# install.sh — MatterController installer for Reactor
#
# Usage:
#   bash install.sh             Install npm dependencies in this directory
#   bash install.sh --check     Check prerequisites without installing

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MIN_NODE_MAJOR=18

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

ok()      { echo -e "${GREEN}[OK]${RESET}    $*"; }
error()   { echo -e "${RED}[ERROR]${RESET} $*" >&2; }
header()  { echo -e "\n${BOLD}── $* ──────────────────────────────────${RESET}"; }

CHECK_ONLY=false
[[ "${1:-}" == "--check" ]] && CHECK_ONLY=true

# ── 1. Node.js ────────────────────────────────────────────────────────────────

header "1. Checking Node.js"
if ! command -v node &>/dev/null; then
    error "node not found. Install Node.js >= ${MIN_NODE_MAJOR} first."
    exit 1
fi
NODE_VERSION="$(node --version)"
NODE_MAJOR="${NODE_VERSION#v}"; NODE_MAJOR="${NODE_MAJOR%%.*}"
if (( NODE_MAJOR < MIN_NODE_MAJOR )); then
    error "Node.js ${NODE_VERSION} is too old. Minimum v${MIN_NODE_MAJOR} required."
    exit 1
fi
ok "Node.js ${NODE_VERSION}"

# ── 2. npm ────────────────────────────────────────────────────────────────────

header "2. Checking npm"
if ! command -v npm &>/dev/null; then
    error "npm not found."
    exit 1
fi
ok "npm $(npm --version)"

if $CHECK_ONLY; then
    ok "All prerequisites met. Run without --check to install."
    exit 0
fi

# ── 3. npm install ────────────────────────────────────────────────────────────

header "3. Installing npm dependencies"
mkdir -p "${SCRIPT_DIR}"
cd "${SCRIPT_DIR}"
npm install --no-audit --no-fund
ok "Dependencies installed"

# ── 4. Syntax check ───────────────────────────────────────────────────────────

header "4. Verifying MatterController.js"
if node --check "${SCRIPT_DIR}/MatterController.js"; then
    ok "MatterController.js syntax OK"
else
    error "Syntax error in MatterController.js!"
    exit 1
fi

# ── Done ──────────────────────────────────────────────────────────────────────

echo ""
echo -e "${GREEN}${BOLD}✅ Installation complete!${RESET}"
echo ""
echo -e "Add the following to ${BOLD}reactor.yaml${RESET} under ${BOLD}controllers:${RESET}"
echo ""
echo -e "${CYAN}  - id: matter_controller${RESET}"
echo -e "${CYAN}    enabled: true${RESET}"
echo -e "${CYAN}    implementation: MatterController${RESET}"
echo -e "${CYAN}    name: Matter${RESET}"
echo -e "${CYAN}    config:${RESET}"
echo -e "${CYAN}      # optional: Matter protocol port (default: 5541)${RESET}"
echo -e "${CYAN}      port: 5541${RESET}"
echo -e "${CYAN}      # optional: label shown in Matter fabric list on devices (default: MatterController)${RESET}"
echo -e "${CYAN}      fabric_label: MatterController${RESET}"
echo -e "${CYAN}      # optional: controller name in Matter metadata (default: Reactor)${RESET}"
echo -e "${CYAN}      controller_name: Reactor${RESET}"
echo ""
echo -e "To add a device: Set the device in pairng mode, if already connected to another"
echo -e "controller, and perform the ${BOLD}x_matter_controller.commission${RESET} action on the Matter"
echo -e "controller's system entity in the Reactor UI, with the 11-digit pairing code as 'code', "
echo -e "or just add the code if it's a new/unpaired device."
echo -e "Watch the ${BOLD}x_matter_controller.status${RESET} attribute on that system entity — it goes"
echo -e "${BOLD}pending${RESET} while commissioning, then ${BOLD}ok${RESET} once the device has been added (or ${BOLD}error${RESET},"
echo -e "with details in ${BOLD}x_matter_controller.last_error${RESET}, if it failed). Reload the page"
echo -e "once status is ${BOLD}ok${RESET} to see the new entity/-ies."
echo ""
