"use strict";

/**
 * MatterController — Reactor Controller for the Matter protocol
 *
 * Connects to Matter devices via matter.js (@matter/main v0.17.1+).
 * Creates its own Matter fabric; devices are commissioned via Multi-Admin
 * (open a commissioning window in e.g. Apple Home and enter the PIN in Reactor).
 *
 * Supported device types:
 *   On/Off lights, dimmable lights, plugs, temperature sensors,
 *   motion sensors (occupancy), contact sensors (door/window).
 *
 * Requirements: Node.js >= 18, @matter/main ^0.17.1
 * Installation: cd ext/MatterController && npm install
 *
 * reactor.yaml example:
 *   controllers:
 *     - id: matter
 *       implementation: MatterController
 *       config:
 *         controller_name: "Reactor"
 *         fabric_label: "MatterController"
 */

const path = require("path");
const fs   = require("fs");

// ── Reactor imports ────────────────────────────────────────────────────────────
// Reactor adds its root to the Node.js module search path, so no relative
// paths are needed (or work) here.

const version  = 26255;
const revision = 1;

/**
 * ORPHAN_CLUSTER_CAPS — generic table of clusters that can appear on an "orphan" endpoint
 * (an endpoint with no recognizable device type of its own — Descriptor.deviceTypeList is
 * empty/unrecognized — sibling to the node's real functional endpoint(s)). Each entry maps
 * a cluster ID to the Reactor capability it can provide and the attribute ID that must be
 * present for that capability to apply. This is the single place to extend if a future device
 * puts some other cluster (not just PowerSource) on its own orphan endpoint.
 *
 * Used by both code paths in _syncNode():
 *  - split_endpoints = false (default): orphan clusters found are merged into the node's sole
 *    functional entity (unchanged legacy behavior — a PowerSource cluster can live on its own
 *    sibling endpoint, e.g. observed on a real Thread door lock).
 *  - split_endpoints = true: each orphan endpoint that matches at least one entry here becomes
 *    its own separate Sensor entity instead of being merged.
 */
const ORPHAN_CLUSTER_CAPS = [
    { clusterId: 47 /* PowerSource */, attrId: 12, capability: "battery_power" },
    { clusterId: 47 /* PowerSource */, attrId: 11, capability: "voltage_sensor" },
];

const Logger = require("server/lib/Logger");
Logger.getLogger("MatterController", "Controller").always("Module MatterController v%1", version);

const Controller    = require("server/lib/Controller").requires(22304);
const Entity        = require("server/lib/Entity").requires(22306);
const Configuration = require("server/lib/Configuration");

// ── Module-level state ────────────────────────────────────────────────────────

let impl = false;

// matter.js is loaded lazily to provide clear error messages if it is missing
let matterLoaded = false;
let ServerNode, Environment, ManualPairingCodeCodec;
let Descriptor, BasicInformation, OnOff, LevelControl, ColorControl,
    TemperatureMeasurement, OccupancySensing, BooleanState, PowerSource,
    BridgedDeviceBasicInformation, DoorLock,
    // UNTESTED (2026-09-08) — prepared from matter.js cluster specs only, no real device
    // available yet to verify attribute semantics/direction. See the UNTESTED comments in
    // matter_devices.yaml and README.md's device type table before relying on these.
    WindowCovering, SmokeCoAlarm,
    RelativeHumidityMeasurement, PressureMeasurement, FlowMeasurement, IlluminanceMeasurement,
    AirQuality, ValveConfigurationAndControl, MatterSwitch, FanControl, EnergyEvse;
let Invoke;

// ── DeviceTypeId → Reactor configuration ──────────────────────────────────────

const DEVICE_MAP = new Map([
    [ 0x0100, { entity_type: "Switch", capabilities: ["power_switch", "toggle"],                                    default_name: "Matter Light"                  } ],
    [ 0x0101, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming"],                         default_name: "Matter Dimmable Light"          } ],
    [ 0x010C, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming", "color_temperature"],    default_name: "Matter Color Temp Light"        } ],
    [ 0x010D, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming", "color_temperature"],    default_name: "Matter Extended Color Light"    } ],
    [ 0x010A, { entity_type: "Switch", capabilities: ["power_switch", "toggle"],                                    default_name: "Matter Plug"                   } ],
    [ 0x010B, { entity_type: "Switch", capabilities: ["power_switch", "toggle", "dimming"],                         default_name: "Matter Dimmable Plug"          } ],
    [ 0x0302, { entity_type: "Sensor", capabilities: ["temperature_sensor"],                                        default_name: "Matter Temperature"            } ],
    [ 0x0107, { entity_type: "Sensor", capabilities: ["motion_sensor"],                                             default_name: "Matter Occupancy"              } ],
    [ 0x0015, { entity_type: "Sensor", capabilities: ["door_sensor"],                                               default_name: "Matter Contact Sensor"         } ],
    [ 0x0850, { entity_type: "Sensor", capabilities: ["binary_sensor"],                                             default_name: "Matter On/Off Sensor"          } ],
    [ 0x000A, { entity_type: "Lock",   capabilities: ["lock"],                                                      default_name: "Matter Door Lock"              } ],
    // ── UNTESTED (2026-09-08): prepared from matter.js cluster specs, no physical device
    // available yet to verify. Verify carefully (units, enum semantics, sign conventions)
    // the first time a real device of this type is commissioned.
    [ 0x0202, { entity_type: "Cover",  capabilities: ["cover", "position"],                                         default_name: "Matter Window Covering"        } ],
    [ 0x0076, { entity_type: "Sensor", capabilities: ["smoke_detector", "co_detector"],                             default_name: "Matter Smoke/CO Alarm"         } ],
    // NOTE: Thermostat/AirConditioner mappings exist for entity/capability assignment only —
    // the Thermostat cluster itself (setpoints, modes, running state) is intentionally NOT
    // implemented yet (2026-09-08): its multi-setpoint/multi-mode model doesn't map cleanly
    // onto Reactor's hvac_control capability without real-device testing to get right.
    // These entities will currently only show temperature_sensor.value (via the standard
    // TemperatureMeasurement cluster, already implemented) with no thermostat control.
    [ 0x0301, { entity_type: "Thermostat", capabilities: ["hvac_control", "temperature_sensor"],                    default_name: "Matter Thermostat"             } ],
    [ 0x0072, { entity_type: "Thermostat", capabilities: ["hvac_control", "temperature_sensor"],                    default_name: "Matter Air Conditioner"        } ],
    // NOTE: Fan/AirPurifier — FanControl cluster is attribute-write based (fanMode), not
    // command based like OnOff. No verified attribute-write path exists yet in this file (all
    // other commands use Invoke against cluster *commands*) — see _doFan() for details on what
    // is and isn't implemented.
    [ 0x002B, { entity_type: "Switch", capabilities: ["power_switch"],                                              default_name: "Matter Fan"                    } ],
    [ 0x002D, { entity_type: "Switch", capabilities: ["power_switch"],                                              default_name: "Matter Air Purifier"           } ],
    [ 0x0042, { entity_type: "Switch", capabilities: ["valve"],                                                     default_name: "Matter Water Valve"            } ],
    [ 0x000F, { entity_type: "Sensor", capabilities: ["button"],                                                    default_name: "Matter Switch Button"          } ],
    // NOTE: EnergyEvse — read-only status mapping only; set_current/set_operating_mode/
    // set_schedule actions are NOT implemented (safety-critical charge control commands
    // should not be guessed at without spec verification against a real charger).
    [ 0x050C, { entity_type: "Switch", capabilities: ["ev_charger", "power_sensor"],                                 default_name: "Matter EV Charger"             } ],
    [ 0x0307, { entity_type: "Sensor", capabilities: ["humidity_sensor"],                                            default_name: "Matter Humidity Sensor"        } ],
    [ 0x0305, { entity_type: "Sensor", capabilities: ["pressure_sensor"],                                            default_name: "Matter Pressure Sensor"        } ],
    [ 0x0306, { entity_type: "Sensor", capabilities: ["value_sensor"],                                               default_name: "Matter Flow Sensor"            } ],
    [ 0x0106, { entity_type: "Sensor", capabilities: ["light_sensor"],                                               default_name: "Matter Light Sensor"           } ],
    [ 0x002C, { entity_type: "Sensor", capabilities: ["air_quality_sensor"],                                         default_name: "Matter Air Quality Sensor"     } ],
    [ 0x0043, { entity_type: "Sensor", capabilities: ["leak_detector"],                                              default_name: "Matter Water Leak Sensor"      } ],
    [ 0x0041, { entity_type: "Sensor", capabilities: ["freeze_detector"],                                            default_name: "Matter Water Freeze Sensor"    } ],
    [ 0x0044, { entity_type: "Sensor", capabilities: ["binary_sensor"],                                              default_name: "Matter Rain Sensor"            } ],
    [ 0x0045, { entity_type: "Sensor", capabilities: ["humidity_sensor"],                                            default_name: "Matter Soil Sensor"            } ],
]);

// ── Controller class ──────────────────────────────────────────────────────────

class MatterController extends Controller {

    /** Prevent Reactor from automatically creating a controller group */
    static createControllerGroup = false;

    constructor( ...args ) {
        super( ...args );
        this._serverNode    = null;   // @matter/main ServerNode
        this._reconnTimer   = null;
        this._retryCount    = 0;
        this._stopping      = false;
        // Map nodeId(string) → { peerAddress, entityIds[] }
        this._nodeMap             = new Map();
        // Map nodeId(string) → label (from the commission action — cleared after first _syncNode)
        this._commissioningLabels = new Map();
        // Map nodeId(string) → name (persisted to disk, survives entity delete)
        this._persistedNames      = new Map();
        // Map nodeId(string) → split_endpoints boolean (persisted to disk, per-node commission choice)
        this._splitEndpointsPrefs = new Map();
        // Pending split_endpoints choice for a commission in flight, consumed by _onNodeAdded()
        // the instant the new node appears — same race-avoidance pattern as _pendingCommissionLabel.
        this._pendingSplitEndpoints = null;
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    async start() {
        this._stopping = false;
        this.log.info( "%1 starting (v%2)", this, version );

        // Load impl data once per process
        if ( false === impl ) {
            impl = await this.loadBaseImplementationData( "matter", __dirname );
        }

        // Import matter.js
        if ( !matterLoaded ) {
            try {
                this._importMatter();
            } catch ( err ) {
                this.log.err( "%1 cannot load @matter/main: %2\n  Run: cd ext/MatterController && npm install", this, err.message );
                this.offline();
                this._scheduleReconnect();
                return this;
            }
        }

        try {
            await this._startMatter();
            this._setupSystemEntity();
            this.online();
            this._retryCount = 0;
        } catch ( err ) {
            this.log.err( "%1 startup error: %2\n%3", this, err.message, err.stack );
            await this._stopMatter();
            this.offline();
            this._scheduleReconnect();
        }

        return this;
    }

    async stop() {
        this.log.info( "%1 stopping", this );
        this._stopping = true;
        this._clearReconnect();
        await this._stopMatter();
        return super.stop();
    }

    // ── Entity lifecycle ───────────────────────────────────────────────────────

    /** Called by the base class for every entity removal (purge_dead_entities,
     *  delete_entity, etc.).  When the last Reactor entity for a matter.js node
     *  is removed, the node is decommissioned so it won't be re-created on the
     *  next restart. */
    removeEntity( entity ) {
        const nodeId   = entity.getAttribute?.( "x_matter.node_id" );
        const entityId = entity.getID();
        const wasDead  = !!entity.isDead?.();   // capture before destroy()

        super.removeEntity( entity );   // destroys the entity

        // Only decommission matter.js nodes when a dead entity is purged.
        // A live entity removed via delete_entity should be recreated on restart.
        if ( !nodeId || !wasDead ) return;

        // Update the entity list for this node; if others remain, we're done.
        const data = this._nodeMap.get( nodeId );
        if ( data ) {
            data.entityIds = data.entityIds.filter( eid => eid !== entityId );
            if ( data.entityIds.length > 0 ) return;
        }

        // All entities for this node are gone — decommission the matter.js node.
        this._nodeMap.delete( nodeId );
        this._persistedNames.delete( nodeId );
        this._splitEndpointsPrefs.delete( nodeId );
        this._saveSplitEndpointsPrefsFile();
        this.log.info( "%1 node %2 decommissioned (all dead entities purged)", this, nodeId );
        if ( this._serverNode ) {
            for ( const node of [ ...this._serverNode.peers ] ) {
                if ( String( node.id ) === nodeId ) {
                    node.delete().catch( e =>
                        this.log.warn( "%1 node %2 delete failed: %3", this, nodeId, e.message ) );
                    break;
                }
            }
        }
    }

    // ── Actions ────────────────────────────────────────────────────────────────

    /** x_matter.remove action — decommissions a Matter node (properly informing the
     *  physical device so it forgets Reactor's fabric, when reachable) and removes all
     *  Reactor entities backed by it. Works for both standalone devices and bridge/aggregator
     *  nodes (removes every sub-device entity sharing the same nodeId in one call), without
     *  needing to stop Reactor or edit storage.json by hand.
     *  params.force: if true, force-remove locally even if the device can't be reached to
     *  decommission cleanly (device will need a manual factory-reset to re-pair elsewhere). */
    async _removeMatterDevice( nodeId, params ) {
        const force = params?.force === true || params?.force === "true";
        const node = this._serverNode
            ? [ ...this._serverNode.peers ].find( n => String( n.id ) === nodeId )
            : null;

        if ( node ) {
            try {
                await node.decommission();
                this.log.notice( "%1 node %2 decommissioned (device notified)", this, nodeId );
            } catch ( err ) {
                if ( !force ) {
                    throw new Error( `Could not reach the device to decommission it cleanly (${err.message}). ` +
                        `Retry with force=true to remove it from Reactor anyway — you will likely need to ` +
                        `factory-reset the physical device manually before it can be paired elsewhere.` );
                }
                this.log.warn( "%1 node %2 unreachable — force-removing locally: %3", this, nodeId, err.message );
                await node.delete().catch( e =>
                    this.log.warn( "%1 node %2 local delete also failed: %3", this, nodeId, e.message ) );
            }
        } else {
            this.log.warn( "%1 node %2 not found among active peers — removing Reactor entities only", this, nodeId );
        }

        this._nodeMap.delete( nodeId );
        this._persistedNames.delete( nodeId );
        this._commissioningLabels.delete( nodeId );
        this._splitEndpointsPrefs.delete( nodeId );
        this._saveSplitEndpointsPrefsFile();

        // Remove every Reactor entity backed by this node (all sub-devices for a bridge/hub)
        for ( const e of Object.values( this.getEntities() ) ) {
            if ( e.getAttribute?.( "x_matter.node_id" ) === nodeId ) {
                e.markDead( true );
                this.removeEntity( e );
            }
        }
    }

    async performOnEntity( entity, actionName, parameters ) {
        if ( !entity.hasCapability( "x_matter" ) ) {
            return super.performOnEntity( entity, actionName, parameters );
        }

        const nodeId     = entity.getAttribute( "x_matter.node_id" );
        const endpointId = entity.getAttribute( "x_matter.endpoint_id" );

        if ( !nodeId ) {
            this.log.err( "%1 performOnEntity: entity %2 missing x_matter.node_id", this, entity.getID() );
            return;
        }

        try {
            const clientNode = await this._getClientNode( nodeId );
            const dot       = actionName.indexOf(".");
            const capName   = actionName.substring(0, dot);
            const actName   = actionName.substring(dot + 1);

            switch ( capName ) {
                case "power_switch":
                    await this._doOnOff( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "toggle":
                    if ( actName === "toggle" ) {
                        await this._invokeCommand( clientNode, endpointId, OnOff, "toggle", undefined );
                        // Optimistic update: flip current state
                        entity.setAttribute( "power_switch.state", !entity.getAttribute("power_switch.state") );
                    }
                    break;
                case "dimming":
                    await this._doDimming( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "color_temperature":
                    await this._doColorTemperature( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "lock":
                    await this._doLock( entity, clientNode, endpointId, actName, parameters );
                    break;
                // UNTESTED (2026-09-08) — see _doCover()/_doPosition() comments.
                case "cover":
                    await this._doCover( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "position":
                    await this._doPosition( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "valve":
                    await this._doValve( entity, clientNode, endpointId, actName, parameters );
                    break;
                case "x_matter":
                    if ( actName === "remove" ) {
                        await this._removeMatterDevice( nodeId, parameters );
                    } else {
                        this.log.warn( "%1 performOnEntity: unknown action '%2'", this, actionName );
                    }
                    break;
                default:
                    this.log.warn( "%1 performOnEntity: unknown action '%2'", this, actionName );
            }
        } catch ( err ) {
            this.log.err( "%1 performOnEntity(%2) error: %3", this, actionName, err.message );
        }
    }

    /** x_matter_controller.commission action — commissions a new Matter device using a
     *  manual pairing code, replacing the old standalone HTTP commissioning UI. Called on
     *  the controller's system entity (see _setupSystemEntity()); base Controller.performOnEntity
     *  dispatches "x_matter_controller.commission" to this method by naming convention. */
    async action_x_matter_controller_commission( entity, params ) {
        const code  = String( params?.code || "" ).replace( /[\s-]/g, "" );
        const label = String( params?.name || "" ).trim() || "Matter Device";
        // split_endpoints: per-node choice — when true, orphan endpoints (e.g. a sibling
        // PowerSource endpoint with no device type of its own) become their own separate
        // Sensor entity instead of being merged into the node's sole functional entity.
        const splitEndpoints = !!params?.split_endpoints;

        if ( !/^\d{11}$/.test( code ) ) {
            const msg = "The code must be exactly 11 digits (hyphens are allowed).";
            entity.setAttributes({ status: "error", last_error: msg }, "x_matter_controller" );
            throw new Error( msg );
        }

        entity.setAttributes({ status: "pending", last_error: "" }, "x_matter_controller" );
        try {
            const nodeId = await this._commissionDevice( code, label, splitEndpoints );
            this.log.notice( "%1 commissioning via action succeeded: node %2", this, nodeId );
            entity.setAttributes({
                status: "ok",
                last_device_name: label,
                last_device_node_id: nodeId,
                last_error: "",
            }, "x_matter_controller" );
            return { node_id: nodeId };
        } catch ( err ) {
            this.log.err( "%1 commissioning via action failed: %2", this, err.message );
            entity.setAttributes({ status: "error", last_error: err.message }, "x_matter_controller" );
            throw err;
        }
    }

    /** sys_system.restart action — auto-attached to every controller's system entity by the
     *  base Controller class (see system_capabilities.yaml), but the base class's default
     *  implementation only logs "not implemented for this Controller class" unless a subclass
     *  overrides action_sys_system_restart (see e.g. MQTTController.js's own override). Matter
     *  needed a full stop()/start() cycle (not just a soft reconnect) since it tears down and
     *  recreates the whole matter.js ServerNode/fabric — a partial recycle wouldn't pick up
     *  e.g. a node_modules update or a config change without a full process restart anyway,
     *  but this at least re-establishes all peer connections and re-syncs every commissioned
     *  device without needing an OS-level service restart. */
    async action_sys_system_restart( entity, params ) {  // eslint-disable-line no-unused-vars
        this.log.info( "%1 performing sys_system.restart", this );
        await this.stop();
        await this.start();
    }

    // ── Private: matter.js import ─────────────────────────────────────────────

    _importMatter() {
        // @matter/main automatically includes @matter/nodejs registration
        const m = require( "@matter/main" );
        ServerNode  = m.ServerNode;
        Environment = m.Environment;

        // Protocol layer — ClusterClient was removed in 0.17.1; commands are sent via interaction.invoke()

        // Pairing code codec (for commissioning from Apple Home etc.)
        ({ ManualPairingCodeCodec } = require( "@matter/types" ));

        // Cluster definitions — use @matter/main/clusters/* (package exports)
        ({ Descriptor }             = require( "@matter/main/clusters/descriptor" ));
        ({ BasicInformation }       = require( "@matter/main/clusters/basic-information" ));
        ({ OnOff }                  = require( "@matter/main/clusters/on-off" ));
        ({ LevelControl }           = require( "@matter/main/clusters/level-control" ));
        ({ TemperatureMeasurement } = require( "@matter/main/clusters/temperature-measurement" ));
        ({ OccupancySensing }       = require( "@matter/main/clusters/occupancy-sensing" ));
        ({ BooleanState }           = require( "@matter/main/clusters/boolean-state" ));
        ({ PowerSource }            = require( "@matter/main/clusters/power-source" ));
        ({ BridgedDeviceBasicInformation } = require( "@matter/main/clusters/bridged-device-basic-information" ));
        ({ ColorControl }           = require( "@matter/main/clusters/color-control" ));
        ({ DoorLock }               = require( "@matter/main/clusters/door-lock" ));
        // UNTESTED — see comment at module-level variable declaration above.
        ({ WindowCovering }         = require( "@matter/main/clusters/window-covering" ));
        ({ SmokeCoAlarm }           = require( "@matter/main/clusters/smoke-co-alarm" ));
        ({ RelativeHumidityMeasurement } = require( "@matter/main/clusters/relative-humidity-measurement" ));
        ({ PressureMeasurement }    = require( "@matter/main/clusters/pressure-measurement" ));
        ({ FlowMeasurement }        = require( "@matter/main/clusters/flow-measurement" ));
        ({ IlluminanceMeasurement } = require( "@matter/main/clusters/illuminance-measurement" ));
        ({ AirQuality }             = require( "@matter/main/clusters/air-quality" ));
        ({ ValveConfigurationAndControl } = require( "@matter/main/clusters/valve-configuration-and-control" ));
        ({ Switch: MatterSwitch }   = require( "@matter/main/clusters/switch" ));
        ({ FanControl }             = require( "@matter/main/clusters/fan-control" ));
        ({ EnergyEvse }             = require( "@matter/main/clusters/energy-evse" ));

        // Invoke builder from the protocol layer (required for the correct invoke format to ClientInteraction)
        ({ Invoke }                 = require( "@matter/protocol" ));

        matterLoaded = true;
        this.log.info( "%1 matter.js loaded", this );
    }

    // ── Private: Matter server ────────────────────────────────────────────────

    async _startMatter() {
        const conf    = this.getConfig() || {};
        const confDir = Configuration.getConfig( "reactor.confdir", "string" ) ||
                        path.resolve( __dirname, "../.." );
        const storDir = path.join( confDir, `matter_${this.getID()}` );
        this._storDir = storDir;

        this.log.info( "%1 Matter storage: %2", this, storDir );

        // Load persisted device names (survive entity deletion in Reactor)
        this._loadPersistedNames();
        // Load persisted per-node split_endpoints preferences (survive entity deletion)
        this._loadSplitEndpointsPrefs();
        const env = Environment.default;
        env.vars.set( "storage.path", storDir );
        // Disable matter.js signal/exit-code handling — Reactor manages this.
        // Without these settings, ProcessManager installs its own SIGINT/SIGTERM handlers
        // that conflict with Reactor and cause the process to hang on Ctrl+C.
        env.vars.set( "runtime.signals",          false );
        env.vars.set( "runtime.exitcode",         false );
        env.vars.set( "runtime.unhandlederrors",  false );

        // Use JSON-file storage: stores all matter.js state in a single storage.json
        // instead of one file per key.  Auto-migrates from the default file format.
        const { StorageService }       = require( "@matter/general" );
        const { JsonFileStorageDriver } = require( "@matter/nodejs" );
        const storageSvc = env.get( StorageService );
        storageSvc.registerDriver( JsonFileStorageDriver );
        storageSvc.configuredDriver = "json";

        // controller_name = name shown in Apple Home for this controller ("Reactor")
        // fabric_label    = fabric label stored on the device ("MatterController")
        const controllerName = conf.controller_name || "Reactor";
        const fabricLabel    = conf.fabric_label    || "MatterController";

        // Create the controller ServerNode (ControllerBehavior included by default)
        this._serverNode = await ServerNode.create({
            id: `reactor-${this.getID()}`,
            network: {
                // Avoid port conflict with other Matter processes (e.g. Matterbridge) on 5540
                port: conf.port || 5541,
            },
            commissioning: {
                // This controller node should not be commissionable by others
                enabled: false,
            },
            productDescription: {
                // Shown as the controller name in Apple Home and similar apps
                name:       controllerName,
                deviceType: 0x0016,  // Root Node
            },
            basicInformation: {
                // nodeLabel = controller name displayed in Apple Home
                nodeLabel: controllerName,
            },
            controller: {
                // Fabric label stored on the device, visible in "Apps with Access"
                adminFabricLabel: fabricLabel,
                // Use random 64-bit operational node IDs instead of sequential (1, 2, 3…).
                // Sequential IDs are not persisted across restarts (nextNodeId resets to 1
                // each time), and IdentityService does not re-register peers restored from
                // storage, so the sequential allocator can hand out a NodeId that a restored
                // peer already holds — ControllerCommissioner then rejects it with
                // "Node ID N is already commissioned and can not be reused". Random IDs avoid
                // the collision entirely.
                nodeIdAssignment: "random",
            },
        });

        // Listen for nodes added by commissioning or loaded from storage
        this._serverNode.peers.added.on( node => this._onNodeAdded( node ) );

        // Start the node (initialises network, loads commissioned nodes from storage)
        await this._serverNode.start();

        this.log.info( "%1 Matter ServerNode started (controller: '%2', fabric: '%3')", this, controllerName, fabricLabel );

        // Process nodes that already exist (loaded from storage).
        // peers.added does not fire for pre-existing nodes, so lifecycle listeners are registered manually.
        // NOTE: _syncNode is NOT called here — we wait for lifecycle.online which fires once
        // the subscription is active. Listeners on a cold (unsubscribed) endpoint never fire.
        let peersFound = 0;
        for ( const node of this._serverNode.peers ) {
            peersFound++;
            this._onNodeAdded( node );   // registers lifecycle.online.on + offline.on
        }
        this.log.info( "%1 %2 existing peer(s) registered", this, peersFound );

        // Remove Reactor entities whose nodes no longer exist in matter.js storage
        this._cleanupStaleEntities();

    }

    /** Registers the x_matter_controller capability (commission action) on the
     *  controller's system entity — replaces the old standalone HTTP commissioning UI. */
    _setupSystemEntity() {
        const sys = this.getSystemEntity();
        sys.extendCapability( "x_matter_controller" );
        // status/last_error reflect an in-flight or just-finished commissioning attempt, which
        // never survives a process restart (the in-memory _commissionQueue is gone) — force them
        // back to a clean idle state on every start(), not just the first time ever. Without this,
        // a restart that happens to occur while a commission is "pending" would leave status stuck
        // on "pending" forever (nothing left to resolve it), and a stale "error" from a past
        // attempt would linger indefinitely and look like an active problem. last_device_name/
        // last_device_node_id are historical ("last device commissioned") and are NOT reset here.
        sys.setAttributes({ status: "idle", last_error: "" }, "x_matter_controller" );
    }

    /**
     * Commissions a new Matter device using a manual pairing code (11 digits)
     * obtained from e.g. Apple Home (Pair in Another Home).
     *
     * @param {string} pairingCode  11-digit manual pairing code
     * @param {string} label        Human-readable name for logging
     * @param {boolean} [splitEndpoints]  If true, orphan endpoints (e.g. a sibling PowerSource
     *   endpoint with no device type of its own) become their own separate entity instead of
     *   being merged into the node's sole functional entity. Persisted per-node.
     */
    // Serialises commissioning calls — only one at a time to avoid races
    // on the cleanup loop that removes uncommissioned nodes.
    _commissionDevice( pairingCode, label, splitEndpoints ) {
        this._commissionQueue = (this._commissionQueue || Promise.resolve())
            .catch( () => {} )   // absorb previous failure so the queue doesn't stall
            .then( () => this._doCommissionDevice( pairingCode, label, splitEndpoints ) );
        return this._commissionQueue;
    }

    async _doCommissionDevice( pairingCode, label, splitEndpoints ) {
        const clean = String(pairingCode).replace(/[^0-9]/g, "");
        this.log.info( "%1 starting commissioning for '%2' (code: %3)", this, label, clean );

        let passcode, shortDiscriminator;
        try {
            const decoded = ManualPairingCodeCodec.decode( clean );
            passcode          = decoded.passcode;
            shortDiscriminator = decoded.shortDiscriminator;
            this.log.info( "%1 decoded pairing code: passcode=%2 shortDiscriminator=%3", this, passcode, shortDiscriminator );
        } catch ( e ) {
            throw new Error( `Invalid pairing code '${clean}': ${e.message}` );
        }

        // Remove uncommissioned nodes from previous attempts to avoid cached addresses
        try {
            for ( const node of [ ...this._serverNode.peers ] ) {
                if ( !node.lifecycle.isCommissioned ) {
                    this.log.info( "%1 removing uncommissioned node %2 before retry", this, node.id );
                    await node.delete().catch( () => {} );
                }
            }
        } catch { /* ignore */ }

        // Stash the label so _onNodeAdded() can attach it to the new node the instant
        // it appears — this must happen before commission() is called since the peers.added
        // event (and the lifecycle.online-triggered first _syncNode) can fire before this
        // function's own await resolves. See _onNodeAdded() for the consuming side.
        this._pendingCommissionLabel = label;
        // Same race-avoidance stash for the split_endpoints choice — must be readable by
        // _onNodeAdded() the instant the new node object exists, before its own
        // lifecycle.online-triggered first _syncNode can fire.
        this._pendingSplitEndpoints = splitEndpoints;

        // nodes.commission() is a CancelablePromise (extends Promise) that resolves to ClientNode
        const TIMEOUT_MS = 5 * 60 * 1000;
        this.log.info( "%1 calling nodes.commission()…", this );
        const discovery = this._serverNode.peers.commission({ passcode, shortDiscriminator, regulatoryCountryCode: "XX" });

        let clientNode;
        try {
            clientNode = await Promise.race([
                discovery,
                new Promise( (_, rej) => setTimeout(
                    () => { discovery.cancel(); rej( new Error("commissioning timeout after 5 min") ); },
                    TIMEOUT_MS
                ) ),
            ]);
        } catch ( e ) {
            // Log full error including stack and inner errors
            this.log.err( "%1 commissioning error: %2", this, e.message );
            this.log.err( "%1 stack: %2", this, (e.stack || "").split("\n").slice(0,5).join(" | ") );
            if ( e.errors ) {
                e.errors.forEach( (inner, i) => {
                    const cause = inner.cause ? ` cause: ${inner.cause?.message}` : "";
                    const causeStack = inner.cause?.stack ? ` | ${inner.cause.stack.split("\n").slice(0,3).join(" | ")}` : "";
                    this.log.err( "%1 inner[%2]: %3%4%5", this, i, inner.message, cause, causeStack );
                });
            }

            // statusCode 8 = FabricConflict, 9 = LabelConflict — device is already commissioned
            // on our fabric. Find the existing node and sync it instead.
            const isFabricConflict = /addNoc.*[: ][89][,\s]/.test( e.message ) ||
                                     /statusCode.*[89]/.test( e.message ) ||
                                     e.message.includes("FabricConflict") ||
                                     e.message.includes("LabelConflict") ||
                                     e.errors?.some( inner => inner.message?.includes("already commissioned and can not be reused") );
            if ( isFabricConflict ) {
                this.log.warn( "%1 AddNOC FabricConflict — searching for existing commissioned node…", this );
                const existing = [ ...this._serverNode.peers ]
                    .filter( n => n.lifecycle.isCommissioned && !this._nodeMap.has( String(n.id) ) );
                if ( existing.length > 0 ) {
                    const node = existing[ existing.length - 1 ];
                    this.log.info( "%1 found existing node %2 — syncing", this, node.id );
                    this._commissioningLabels.set( String(node.id), label );
                    this._saveSplitEndpointsPref( String(node.id), splitEndpoints );
                    await this._syncNode( node ).catch( err =>
                        this.log.warn( "%1 _syncNode (FabricConflict-recover) failed: %2", this, err.message ) );
                    return String( node.id );
                }
                this.log.warn( "%1 no existing node found — device may already be commissioned in another session", this );
            }

            throw new Error( `Commissioning failed: ${e.message}` );
        } finally {
            // Don't let a stale label/preference leak onto some unrelated future node if this
            // attempt failed before _onNodeAdded() ever consumed it.
            this._pendingCommissionLabel = null;
            this._pendingSplitEndpoints = null;
        }

        const resultNodeId = String(clientNode.id);
        this.log.notice( "%1 device '%2' commissioned! Node ID: %3", this, label, resultNodeId );

        // Save the label from the commissioning UI so _syncNode can use it as the entity name
        this._commissioningLabels.set( resultNodeId, label );
        // Save permanently (survives entity deletion)
        this._savePersistedName( resultNodeId, label );
        // Save the split_endpoints choice permanently too (in case _onNodeAdded already
        // consumed the pending stash into a per-node preference before this point — this call
        // is idempotent and just ensures the persisted file reflects the final choice).
        this._saveSplitEndpointsPref( resultNodeId, splitEndpoints );

        // Wait briefly to let the node stabilise after CASE
        await new Promise( res => setTimeout(res, 2000) );

        // Sync the node immediately after commissioning regardless of lifecycle.isOnline —
        // isOnline may be false right after CASE but the node is still reachable.
        this.log.info( "%1 syncing node %2 immediately after commissioning (isOnline=%3)",
            this, resultNodeId, clientNode.lifecycle.isOnline );
        await this._syncNode( clientNode ).catch( e =>
            this.log.warn( "%1 _syncNode after commissioning failed: %2", this, e.message ) );

        return resultNodeId;
    }

    async _stopMatter() {
        this._nodeMap.clear();
        if ( this._serverNode ) {
            const node = this._serverNode;
            this._serverNode = null;
            try {
                // Timeout of 5s — matter.js can hang during close()
                await Promise.race([
                    node.close(),
                    new Promise( res => setTimeout(res, 5000) ),
                ]);
            } catch { /* ignore */ }
        }
    }


    _onNodeAdded( clientNode ) {
        // If a commissioning action is in flight, capture the label immediately —
        // before the very first lifecycle.online-triggered _syncNode() runs — so the
        // entity is created with the right name instead of an autoName that would
        // then win as "existingName" on every later sync.
        if ( this._pendingCommissionLabel != null ) {
            this._commissioningLabels.set( String(clientNode.id), this._pendingCommissionLabel );
            this._pendingCommissionLabel = null;
        }
        // Same race-avoidance pattern for the split_endpoints choice — must be persisted
        // before the first _syncNode() runs, since that's what decides whether orphan
        // endpoints get split off into their own entity or merged.
        if ( this._pendingSplitEndpoints != null ) {
            this._saveSplitEndpointsPref( String(clientNode.id), this._pendingSplitEndpoints );
            this._pendingSplitEndpoints = null;
        }
        clientNode.lifecycle.online.on( () => {
            this.log.notice( "%1 lifecycle.online fired for node %2 — running _syncNode", this, clientNode.id );
            this._syncNode( clientNode ).catch( e =>
                this.log.warn( "%1 _syncNode online error (node %2): %3", this, clientNode.id, e.message ) );
        });
        clientNode.lifecycle.offline.on( () => {
            this._markNodeOffline( clientNode.id );
        });
    }

    _markNodeOffline( nodeId ) {
        const data = this._nodeMap.get( String(nodeId) );
        if ( !data ) return;
        this.log.info( "%1 node %2 offline", this, nodeId );
        for ( const eid of data.entityIds ) {
            const entity = this.findEntity( eid );
            if ( entity ) entity.setAttribute( "x_matter.available", false );
        }
    }

    /** Marks entities as dead if their node no longer exists in matter.js storage. */
    _cleanupStaleEntities() {
        const knownPeerIds = new Set();
        for ( const peer of this._serverNode.peers ) {
            knownPeerIds.add( String(peer.id) );
        }
        for ( const entity of Object.values( this.getEntities() ) ) {
            if ( !entity.hasCapability( "x_matter" ) ) continue;
            const nodeId = entity.getAttribute( "x_matter.node_id" );
            if ( nodeId && !knownPeerIds.has( nodeId ) ) {
                this.log.info( "%1 removing stale entity %2 (node %3 not found)", this, entity.getID(), nodeId );
                entity.markDead( true );
            }
        }
    }

    /**
     * Reads a commissioned node's endpoints and creates/updates Reactor entities
     * and sets up subscriptions via matter.js behavior $Changed events.
     */
    async _syncNode( clientNode ) {
        const nodeIdStr  = String( clientNode.id );
        const peerAddress = clientNode.state?.commissioning?.peerAddress;

        if ( !peerAddress ) {
            this.log.warn( "%1 node %2 has no peerAddress — skipping", this, nodeIdStr );
            return;
        }

        this.log.info( "%1 syncing node %2", this, nodeIdStr );

        try {
            // Read cached state from matter.js local storage (interaction.read returns empty
            // due to version filtering once NetworkClient has subscribed and populated the cache)
            let endpointMap = this._readEndpointMapFromStorage( nodeIdStr );
            if ( !endpointMap || Object.keys( endpointMap ).length === 0 ) {
                // Fallback 1: in-memory behavior state (works immediately after commissioning)
                endpointMap = this._readEndpointMapFromLocalState( clientNode );
                if ( endpointMap ) {
                    this.log.debug( 5, "%1 _syncNode(%2) local state: %3 endpoints", this, nodeIdStr, Object.keys( endpointMap ).length );
                } else {
                    // Fallback 2: network read (e.g. if local cache is entirely absent)
                    this.log.debug( 5, "%1 _syncNode(%2) local state empty — reading from network", this, nodeIdStr );
                    const allAttrs = [];
                    for await ( const chunk of clientNode.interaction.read({ isFabricFiltered: true, includeKnownVersions: true, attributeRequests: [{}] }) ) {
                        for ( const change of chunk ) {
                            if ( change.kind === "attr-value" ) allAttrs.push( change );
                        }
                    }
                    this.log.debug( 5, "%1 _syncNode(%2) network read: %3 attr-value items", this, nodeIdStr, allAttrs.length );
                    endpointMap = this._buildEndpointMap( allAttrs );
                }
            } else {
                this.log.debug( 5, "%1 _syncNode(%2) storage: %3 endpoints", this, nodeIdStr, Object.keys( endpointMap ).length );
            }

            // Read vendorName/productName/firmwareVersion from root endpoint (ep 0), BasicInformation cluster
            let vendorName      = "Unknown";
            let productName     = "Unknown";
            let firmwareVersion = null;
            try {
                const bi = endpointMap[0]?.[BasicInformation.Cluster.id];
                if ( bi ) {
                    vendorName      = bi[1]  || vendorName;   // vendorName attribute id = 1
                    productName     = bi[3]  || productName;  // productName attribute id = 3
                    firmwareVersion = bi[10] || null;         // softwareVersionString attribute id = 10
                }
            } catch { /* ignore */ }

            const entityIds = [];

            // On bridge/aggregator devices (e.g. Matterbridge), each bridged sub-device sits
            // under a wrapper endpoint (partsList child) that carries its own distinct
            // BridgedDeviceBasicInformation.nodeLabel — build a child→parent map from every
            // endpoint's Descriptor.partsList so we can look that per-device name up below.
            // Without this, all sub-devices of the same node would otherwise share one name.
            const childToParent = {};
            for ( const [pEndpointId, pClusterMap] of Object.entries(endpointMap) ) {
                const partsList = pClusterMap[Descriptor.Cluster.id]?.[3];  // attributeId 3 = partsList
                if ( Array.isArray(partsList) ) {
                    for ( const childId of partsList ) childToParent[childId] = Number(pEndpointId);
                }
            }

            // Per-node split_endpoints preference (commission-time choice, persisted).
            // false (default) = legacy merge behavior; true = orphan endpoints become their
            // own separate entity instead of being merged into the node's sole functional entity.
            const splitEndpoints = !!this._splitEndpointsPrefs.get( nodeIdStr );

            // Some devices (e.g. several Thread door locks) put PowerSource on its own endpoint
            // with no recognizable device type of its own (Descriptor.deviceTypeList empty/unknown),
            // sibling to the endpoint carrying the actual functional cluster (e.g. DoorLock on ep1,
            // PowerSource on ep2). Collect any PowerSource attrs found anywhere in the node so they
            // can be merged into the one functional endpoint below — but only when the node has
            // exactly one entity-bearing endpoint, to avoid misattributing a shared/ambiguous
            // cluster to the wrong sub-device on multi-endpoint bridges/aggregators. This legacy
            // merge path only runs when split_endpoints is false for this node (see below).
            const nodeWidePowerSource = {};
            for ( const clusterMap of Object.values(endpointMap) ) {
                if ( clusterMap[PowerSource.Cluster.id] ) {
                    Object.assign( nodeWidePowerSource, clusterMap[PowerSource.Cluster.id] );
                }
            }

            // Pre-scan endpoints (skip ep 0 = root) to find which ones will actually become
            // entities, so we know whether it's safe to merge the node-wide bonus cluster above.
            const candidateEndpoints = [];
            for ( const [endpointId, clusterMap] of Object.entries(endpointMap) ) {
                const epId = Number(endpointId);
                if ( epId === 0 ) continue;

                // Read deviceTypeList from Descriptor cluster (cluster id 29, attr id 0)
                const descAttrs = clusterMap[Descriptor.Cluster.id];
                if ( !descAttrs ) continue;
                const deviceTypeList = descAttrs[0];  // attributeId 0 = deviceTypeList
                if ( !Array.isArray(deviceTypeList) || deviceTypeList.length === 0 ) continue;

                // Pick the best-matching config (most capabilities)
                const cfg = this._pickBestConfig( deviceTypeList );
                if ( !cfg ) continue;

                candidateEndpoints.push( { epId, clusterMap, cfg } );
            }

            // Orphan endpoints: any non-root endpoint that did NOT qualify as a candidateEndpoint
            // above (no recognizable device type) but exposes at least one cluster/attribute this
            // controller knows how to map to a Reactor capability (see ORPHAN_CLUSTER_CAPS). Under
            // split_endpoints=true, each becomes its own entity below instead of being merged.
            const candidateEpIds = new Set( candidateEndpoints.map( c => c.epId ) );
            const orphanEndpoints = [];
            if ( splitEndpoints ) {
                for ( const [endpointId, clusterMap] of Object.entries(endpointMap) ) {
                    const epId = Number(endpointId);
                    if ( epId === 0 || candidateEpIds.has(epId) ) continue;
                    const caps = [];
                    for ( const spec of ORPHAN_CLUSTER_CAPS ) {
                        if ( clusterMap[spec.clusterId]?.[spec.attrId] != null && !caps.includes( spec.capability ) ) {
                            caps.push( spec.capability );
                        }
                    }
                    if ( caps.length > 0 ) orphanEndpoints.push( { epId, clusterMap, caps } );
                }
            }

            for ( const { epId, clusterMap, cfg } of candidateEndpoints ) {
                // Legacy merge: only when this node has split_endpoints off, exactly one candidate
                // endpoint, and no PowerSource of its own already — unchanged from before.
                if ( !splitEndpoints && candidateEndpoints.length === 1 && !clusterMap[PowerSource.Cluster.id]
                     && Object.keys( nodeWidePowerSource ).length > 0 ) {
                    clusterMap[PowerSource.Cluster.id] = nodeWidePowerSource;
                }

                // Per-device name from the bridged wrapper endpoint's BridgedDeviceBasicInformation,
                // if any (only present for bridge/aggregator sub-devices, not standalone devices)
                let deviceLabel = null;
                const parentEpId = childToParent[epId];
                if ( parentEpId !== undefined ) {
                    deviceLabel = endpointMap[parentEpId]?.[BridgedDeviceBasicInformation.Cluster.id]?.[5] || null;
                }

                // When a split actually occurred on this node (at least one orphan endpoint was
                // split into its own entity) AND this is the sole main/functional entity on a
                // standalone (non-bridge) device, append this entity's own type_label to its name
                // too — e.g. "Entrédörr" + "Door Lock" — so it's clearly distinguishable from the
                // split-off sibling (e.g. "Entrédörr Battery / Voltage") rather than looking like an
                // unlabeled/default entity next to a labeled one. Only applies when a split actually
                // happened; otherwise the main entity keeps its plain, unsuffixed name as always.
                if ( !deviceLabel && orphanEndpoints.length > 0 && candidateEndpoints.length === 1 && cfg.type_label ) {
                    const nodeLevelName = this._persistedNames.get( nodeIdStr ) || this._commissioningLabels.get( nodeIdStr );
                    if ( nodeLevelName ) deviceLabel = `${nodeLevelName} ${cfg.type_label}`;
                }

                const eid = this._makeEntityId( nodeIdStr, epId );
                try {
                    this._createOrUpdateEntity( eid, nodeIdStr, epId, cfg, vendorName, productName,
                                                firmwareVersion, clusterMap, deviceLabel );
                    entityIds.push( eid );
                } catch ( e ) {
                    this.log.warn( "%1 could not create entity %2: %3", this, eid, e.message );
                }
            }

            // Create a separate entity for each orphan endpoint (split_endpoints=true only).
            // These get a synthetic cfg (no matter_devices.yaml entry exists for a device-type-less
            // endpoint) built from whichever capabilities its clusters matched in ORPHAN_CLUSTER_CAPS.
            const CAP_LABELS = { battery_power: "Battery", voltage_sensor: "Voltage" };
            for ( const { epId, clusterMap, caps } of orphanEndpoints ) {
                const suffix = caps.map( c => CAP_LABELS[c] || c ).join(" / ");

                let deviceLabel = null;
                const parentEpId = childToParent[epId];
                if ( parentEpId !== undefined ) {
                    const parentLabel = endpointMap[parentEpId]?.[BridgedDeviceBasicInformation.Cluster.id]?.[5] || null;
                    if ( parentLabel ) deviceLabel = `${parentLabel} ${suffix}`;
                }
                // Standalone (non-bridge) device: there's no per-endpoint BridgedDeviceBasicInformation
                // label to fall back to, so persistedName/uiLabel (both keyed per NODE, not per
                // endpoint) would otherwise win via _createOrUpdateEntity's naming priority and give
                // this orphan entity the exact same name as the main functional entity. Build a
                // "<node name> <suffix>" label instead so it ranks ahead of those in the priority
                // chain (existingName || deviceLabel || persistedName || uiLabel || ...).
                if ( !deviceLabel ) {
                    const nodeLevelName = this._persistedNames.get( nodeIdStr ) || this._commissioningLabels.get( nodeIdStr );
                    if ( nodeLevelName ) deviceLabel = `${nodeLevelName} ${suffix}`;
                }

                const orphanCfg = {
                    entity_type:   "Sensor",
                    capabilities:  caps,
                    type_label:    suffix,
                    default_name:  `${vendorName} ${productName} ${suffix} (${nodeIdStr}:${epId})`,
                };

                const eid = this._makeEntityId( nodeIdStr, epId );
                try {
                    this._createOrUpdateEntity( eid, nodeIdStr, epId, orphanCfg, vendorName, productName,
                                                firmwareVersion, clusterMap, deviceLabel );
                    entityIds.push( eid );
                    this.log.info( "%1 split_endpoints: created separate entity %2 for orphan endpoint %3 (%4)",
                        this, eid, epId, suffix );
                } catch ( e ) {
                    this.log.warn( "%1 could not create split entity %2: %3", this, eid, e.message );
                }
            }

            // Update the node map and clear any commissioning label
            this._nodeMap.set( nodeIdStr, { peerAddress, entityIds } );
            this._commissioningLabels.delete( nodeIdStr );

            // Register listeners on behavior events (matter.js auto-subscribes; we only
            // need to listen on the $Changed events, no separate subscription required)
            this._registerStateListeners( clientNode, nodeIdStr );

            this.log.info( "%1 node %2 synced (%3 entity/-ies)", this, nodeIdStr, entityIds.length );

        } catch ( err ) {
            this.log.err( "%1 _syncNode(%2) error: %3", this, nodeIdStr, err.message );
            throw err;
        }
    }

    // ── Private: Entity management ───────────────────────────────────────────────

    _createOrUpdateEntity( entityId, nodeIdStr, endpointId, cfg, vendorName, productName, firmwareVersion, clusterMap, deviceLabel ) {
        const entity = this.getEntity( cfg.entity_type || "Switch", entityId );
        entity.deferNotifies( true );

        try {
            // Mark as available (node is online when we sync)
            entity.setAttribute( "x_matter.available", true );

            // Name priority: existing name (restart) always wins so user renames survive.
            // Otherwise prefer the per-device bridged label (e.g. Matterbridge's name for this
            // specific sub-device). persistedName/uiLabel are keyed per NODE (one name per whole
            // Matter node, from matter-names.json / the commissioning UI input) — fine for
            // single-device nodes, but must rank below deviceLabel, or every sub-device of a
            // bridge/aggregator would get the same node-level name again.
            const uiLabel        = this._commissioningLabels.get( nodeIdStr );
            const existingName   = entity.getAttribute( "x_matter.node_id" ) ? entity.getName() : null;
            const persistedName  = this._persistedNames.get( nodeIdStr );
            const autoName       = `${vendorName} ${productName} (${nodeIdStr}:${endpointId})`;
            entity.setName( existingName || deviceLabel || persistedName || uiLabel || cfg.default_name || autoName );

            // Extend capabilities — start from the device-type's declared list, then
            // opportunistically auto-add any capability we know how to map from a cluster
            // that's actually present on this endpoint, regardless of the device type/YAML
            // (e.g. a battery-powered lock/sensor exposes PowerSource even though
            // matter_devices.yaml's capability list for its primary device type doesn't
            // mention battery_power). Keep this list small — only clusters we have fully
            // working read/write/listener code for, to avoid exposing dead attributes.
            const capsList = [...(cfg.capabilities || [])];
            if ( clusterMap[PowerSource.Cluster.id]?.[12] != null && !capsList.includes( "battery_power" ) ) {
                capsList.push( "battery_power" );
            }
            // batVoltage (attr 11, mV) maps directly onto the standard voltage_sensor
            // (alias of value_sensor) capability — same opportunistic auto-detect pattern
            // as battery_power above.
            if ( clusterMap[PowerSource.Cluster.id]?.[11] != null && !capsList.includes( "voltage_sensor" ) ) {
                capsList.push( "voltage_sensor" );
            }
            const caps = [...capsList, "x_matter"];
            entity.extendCapabilities( caps, true );

            // Matter metadata
            entity.setAttribute( "x_matter.node_id",     nodeIdStr );
            entity.setAttribute( "x_matter.endpoint_id", endpointId );
            entity.setAttribute( "x_matter.vendor_name",  vendorName );
            entity.setAttribute( "x_matter.product_name", productName );
            if ( firmwareVersion != null ) {
                entity.setAttribute( "x_matter.firmware_version", firmwareVersion );
            }
            entity.setAttribute( "x_matter.device_type",
                cfg.type_label || "0x" + (cfg.device_type_id || 0).toString(16).toUpperCase().padStart(4, "0") );

            // Primary attribute for UI
            if ( cfg.primary_attribute ) {
                try { entity.setPrimaryAttribute( cfg.primary_attribute ); } catch { /* ignore */ }
            }

            // Apply initial attribute values from already-read data
            this._applyClusterValues( entity, clusterMap, capsList );

        } finally {
            entity.deferNotifies( false );
        }
    }

    /** Applies cluster attribute values (from initial sync) to an entity. */
    _applyClusterValues( entity, clusterMap, capabilities ) {
        for ( const cap of capabilities ) {
            try {
                switch ( cap ) {
                    case "power_switch": {
                        const v = clusterMap[OnOff.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "power_switch.state", Boolean(v) );
                        break;
                    }
                    case "dimming": {
                        const v = clusterMap[LevelControl.Cluster.id]?.[0];
                        if ( v != null ) {
                            entity.setAttribute( "dimming.level", Math.round( v / 254 * 100 ) / 100 );
                            entity.setAttribute( "dimming.step",  0.1 );
                        }
                        break;
                    }
                    case "color_temperature": {
                        // colorTemperatureMireds attr id 7 → Kelvin
                        const v = clusterMap[768]?.[7];
                        if ( v != null && v > 0 )
                            entity.setAttribute( "color_temperature.value", Math.round( 1_000_000 / v ) );
                        break;
                    }
                    case "temperature_sensor": {
                        const v = clusterMap[TemperatureMeasurement.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "temperature_sensor.value", v / 100 );
                        break;
                    }
                    case "motion_sensor": {
                        const v = clusterMap[OccupancySensing.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "motion_sensor.tripped", Boolean(v & 0x01) );
                        break;
                    }
                    case "door_sensor": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "door_sensor.state", Boolean(v) );
                        break;
                    }
                    case "binary_sensor": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "binary_sensor.state", Boolean(v) );
                        break;
                    }
                    case "battery_power": {
                        const v = clusterMap[PowerSource.Cluster.id]?.[12];
                        if ( v != null ) entity.setAttribute( "battery_power.level", v / 200 );
                        break;
                    }
                    case "voltage_sensor": {
                        // batVoltage is reported in millivolts — convert to volts
                        const v = clusterMap[PowerSource.Cluster.id]?.[11];
                        if ( v != null ) {
                            entity.setAttribute( "voltage_sensor.value", v / 1000 );
                            entity.setAttribute( "voltage_sensor.units", "V" );
                        }
                        break;
                    }
                    case "lock": {
                        // LockState enum: 0=NotFullyLocked, 1=Locked, 2=Unlocked, 3=Unlatched
                        const v = clusterMap[DoorLock.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "lock.state", v === 1 );
                        break;
                    }
                    // ── UNTESTED (2026-09-08) — no physical device available to verify yet.
                    // In particular the percent100ths direction (0=open/10000=closed per spec)
                    // and the "position.value" 0..1 convention (open=1 assumed here — CONFIRM
                    // against Reactor's other position-capability controllers, e.g. Zwave, once
                    // a real device exists) need checking against a real Window Covering device.
                    case "cover": {
                        const v = clusterMap[WindowCovering.Cluster.id]?.[14];
                        if ( v != null ) entity.setAttribute( "cover.state", v < 10000 );
                        break;
                    }
                    case "position": {
                        const v = clusterMap[WindowCovering.Cluster.id]?.[14];
                        if ( v != null ) entity.setAttribute( "position.value", Math.round( (10000 - v) / 100 ) / 100 );
                        break;
                    }
                    // UNTESTED (2026-09-08) — AlarmStateEnum semantics (Normal/Warning/Critical)
                    // assumed per spec; no physical smoke/CO alarm available to verify.
                    case "smoke_detector": {
                        const v = clusterMap[SmokeCoAlarm.Cluster.id]?.[1];
                        if ( v != null ) entity.setAttribute( "smoke_detector.state", v !== 0 );
                        break;
                    }
                    case "co_detector": {
                        const v = clusterMap[SmokeCoAlarm.Cluster.id]?.[2];
                        if ( v != null ) entity.setAttribute( "co_detector.state", v !== 0 );
                        break;
                    }
                    // ── UNTESTED (2026-09-08) — all cases below prepared from matter.js cluster
                    // specs only, no physical devices available yet to verify. Verify carefully
                    // the first time a real device of each type is commissioned (units, enum
                    // semantics, and sign conventions all need confirming against real hardware —
                    // the spec is not always followed consistently by vendors).
                    case "humidity_sensor": {
                        const v = clusterMap[RelativeHumidityMeasurement.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "humidity_sensor.value", v / 100 );
                        break;
                    }
                    case "pressure_sensor": {
                        // Spec: MeasuredValue = 10 x Pressure[kPa] — CONFIRM against real device.
                        const v = clusterMap[PressureMeasurement.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "pressure_sensor.value", v / 10 );
                        break;
                    }
                    case "value_sensor": {
                        // Flow sensor. Spec: MeasuredValue = 10 x Flow[m3/h] — CONFIRM units.
                        const v = clusterMap[FlowMeasurement.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "value_sensor.value", v / 10 );
                        break;
                    }
                    case "light_sensor": {
                        // Spec formula: MeasuredValue = 10000 * log10(lux) + 1 → invert to get lux.
                        const v = clusterMap[IlluminanceMeasurement.Cluster.id]?.[0];
                        if ( v != null && v > 0 )
                            entity.setAttribute( "light_sensor.value", Math.round( 10 ** ( (v - 1) / 10000 ) ) );
                        break;
                    }
                    case "air_quality_sensor": {
                        // AirQualityEnum: 0=Unknown,1=Good,2=Fair,3=Moderate,4=Poor,5=VeryPoor,6=ExtremelyPoor
                        // Stored as-is (0-6); CONFIRM this raw enum is a sensible ".value" for
                        // Reactor UI/rules, or whether it should be translated to a % / AQI scale.
                        const v = clusterMap[AirQuality.Cluster.id]?.[0];
                        if ( v != null ) entity.setAttribute( "air_quality_sensor.value", v );
                        break;
                    }
                    case "leak_detector": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "leak_detector.state", Boolean(v) );
                        break;
                    }
                    case "freeze_detector": {
                        const v = clusterMap[BooleanState.Cluster.id]?.[0];
                        if ( v !== undefined ) entity.setAttribute( "freeze_detector.state", Boolean(v) );
                        break;
                    }
                    case "valve": {
                        // ValveStateEnum: 0=Closed, 1=Open, 2=Transitioning
                        const v = clusterMap[ValveConfigurationAndControl.Cluster.id]?.[4];
                        if ( v != null ) entity.setAttribute( "valve.state", v === 1 );
                        break;
                    }
                    case "button": {
                        // GenericSwitch is event-driven (initialPress/shortRelease/longPress/...),
                        // not attribute-state driven — this only covers the initial full sync
                        // (current position at commissioning time). See _registerStateListeners()
                        // for the (highly speculative) live event → button.state mapping.
                        const v = clusterMap[MatterSwitch.Cluster.id]?.[1];
                        if ( v != null ) entity.setAttribute( "button.state", v > 0 ? "single" : "release" );
                        break;
                    }
                    case "ev_charger": {
                        // EnergyEvse.State enum — approximate mapping to ev_charger.state strings.
                        // READ-ONLY: set_current/set_operating_mode/set_schedule are NOT implemented,
                        // see DEVICE_MAP comment near 0x050C for why.
                        const v = clusterMap[EnergyEvse.Cluster.id]?.[0];
                        if ( v != null ) {
                            const STATE_MAP = {
                                0: "not connected", 1: "ready", 2: "ready",
                                3: "charging", 4: "charging", 5: "suspended", 6: "fault",
                            };
                            entity.setAttribute( "ev_charger.state", STATE_MAP[v] ?? "fault" );
                        }
                        break;
                    }
                }
            } catch { /* ignore individual read errors */ }
        }
    }

    // ── Private: Subscriptions ────────────────────────────────────────────────

    /**
     * Registers listeners on matter.js behavior $Changed events for all known endpoints.
     * matter.js maintains an automatic subscription — no separate subscription is needed.
     *
     * Covers all clusters in BEHAVIOR_MAP so Reactor entities are updated in real time:
     * on/off, dimming, color temperature, temperature, occupancy, boolean state, battery.
     */
    _registerStateListeners( clientNode, nodeIdStr ) {
        const data = this._nodeMap.get( nodeIdStr );
        if ( !data ) return;

        for ( const eid of data.entityIds ) {
            const entity = this.findEntity( eid );
            if ( !entity ) continue;
            const endpointId = entity.getAttribute( "x_matter.endpoint_id" );
            if ( endpointId == null ) continue;

            let ep;
            try { ep = clientNode.endpoints.for( endpointId ); } catch { continue; }

            const apply = ( clusterId, attributeId ) => ( value ) => {
                const e = this.findEntity( eid );
                if ( !e ) return;
                e.deferNotifies( true );
                try { this._applyOneAttribute( e, clusterId, attributeId, value ); }
                finally { e.deferNotifies( false ); }
            };

            const ev = ep.events;

            // If this entity has battery_power or voltage_sensor (possibly auto-detected
            // from a *sibling* endpoint — see _createOrUpdateEntity — and this endpoint
            // itself has no powerSource behavior), find the sibling endpoint that actually
            // carries PowerSource and listen there instead, so live updates still reach
            // this entity. Only meaningful/safe when this node has exactly one entity
            // (matches the merge condition used at creation time).
            let powerEv = ev;
            if ( ( entity.hasCapability( "battery_power" ) || entity.hasCapability( "voltage_sensor" ) )
                 && !ev?.powerSource && data.entityIds.length === 1 ) {
                for ( const sibling of clientNode.endpoints ) {
                    if ( !sibling || sibling.number === endpointId ) continue;
                    if ( sibling.events?.powerSource ) { powerEv = sibling.events; break; }
                }
            }

            // OnOff cluster (6)
            ev?.onOff?.onOff$Changed                            ?.on( apply( OnOff.Cluster.id, 0 ) );
            ev?.levelControl?.currentLevel$Changed              ?.on( apply( LevelControl.Cluster.id, 0 ) );

            // ColorControl cluster (768) — color temperature + XY
            ev?.colorControl?.colorTemperatureMireds$Changed    ?.on( apply( 768, 7 ) );
            ev?.colorControl?.colorMode$Changed                 ?.on( apply( 768, 8 ) );
            ev?.colorControl?.currentX$Changed                  ?.on( apply( 768, 3 ) );
            ev?.colorControl?.currentY$Changed                  ?.on( apply( 768, 4 ) );

            // TemperatureMeasurement cluster (1026)
            ev?.temperatureMeasurement?.measuredValue$Changed   ?.on( apply( TemperatureMeasurement.Cluster.id, 0 ) );

            // OccupancySensing cluster (1030)
            ev?.occupancySensing?.occupancy$Changed             ?.on( apply( OccupancySensing.Cluster.id, 0 ) );

            // BooleanState cluster (69)
            ev?.booleanState?.stateValue$Changed                ?.on( apply( BooleanState.Cluster.id, 0 ) );

            // PowerSource cluster (47) — batteri (own endpoint, or sibling — see powerEv above)
            powerEv?.powerSource?.batPercentRemaining$Changed   ?.on( apply( PowerSource.Cluster.id, 12 ) );
            powerEv?.powerSource?.status$Changed                ?.on( apply( PowerSource.Cluster.id, 0 ) );
            powerEv?.powerSource?.batVoltage$Changed            ?.on( apply( PowerSource.Cluster.id, 11 ) );

            // DoorLock cluster (257)
            ev?.doorLock?.lockState$Changed                     ?.on( apply( DoorLock.Cluster.id, 0 ) );

            // WindowCovering cluster (258) — UNTESTED, see comments in _applyClusterValues
            ev?.windowCovering?.currentPositionLiftPercent100ths$Changed ?.on( apply( WindowCovering.Cluster.id, 14 ) );

            // SmokeCoAlarm cluster (92) — UNTESTED, see comments in _applyClusterValues
            ev?.smokeCoAlarm?.smokeState$Changed                ?.on( apply( SmokeCoAlarm.Cluster.id, 1 ) );
            ev?.smokeCoAlarm?.coState$Changed                   ?.on( apply( SmokeCoAlarm.Cluster.id, 2 ) );

            // UNTESTED (2026-09-08) — remaining clusters below, see comments in _applyClusterValues.
            ev?.relativeHumidityMeasurement?.measuredValue$Changed ?.on( apply( RelativeHumidityMeasurement.Cluster.id, 0 ) );
            ev?.pressureMeasurement?.measuredValue$Changed      ?.on( apply( PressureMeasurement.Cluster.id, 0 ) );
            ev?.flowMeasurement?.measuredValue$Changed          ?.on( apply( FlowMeasurement.Cluster.id, 0 ) );
            ev?.illuminanceMeasurement?.measuredValue$Changed   ?.on( apply( IlluminanceMeasurement.Cluster.id, 0 ) );
            ev?.airQuality?.airQuality$Changed                  ?.on( apply( AirQuality.Cluster.id, 0 ) );
            ev?.valveConfigurationAndControl?.currentState$Changed ?.on( apply( ValveConfigurationAndControl.Cluster.id, 4 ) );
            ev?.energyEvse?.state$Changed                       ?.on( apply( EnergyEvse.Cluster.id, 0 ) );

            // Fallback for button: some client stacks may only expose currentPosition as a
            // plain attribute (no cluster events wired through) — treat a position change as
            // a generic "single" press/"release" if the event-based listeners above never fire.
            ev?.switch?.currentPosition$Changed                 ?.on( apply( MatterSwitch.Cluster.id, 1 ) );

            // GenericSwitch (button) — HIGHLY SPECULATIVE, the most uncertain code in this
            // whole batch. Matter's Switch cluster is *event*-driven (not attribute $Changed),
            // and the exact matter.js client-side event names/shapes below are assumed by
            // analogy with the cluster spec's event names — NOT verified against any working
            // client code or a real device. Expect to need real debugging here.
            try {
                const setBtn = state => {
                    const e = this.findEntity( eid );
                    if ( !e ) return;
                    e.setAttribute( "button.state", state );
                    e.setAttribute( "button.since", Date.now() );
                };
                ev?.switch?.events?.initialPress          ?.on( () => {} ); // press start — no Reactor equivalent, ignored
                ev?.switch?.events?.shortRelease           ?.on( () => setBtn( "single" ) );
                ev?.switch?.events?.longPress              ?.on( () => setBtn( "hold" ) );
                ev?.switch?.events?.longRelease            ?.on( () => setBtn( "long" ) );
                ev?.switch?.events?.multiPressComplete     ?.on( ( data ) => {
                    // Field name for press count is a guess (`totalNumberOfPressesCounted` per
                    // spec) — CONFIRM against real device payload shape.
                    const n = data?.totalNumberOfPressesCounted ?? data?.total ?? 2;
                    setBtn( n === 2 ? "double" : n === 3 ? "triple" : String( Math.min(n, 5) ) );
                });
            } catch { /* GenericSwitch events not available on this endpoint — ignore */ }

            this.log.debug( 5, "%1 behavior listeners registered for entity %2", this, eid );
        }
    }

    /** Applies a single attribute value to an entity. */
    _applyOneAttribute( entity, clusterId, attributeId, value ) {
        switch ( clusterId ) {
            case OnOff.Cluster.id:
                if ( attributeId === 0 )
                    entity.setAttribute( "power_switch.state", Boolean(value) );
                break;

            case LevelControl.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "dimming.level", Math.round( value / 254 * 100 ) / 100 );
                break;

            case 768: // ColorControl
                if ( attributeId === 7 && value != null && value > 0 )
                    // mireds → Kelvin
                    entity.setAttribute( "color_temperature.value", Math.round( 1_000_000 / value ) );
                break;

            case TemperatureMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "temperature_sensor.value", value / 100 );
                break;

            case OccupancySensing.Cluster.id:
                if ( attributeId === 0 )
                    entity.setAttribute( "motion_sensor.tripped", Boolean(value & 0x01) );
                break;

            case BooleanState.Cluster.id:
                if ( attributeId === 0 ) {
                    // Select the correct attribute name based on which capability the entity has
                    const boolAttr = entity.hasCapability("door_sensor")    ? "door_sensor.state"  :
                                     entity.hasCapability("leak_detector")   ? "binary_sensor.state" :
                                     entity.hasCapability("freeze_detector") ? "binary_sensor.state" :
                                     "binary_sensor.state";
                    entity.setAttribute( boolAttr, Boolean(value) );
                }
                break;

            case PowerSource.Cluster.id:
                if ( attributeId === 12 && value != null )
                    entity.setAttribute( "battery_power.level", value / 200 );
                if ( attributeId === 11 && value != null )
                    entity.setAttribute( "voltage_sensor.value", value / 1000 );
                break;

            case DoorLock.Cluster.id:
                // LockState enum: 0=NotFullyLocked, 1=Locked, 2=Unlocked, 3=Unlatched
                if ( attributeId === 0 )
                    entity.setAttribute( "lock.state", value === 1 );
                break;

            // UNTESTED (2026-09-08) — see comments in _applyClusterValues.
            case WindowCovering.Cluster.id:
                if ( attributeId === 14 && value != null ) {
                    entity.setAttribute( "cover.state", value < 10000 );
                    entity.setAttribute( "position.value", Math.round( (10000 - value) / 100 ) / 100 );
                }
                break;

            case SmokeCoAlarm.Cluster.id:
                if ( attributeId === 1 ) entity.setAttribute( "smoke_detector.state", value !== 0 );
                if ( attributeId === 2 ) entity.setAttribute( "co_detector.state", value !== 0 );
                break;

            // UNTESTED (2026-09-08) — see _applyClusterValues for caveats on all cases below.
            case RelativeHumidityMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "humidity_sensor.value", value / 100 );
                break;

            case PressureMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "pressure_sensor.value", value / 10 );
                break;

            case FlowMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "value_sensor.value", value / 10 );
                break;

            case IlluminanceMeasurement.Cluster.id:
                if ( attributeId === 0 && value != null && value > 0 )
                    entity.setAttribute( "light_sensor.value", Math.round( 10 ** ( (value - 1) / 10000 ) ) );
                break;

            case AirQuality.Cluster.id:
                if ( attributeId === 0 && value != null )
                    entity.setAttribute( "air_quality_sensor.value", value );
                break;

            case ValveConfigurationAndControl.Cluster.id:
                // ValveStateEnum: 0=Closed, 1=Open, 2=Transitioning
                if ( attributeId === 4 && value != null )
                    entity.setAttribute( "valve.state", value === 1 );
                break;

            case MatterSwitch.Cluster.id:
                // Fallback path only — see comment in _registerStateListeners. Select the
                // correct attribute name based on which capability the entity has, matching
                // the leak/freeze/binary_sensor selection pattern used for BooleanState above.
                if ( attributeId === 1 && value != null )
                    entity.setAttribute( "button.state", value > 0 ? "single" : "release" );
                break;

            case EnergyEvse.Cluster.id:
                if ( attributeId === 0 && value != null ) {
                    const STATE_MAP = {
                        0: "not connected", 1: "ready", 2: "ready",
                        3: "charging", 4: "charging", 5: "suspended", 6: "fault",
                    };
                    entity.setAttribute( "ev_charger.state", STATE_MAP[value] ?? "fault" );
                }
                break;
        }
    }

    // ── Privat: Commands ──────────────────────────────────────────────────────

    async _doOnOff( entity, clientNode, endpointId, action, params ) {
        const newState = action === "on" ? true : action === "off" ? false : (params?.state ?? false);
        await this._invokeCommand( clientNode, endpointId, OnOff, newState ? "on" : "off", undefined );
        // Optimistic update — subscription report will confirm later
        entity.setAttribute( "power_switch.state", newState );
    }

    async _doLock( entity, clientNode, endpointId, action, params ) {
        const newState = action === "lock" ? true : action === "unlock" ? false : (params?.state ?? false);
        await this._invokeCommand( clientNode, endpointId, DoorLock, newState ? "lockDoor" : "unlockDoor", undefined );
        // Optimistic update — subscription report will confirm later
        entity.setAttribute( "lock.state", newState );
    }

    // UNTESTED (2026-09-08) — prepared from matter.js/spec only, no physical Water Valve
    // device available yet to verify.
    async _doValve( entity, clientNode, endpointId, action, params ) {
        const newState = action === "open" ? true : action === "close" ? false : (params?.state ?? false);
        await this._invokeCommand( clientNode, endpointId, ValveConfigurationAndControl,
            newState ? "open" : "close", undefined );
        entity.setAttribute( "valve.state", newState );
    }

    // ── UNTESTED (2026-09-08) — prepared from matter.js/spec only, no physical Window
    // Covering device available yet. Verify against a real device before relying on this:
    //   - percent100ths direction (spec says 0=open, 10000=closed; confirm no inversion)
    //   - "open"/"close" mapping to upOrOpen/downOrClose (spec names, should be safe)
    //   - position.value 0..1 convention matches Reactor's other position-capable controllers
    async _doCover( entity, clientNode, endpointId, action, params ) {
        switch ( action ) {
            case "open":
                await this._invokeCommand( clientNode, endpointId, WindowCovering, "upOrOpen", undefined );
                entity.setAttribute( "cover.state", true );
                break;
            case "close":
                await this._invokeCommand( clientNode, endpointId, WindowCovering, "downOrClose", undefined );
                entity.setAttribute( "cover.state", false );
                break;
            case "stop":
                await this._invokeCommand( clientNode, endpointId, WindowCovering, "stopMotion", undefined );
                break;
            case "set": {
                const open = params?.state ?? false;
                await this._invokeCommand( clientNode, endpointId, WindowCovering,
                    open ? "upOrOpen" : "downOrClose", undefined );
                entity.setAttribute( "cover.state", open );
                break;
            }
        }
    }

    // UNTESTED (2026-09-08) — see _doCover() comment above; shares the same underlying
    // WindowCovering.goToLiftPercentage command as the "cover" capability's open/close.
    async _doPosition( entity, clientNode, endpointId, action, params ) {
        const clamp    = v => Math.max( 0, Math.min( 1, v ) );
        const toPct100 = v => Math.round( (1 - clamp(v)) * 10000 );  // Reactor 1=open → Matter 0=open
        const current  = entity.getAttribute( "position.value" ) ?? 0;

        let target;
        switch ( action ) {
            case "set":      target = clamp( params?.value ?? 0 );                       break;
            case "increase":  target = clamp( current + (params?.amount ?? 0.1) );        break;
            case "decrease":  target = clamp( current - (params?.amount ?? 0.1) );        break;
            case "relative":  target = clamp( current + (params?.amount ?? 0) );          break;
            default: return;
        }

        await this._invokeCommand( clientNode, endpointId, WindowCovering, "goToLiftPercentage", {
            liftPercent100thsValue: toPct100( target ),
        });
        entity.setAttribute( "position.value", target );
        entity.setAttribute( "cover.state", target > 0 );
    }

    async _doDimming( entity, clientNode, endpointId, action, params ) {
        const clamp = lvl => Math.max(1, Math.min(254, Math.round(lvl * 254)));
        const move  = async lvl => {
            await this._invokeCommand( clientNode, endpointId, LevelControl, "moveToLevel", {
                level:           clamp(lvl),
                transitionTime:  0,
                optionsMask:     0,
                optionsOverride: 0,
            });
            // Optimistic update
            entity.setAttribute( "dimming.level", Math.round( lvl * 100 ) / 100 );
        };

        switch ( action ) {
            case "set":  await move( params?.level ?? 1 ); break;
            case "up": {
                const step = entity.getAttribute("dimming.step") || 0.1;
                await move( Math.min(1, (entity.getAttribute("dimming.level") || 0) + step) );
                break;
            }
            case "down": {
                const step = entity.getAttribute("dimming.step") || 0.1;
                await move( Math.max(0, (entity.getAttribute("dimming.level") || 0) - step) );
                break;
            }
            default: this.log.warn( "%1 unknown dimming action: %2", this, action );
        }
    }

    async _doColorTemperature( entity, clientNode, endpointId, action, params ) {
        if ( action !== "set" || params?.value == null ) return;
        // Kelvin → mireds (Matter: 1 000 000 / K), clamp to valid range
        const mireds = Math.max( 1, Math.min( 65279, Math.round( 1_000_000 / params.value ) ) );
        await this._invokeCommand( clientNode, endpointId, ColorControl, "moveToColorTemperature", {
            colorTemperatureMireds:         mireds,
            transitionTime:                 0,
            colorTemperatureMinimumMireds:  0,
            colorTemperatureMaximumMireds:  65279,
            optionsMask:                    0,
            optionsOverride:                0,
        });
        // Optimistic update — convert back to Kelvin
        entity.setAttribute( "color_temperature.value", Math.round( 1_000_000 / mireds ) );
    }

    // ── Private: ClientNode management ───────────────────────────────────────

    /** Finds a ClientNode in peers by its nodeIdStr (same as String(node.id)). */
    async _getClientNode( nodeId ) {
        for ( const node of this._serverNode.peers ) {
            if ( String(node.id) === nodeId ) return node;
        }
        throw new Error( `ClientNode ${nodeId} not found in peers` );
    }

    /**
     * Sends a command via the 0.17.1 interaction.invoke() API.
     * Invoke() constructs the Map+invokeRequests structure that ClientInteraction requires.
     */
    async _invokeCommand( clientNode, endpointId, cluster, commandName, fields ) {
        const request = Invoke({
            commands: [
                Invoke.ConcreteCommandRequest({ endpoint: Number(endpointId), cluster, command: commandName, fields })
            ]
        });
        for await ( const chunk of clientNode.interaction.invoke( request ) ) {
            for ( const entry of chunk ) {
                if ( entry.kind === "cmd-status" && entry.status !== 0 ) {
                    throw new Error( `Command ${commandName} returned status ${entry.status}` );
                }
            }
        }
    }

    // ── Private: Helper methods ───────────────────────────────────────────────

    _namesFilePath() {
        return path.join( this._storDir, "matter-names.json" );
    }

    _loadPersistedNames() {
        try {
            const data = JSON.parse( fs.readFileSync( this._namesFilePath(), "utf8" ) );
            this._persistedNames = new Map( Object.entries(data) );
            this.log.debug( 5, "%1 loaded %2 persisted device names", this, this._persistedNames.size );
        } catch {
            this._persistedNames = new Map();
        }
    }

    _savePersistedName( nodeIdStr, name ) {
        this._persistedNames.set( nodeIdStr, name );
        try {
            const data = Object.fromEntries( this._persistedNames );
            fs.writeFileSync( this._namesFilePath(), JSON.stringify(data, null, 2), "utf8" );
        } catch ( e ) {
            this.log.warn( "%1 could not save device name: %2", this, e.message );
        }
    }

    _splitEndpointsFilePath() {
        return path.join( this._storDir, "matter-splitendpoints.json" );
    }

    _loadSplitEndpointsPrefs() {
        try {
            const data = JSON.parse( fs.readFileSync( this._splitEndpointsFilePath(), "utf8" ) );
            this._splitEndpointsPrefs = new Map( Object.entries(data) );
            this.log.debug( 5, "%1 loaded %2 persisted split_endpoints preferences", this, this._splitEndpointsPrefs.size );
        } catch {
            this._splitEndpointsPrefs = new Map();
        }
    }

    _saveSplitEndpointsPref( nodeIdStr, splitEndpoints ) {
        this._splitEndpointsPrefs.set( nodeIdStr, !!splitEndpoints );
        this._saveSplitEndpointsPrefsFile();
    }

    /** Persists the current _splitEndpointsPrefs Map as-is (used after deleting an entry). */
    _saveSplitEndpointsPrefsFile() {
        try {
            const data = Object.fromEntries( this._splitEndpointsPrefs );
            fs.writeFileSync( this._splitEndpointsFilePath(), JSON.stringify(data, null, 2), "utf8" );
        } catch ( e ) {
            this.log.warn( "%1 could not save split_endpoints preferences: %2", this, e.message );
        }
    }


    /**
     * Reads cached attribute state from matter.js file storage.
     *
     * @param {string} nodeIdStr – Matter NodeId as string (e.g. "1")
     * @returns {{ [epId]: { [clusterId]: { [attrId]: any } } } | null}
     */
    _readEndpointMapFromStorage( nodeIdStr ) {
        if ( !this._storDir ) return null;

        const storageDir = path.join( this._storDir, `reactor-${this.getID()}` );
        let files;
        try {
            files = fs.readdirSync( storageDir );
        } catch {
            return null;
        }

        // Find the peerId matching nodeIdStr via the peerAddress file
        let peerId = null;
        for ( const filename of files ) {
            if ( !filename.endsWith( ".commissioning.peerAddress" ) ) continue;
            const m = filename.match( /^nodes\.(peer\d+)\..+\.commissioning\.peerAddress$/ );
            if ( !m ) continue;
            try {
                const raw  = fs.readFileSync( path.join( storageDir, filename ), "utf8" );
                const addr = JSON.parse( raw );
                // nodeId is double-encoded JSON representing a BigInt
                const nodeIdObj = JSON.parse( addr.nodeId );
                if ( String( nodeIdObj.__value__ ) === nodeIdStr ) {
                    peerId = m[1];
                    break;
                }
            } catch { /* skip corrupt files */ }
        }

        if ( !peerId ) return null;

        // Build endpointMap from: nodes.{peerId}.endpoints.{epId}.{clusterId}.{attrId}
        const prefix = `nodes.${peerId}.endpoints.`;
        const endpointMap = {};

        for ( const filename of files ) {
            if ( !filename.startsWith( prefix ) ) continue;
            const rest = filename.slice( prefix.length );
            // File must have exactly 3 parts (epId.clusterId.attrId), all numeric
            const parts = rest.split( "." );
            if ( parts.length !== 3 ) continue;
            const epId     = Number( parts[0] );
            const clusterId = Number( parts[1] );
            const attrId   = Number( parts[2] );
            if ( !Number.isFinite(epId) || !Number.isFinite(clusterId) || !Number.isFinite(attrId) ) continue;

            try {
                const value = JSON.parse( fs.readFileSync( path.join( storageDir, filename ), "utf8" ) );
                if ( !endpointMap[epId] )              endpointMap[epId] = {};
                if ( !endpointMap[epId][clusterId] )   endpointMap[epId][clusterId] = {};
                endpointMap[epId][clusterId][attrId] = value;
            } catch { /* skip corrupt files */ }
        }

        return endpointMap;
    }

    /**
     * Reads cached attribute state from matter.js in-memory behavior state.
     * Works immediately after commissioning (before disk cache is flushed).
     *
     * @param {object} clientNode – ClientNode
     * @returns {{ [epId]: { [clusterId]: { [attrId]: any } } } | null}
     */
    _readEndpointMapFromLocalState( clientNode ) {
        // behaviorId → { id: clusterId, attrs: { propName: attrId } }
        const BEHAVIOR_MAP = {
            descriptor:              { id: 29,   attrs: { deviceTypeList: 0, serverList: 1, clientList: 2, partsList: 3 } },
            basicInformation:        { id: 40,   attrs: { vendorName: 1, vendorId: 2, productName: 3, productId: 4, softwareVersionString: 10 } },
            onOff:                   { id: 6,    attrs: { onOff: 0 } },
            levelControl:            { id: 8,    attrs: { currentLevel: 0 } },
            colorControl:            { id: 768,  attrs: { colorMode: 8, colorTemperatureMireds: 7, currentX: 3, currentY: 4 } },
            temperatureMeasurement:  { id: 1026, attrs: { measuredValue: 0 } },
            occupancySensing:        { id: 1030, attrs: { occupancy: 0 } },
            booleanState:            { id: 69,   attrs: { stateValue: 0 } },
            powerSource:             { id: 47,   attrs: { batPercentRemaining: 12, status: 0, batVoltage: 11 } },
            bridgedDeviceBasicInformation: { id: 57, attrs: { nodeLabel: 5 } },
            doorLock:                { id: 257,  attrs: { lockState: 0 } },
            // UNTESTED — see comment near WindowCovering/SmokeCoAlarm module vars.
            windowCovering:          { id: 258,  attrs: { currentPositionLiftPercent100ths: 14 } },
            smokeCoAlarm:            { id: 92,   attrs: { smokeState: 1, coState: 2 } },
            relativeHumidityMeasurement: { id: 1029, attrs: { measuredValue: 0 } },
            pressureMeasurement:     { id: 1027, attrs: { measuredValue: 0 } },
            flowMeasurement:         { id: 1028, attrs: { measuredValue: 0 } },
            illuminanceMeasurement:  { id: 1024, attrs: { measuredValue: 0 } },
            airQuality:              { id: 91,   attrs: { airQuality: 0 } },
            valveConfigurationAndControl: { id: 129, attrs: { currentState: 4 } },
            switch:                  { id: 59,   attrs: { currentPosition: 1 } },
            fanControl:              { id: 514,  attrs: { fanMode: 0 } },
            energyEvse:              { id: 153,  attrs: { state: 0 } },
        };

        const endpointMap = {};
        // Iterate every endpoint the node actually has (root + all descendants) instead of a
        // hardcoded numeric range — bridge/aggregator devices can expose endpoint numbers well
        // beyond 15 (e.g. a Matterbridge hub's sub-devices at ep17/ep18), which a fixed 0..15
        // loop would silently skip.
        const allEndpoints = [ clientNode, ...clientNode.endpoints ];
        for ( const endpoint of allEndpoints ) {
            if ( !endpoint ) continue;
            const epId = endpoint === clientNode ? 0 : endpoint.number;
            if ( epId === undefined || epId === null ) continue;

            let state;
            try {
                state = endpoint.state;
            } catch { continue; }
            if ( !state ) continue;

            const clusterMap = {};
            for ( const [behaviorId, info] of Object.entries( BEHAVIOR_MAP ) ) {
                const bs = state[ behaviorId ];
                if ( !bs || typeof bs !== "object" ) continue;
                const attrMap = {};
                for ( const [propName, attrId] of Object.entries( info.attrs ) ) {
                    if ( bs[ propName ] !== undefined ) attrMap[ attrId ] = bs[ propName ];
                }
                if ( Object.keys( attrMap ).length > 0 ) clusterMap[ info.id ] = attrMap;
            }
            if ( Object.keys( clusterMap ).length > 0 ) endpointMap[ epId ] = clusterMap;
        }

        return Object.keys( endpointMap ).length > 0 ? endpointMap : null;
    }

    _buildEndpointMap( allAttrs ) {
        const map = {};
        for ( const { path, value } of allAttrs ) {
            const { endpointId, clusterId, attributeId } = path;
            if ( !map[endpointId] ) map[endpointId] = {};
            if ( !map[endpointId][clusterId] ) map[endpointId][clusterId] = {};
            map[endpointId][clusterId][attributeId] = value;
        }
        return map;
    }

    /** Selects the DeviceType configuration with the most capabilities. */
    _pickBestConfig( deviceTypeList ) {
        let best     = null;
        let bestCaps = -1;

        for ( const dt of deviceTypeList ) {
            const code = typeof dt === "object" ? (dt.deviceType ?? dt.code) : dt;
            let cfg = null;

            // Check YAML file first, then built-in map
            if ( impl && Array.isArray(impl.mapping) ) {
                cfg = impl.mapping.find( m => Number(m.device_type_id) === code ) || null;
            }
            cfg = cfg || DEVICE_MAP.get(code) || null;

            if ( cfg ) {
                const n = (cfg.capabilities || []).length;
                if ( n > bestCaps ) { best = cfg; bestCaps = n; }
            }
        }

        return best;
    }

    _makeEntityId( nodeIdStr, endpointId ) {
        const safe = String(nodeIdStr).replace( /[^a-zA-Z0-9]/g, "_" );
        return `${safe}_ep${endpointId}`.substring(0, 128);
    }

    // ── Private: Poll ──────────────────────────────────────────────────────────

    // ── Private: Reconnection ─────────────────────────────────────────────────

    _scheduleReconnect() {
        if ( this._reconnTimer || this._stopping ) return;
        const BASE_MS  = 30_000;
        const MAX_MS   = 300_000;
        const FAST_IDX = 12;
        let delay = BASE_MS;
        if ( this._retryCount > FAST_IDX ) {
            delay = Math.min( MAX_MS, BASE_MS * Math.pow(2, this._retryCount - FAST_IDX) );
        }
        this.log.info( "%1 reconnecting in %2s (attempt %3)", this, Math.round(delay/1000), this._retryCount + 1 );

        this._reconnTimer = setTimeout( async () => {
            this._reconnTimer = null;
            if ( this._stopping ) return;
            this._retryCount++;
            await this._stopMatter();
            try {
                await this._startMatter();
                this._setupSystemEntity();
                this.online();
                this._retryCount = 0;
            } catch ( err ) {
                this.log.err( "%1 reconnection %2 failed: %3\n%4", this, this._retryCount, err.message, err.stack );
                this.offline();
                this._scheduleReconnect();
            }
        }, delay );
    }

    _clearReconnect() {
        if ( this._reconnTimer ) { clearTimeout(this._reconnTimer); this._reconnTimer = null; }
    }
}

module.exports = MatterController;
